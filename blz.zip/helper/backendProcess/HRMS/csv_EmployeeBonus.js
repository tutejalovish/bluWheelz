const multer = require("multer");
const path = require("path");
const moment = require("moment");
const xlsx = require("xlsx");
const helper = require("./../../helper");

const { hrmsDB } = require("./../../../config/database");

exports.EmployeeBonus = async function (data, uid, emit_hrms_notifications, expression) {
  try {
      let startTime = new Date();
      console.log("JSON parse data",JSON.parse(data))
      const date = JSON.parse(data).period.match(/([0-9]{2})-([0-9]{2})-([0-9]{4})/g);
      const fromdate = moment(date[0], "MM-YYYY").format("YYYY-MM");
      const todate = moment(date[1], "MM-YYYY").format("YYYY-MM");

     

      let stmt = await hrmsDB.query(
          `SELECT tbl_final_salary.final_emp_bonus, tbl_emp_basic.emp_code, 
          tbl_emp_basic.emp_gender, tbl_emp_basic.emp_status, tbl_emp_basic.emp_f_name, 
          tbl_emp_basic.emp_l_name, tbl_emp_basic.emp_dob, tbl_emp_basic.emp_doj, 
          tbl_emp_basic.emp_mobile, tbl_emp_family.emp_father_name 
          FROM tbl_final_salary 
          LEFT JOIN tbl_emp_basic 
          ON tbl_final_salary.final_emp_code = tbl_emp_basic.emp_code 
          WHERE tbl_final_salary.final_emp_payroll = :payroll 
          AND tbl_emp_basic.emp_code='MSW0024'
          AND DATE_FORMAT(tbl_final_salary.final_salary_period,'%Y-%m') 
          BETWEEN :datefrom AND :dateto`,
          {
              replacements: {
                  payroll: JSON.parse(data).payroll,
                  datefrom: fromdate,
                  dateto: todate,
              },
              type: hrmsDB.QueryTypes.SELECT,
          }
      );

      if (stmt.length > 0) {
          let result = [];
          let count = 0;

          stmt.forEach(async (data) => {
              let monthlyData = {};
              // Assuming you've monthly data for each employee
              // Populate it with necessary fields (Paid Days, Basic + DA, Bonus Amount)
              monthlyData["Apr'23"] = { "Paid Days": "", "Basic + DA": "", "Bonus Amount": "" };
              // Repeat for other months...

              // Accumulate totals
              let totalDays = 0;
              let totalSalary = 0;
              let totalAmount = 0;

              result.push({
                  "Sr No.": count + 1,
                  "Emp. Code": data.emp_code,
                  "Emp. Name": `${data.emp_f_name} ${data.emp_l_name}`,
                  "Father's Name": data.emp_father_name,
                  "Mobile No.": data.emp_mobile,
                  "Date Of Joining": moment(data.emp_doj, "YYYY-MM-DD").format("DD-MM-YYYY") ?? "N/A",
                  ...monthlyData,
                  "TOTAL DAY": totalDays,
                  "TOTAL SALARY": totalSalary,
                  "TOTAL AMOUNT": totalAmount,
              });

              count++;

              // Progress reporting logic remains the same...
          });

          if (stmt.length === count) {
              // Generate the Excel file
              const worksheet = xlsx.utils.json_to_sheet(result);
              const workbook = xlsx.utils.book_new();

              xlsx.utils.book_append_sheet(workbook, worksheet, "Employee Bonus");

              let randKey = Math.floor(Math.random() * (999 - 100 + 1)) + 100;
              const fileName = `./files/masterEmpBonus${randKey}.xlsx`;
              xlsx.writeFile(workbook, fileName);

              await hrmsDB.query(`UPDATE user_files_req SET status = 'complete', 
                  other_data = :other WHERE user_id= :uid 
                  AND req_code = :expression AND module_name = 'HRMS'`, 
                  {
                      replacements: {
                          expression: expression,
                          uid: uid,
                          other: JSON.stringify({
                              fileName: `masterEmpBonus${randKey}.xlsx`,
                              fileUrl: fileName,
                          }),
                      },
                      type: hrmsDB.QueryTypes.UPDATE,
                  }
              );
              emit_hrms_notifications();
          }
      } else {
          // Handle no data case
      }
  } catch (err) {
      console.log("Employee Bonus : ", err.stack);
      return res.json({
          status: "error",
          msg: "ERROR ",
          error: err.stack,
          code: 500,
      });
  }
};

