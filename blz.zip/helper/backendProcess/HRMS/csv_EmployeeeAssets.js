const multer = require("multer");
const path = require("path");
const moment = require("moment");
const xlsx = require("xlsx");
const helper = require("./../../helper");
const { verifyToken, error_log, emit_error_msg, emit_notifications } = require("./../../utils");

const { hrmsDB } = require("./../../../config/database");

exports.EmployeeAssets = async function (
  data,
  uid,
  emit_hrms_notifications,
  expression,
) {
  try {
    const date = JSON.parse(data).period.match(
      /([0-9]{2})-([0-9]{2})-([0-9]{4})/g,
    );
    const fromdate = moment(date[0], "DD-MM-YYYY").format("YYYY-MM-DD");
    const todate = moment(date[1], "DD-MM-YYYY").format("YYYY-MM-DD");

    if (
      moment(date[1], "DD-MM-YYYY").diff(
        moment(date[0], "DD-MM-YYYY"),
        "days",
      ) > "90"
    ) {
      socket.emit("toastr_error", {
        msg: "you can not download more than 90 days data",
      });
      return;
    }

    let stmt1 = await hrmsDB.query(
      "SELECT tbl_emp_basic.emp_f_name, tbl_emp_basic.emp_l_name, tbl_emp_basic.emp_gender, tbl_emp_basic.emp_doj, tbl_emp_basic.emp_status, master_asset_type.type_name, master_assets.*, assets_transaction.at_txn_assign_dt, assets_transaction.at_txn_emp, assets_transaction.at_txn_dt, assets_transaction.at_txn_remark, assets_transaction.at_txn_refid FROM `master_asset_type` LEFT JOIN master_assets ON master_assets.asset_type = master_asset_type.type_id LEFT JOIN assets_transaction ON assets_transaction.at_assets_id = master_assets.asset_txn_id LEFT JOIN tbl_emp_basic ON tbl_emp_basic.emp_code = assets_transaction.at_txn_emp WHERE assets_transaction.at_current_status = '--' AND master_assets.is_in_draft = 'N' AND  DATE_FORMAT(assets_transaction.at_txn_dt,'%Y-%m-%d') BETWEEN :datefrom AND :dateto ORDER BY assets_transaction.at_txn_emp ASC",
      {
        replacements: {
          datefrom: fromdate,
          dateto: todate,
        },
        type: hrmsDB.QueryTypes.SELECT,
      },
    );
    if (stmt1.length > 0) {
      let result = [];
      let count = 0;
      stmt1.forEach(async (element) => {
        result.push({
          EMP_CODE: element.at_txn_emp,
          EMP_NAME: element.emp_f_name + " " + element.emp_l_name,
          DOJ:
            moment(element.emp_doj, "YYYY-MM-DD").format("DD-MM-YYYY") ??
            "N/A",
          GENDER: element.emp_gender ?? "N/A",
          STATUS:
            element.emp_status == "A"
              ? "Active"
              : element.emp_status == "T"
                ? "Terminated"
                : element.emp_status == "S"
                  ? "Suspended"
                  : element.emp_status == "H"
                    ? "Hold"
                    : element.emp_status == "RT"
                      ? "Retired"
                      : element.emp_status == "RS"
                        ? "Resigned"
                        : "N/A",
          ASSET_TYPE: element.type_name,
          ASSET_NAME: element.asset_name,
          MODEL: element.asset_model,
          SR_NO: element.asset_serial_number,
          INVOICE_NO: element.asset_inv_no,
          PURCHASE_DATE: element.purchase_date,
          VALUE: element.asset_value,
          UNDER_WARRANTY: element.is_warranty,
          WARRANTY_DATE: element.assets_warranty_dt
        });
        count++;

        if (stmt1.length == count) {
          const modifiedResult = result.map((obj) => {
            const modifiedObj = {};
            for (const key in obj) {
              modifiedObj[key.replace(/_/g, " ")] = obj[key];
            }
            return modifiedObj;
          });

          const worksheet = xlsx.utils.json_to_sheet(modifiedResult);

          const workbook = xlsx.utils.book_new();

          xlsx.utils.book_append_sheet(
            workbook,
            worksheet,
            "Assets Details",
          );

          //buffer we use to handle the big file
          xlsx.write(workbook, { bookType: "csv", type: "buffer" });

          let randKey = Math.floor(Math.random() * (999 - 100 + 1)) + 100;

          xlsx.writeFile(
            workbook,
            "./files/EmpAssetsRecord" + randKey + ".xlsx",
          );

          let stmt = await hrmsDB.query(
            "UPDATE `user_files_req` SET `status` = 'complete', `other_data` = :other WHERE `user_id`= :uid AND `req_code` = :expression AND `module_name` = 'HRMS'",
            {
              replacements: {
                expression: expression,
                uid: uid,
                other: JSON.stringify({
                  fileName: `EmpAssetsRecord${randKey}.xlsx`,
                  fileUrl: "./files/EmpAssetsRecord" + randKey + ".xlsx",
                }),
              },
              type: hrmsDB.QueryTypes.UPDATE,
            },
          );
          emit_hrms_notifications();
          return;
        }
      });
    } else {
      // no data found related to payroll id
    }
  } catch (err) {
    error_log({ stack: err.stack });
  }
};
