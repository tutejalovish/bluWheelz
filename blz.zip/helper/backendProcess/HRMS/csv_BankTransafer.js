const multer = require("multer");
const path = require("path");
const moment = require("moment");
const xlsx = require("xlsx");
const helper = require("./../../helper");

const { hrmsDB } = require("./../../../config/database");

exports.BankTransfer = async function (data, uid, emit_hrms_notifications, expression,socket) {
  try {
    const email = await hrmsDB.query("SELECT log_email_address FROM hrms_login WHERE log_user_id = :code", {
      replacements: {
        code:  uid
      },
      type: hrmsDB.QueryTypes.SELECT,
    });
    let startTime= new Date();
    const date = JSON.parse(data).period.match(/([0-9]{2})-([0-9]{2})-([0-9]{4})/g);
    const fromdate = moment(date[0], "DD-MM-YYYY").format("YYYY-MM-DD");
    const todate = moment(date[1], "DD-MM-YYYY").format("YYYY-MM-DD");

    if (moment(date[1], "DD-MM-YYYY").diff(moment(date[0], "DD-MM-YYYY"), "days") > "90") {
      socket.emit("toastr_error", {
        msg: "you can not download more than 90 days data",
      });
      return;
    }

    let stmt = await hrmsDB.query(
      "SELECT tbl_final_salary.*, tbl_emp_basic.emp_f_name, tbl_emp_basic.emp_l_name, tbl_emp_bank.emp_bank_ifsc, tbl_emp_bank.emp_bank_name, tbl_emp_bank.emp_bank_ac_no FROM `tbl_final_salary` LEFT JOIN tbl_emp_basic ON tbl_final_salary.final_emp_code = tbl_emp_basic.emp_code LEFT JOIN tbl_emp_bank ON tbl_final_salary.final_emp_code = tbl_emp_bank.emp_code WHERE `tbl_final_salary`.`final_emp_payroll` = :payroll AND DATE_FORMAT( `tbl_final_salary`.final_salary_insert_dt, '%Y-%m-%d' ) BETWEEN :datefrom AND :dateto",
      {
        replacements: {
          payroll: JSON.parse(data).payroll,
          datefrom: fromdate,
          dateto: todate,
        },
        type: hrmsDB.QueryTypes.SELECT,
      }
    );
    if (stmt.length > 0) {
      let result = [];
      let count = 0;
      stmt.forEach(async (data) => {
        result.push({
          Client_Code: "MSC03",
          Product_Code: "SALPAY",
          Payment_Type: "",
          "Payment_Ref_No.": "",
          Payment_Date: "",
          Instrument_Date: "",
          Dr_Ac_No: "0014260407",
          Amount: data.final_salary_take_home,
          Bank_Code_Indicator: "M",
          Beneficiary_Code: data.final_emp_code,
          Beneficiary_Name: data.emp_f_name + " " + data.emp_l_name,
          Beneficiary_Bank: "",
          "Beneficiary_Branch / IFSC Code": data.emp_bank_ifsc,
          Beneficiary_Acc_No: data.emp_bank_ac_no,
          Location: "",
          Print_Location: "",
          Instrument_Number: "",
          Ben_Add1: "",
          Ben_Add2: "",
          Ben_Add3: "",
          Ben_Add4: "",
          Beneficiary_Email: "",
          Beneficiary_Mobile: "",
          Debit_Narration: "WAGES " + moment(fromdate, "YYYY-MM-DD").format("MMM YY") + " PAY " + moment(new Date()).tz("Asia/Kolkata").format("DD MMM YY"),
          Credit_Narration: "",
          "Payment Details 1": "",
          "Payment Details 2": "",
          "Payment Details 3": "",
          "Payment Details 4": "",
          Enrichment_1: "",
          Enrichment_2: "",
          Enrichment_3: "",
          Enrichment_4: "",
          Enrichment_5: "",
          Enrichment_6: "",
          Enrichment_7: "",
          Enrichment_8: "",
          Enrichment_9: "",
          Enrichment_10: "",
          Enrichment_11: "",
          Enrichment_12: "",
          Enrichment_13: "",
          Enrichment_14: "",
          Enrichment_15: "",
          Enrichment_16: "",
          Enrichment_17: "",
          Enrichment_18: "",
          Enrichment_19: "",
          Enrichment_20: "",
        });
        count++;
        const totalRecords = stmt.length;
        const recordsProcessed = count;
        const recordsLeft = totalRecords - recordsProcessed;
        const percentage = (recordsProcessed / totalRecords) * 100;

        // Calculate the elapsed time
        const currentTime = new Date();
        if (count === 0) {
          startTime = currentTime; // Initialize startTime only at the beginning of the loop
        }
        const elapsedTime = currentTime - startTime; // Current time - start time
        const timePerRecord = elapsedTime / recordsProcessed; // Time per record
        const estimatedTimeLeft = timePerRecord * recordsLeft;

        // Convert estimatedTimeLeft from milliseconds to a more readable format
        const estimatedTimeLeftSeconds = Math.round(estimatedTimeLeft / 1000);
        const estimatedTimeLeftMinutes = Math.floor(estimatedTimeLeftSeconds / 60);
        const estimatedTimeLeftHours = Math.floor(estimatedTimeLeftMinutes / 60);

        // Calculate remaining minutes and seconds
        const remainingMinutes = estimatedTimeLeftMinutes % 60;
        const remainingSeconds = estimatedTimeLeftSeconds % 60;

        // Format the time as "00h:00m:00s"
        const formattedTime = `${estimatedTimeLeftHours.toString().padStart(2, "0")}h:${remainingMinutes.toString().padStart(2, "0")}m:${remainingSeconds.toString().padStart(2, "0")}s`;
        socket.emit("bnkTrnsfProgress", {
          percentage: percentage.toFixed(2),
          remainingTime: formattedTime,
          totalRecords: totalRecords,
          recordsProcessed: recordsProcessed,
          recordsLeft: recordsLeft,
        });
        console.log(`Progress: ${percentage.toFixed(2)}% | Remaining time: ${formattedTime} | Total Records: ${totalRecords} | Records Processed: ${recordsProcessed} | Records Left: ${recordsLeft} `);
        if (stmt.length == count) {
          const worksheet = xlsx.utils.json_to_sheet(result);
          const workbook = xlsx.utils.book_new();

          xlsx.utils.book_append_sheet(workbook, worksheet, "electronic");

          //buffer we use to handle the big file
          xlsx.write(workbook, { bookType: "csv", type: "buffer" });

          let randKey = Math.floor(Math.random() * (999 - 100 + 1)) + 100;

          xlsx.writeFile(workbook, "./files/BankTransferSheet" + randKey + ".xlsx");
          let fileName=`BankTransferSheet${randKey}.xlsx`;
          let stmt = await hrmsDB.query("UPDATE `user_files_req` SET `status` = 'complete', `other_data` = :other WHERE `user_id`= :uid AND `req_code` = :expression AND `module_name` = 'HRMS'", {
            replacements: {
              expression: expression,
              uid: uid,
              other: JSON.stringify({
                fileName: fileName,
                fileUrl: "./files/BankTransferSheet" + randKey + ".xlsx",
              }),
            },
            type: hrmsDB.QueryTypes.UPDATE,
          });
          if(stmt.length>0){
              helper.sendMail(email[0].log_email_address, null, "Bank Transfer Report", "File Downloaded Successfully", { path: `./files/${fileName}` });
          }
          emit_hrms_notifications();
          return;
        }
      });
    } else {
      // no data found related to payroll id
    }
  } catch (err) {
    console.log("Bank Transfer Sheet : ", err.stack);
    return res.json({
      status: "error",
      msg: "ERROR ",
      error: err.stack,
      code: 500,
    });
  }
};
