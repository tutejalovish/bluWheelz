const { hrmsDB, saviorDB } = require("../../../config/database");

const jwt = require("jsonwebtoken");
const moment = require("moment");
const helper = require("../../helper");
const xlsx = require("xlsx");
const fs = require("fs");

function verifyToken(token) {
  return new Promise((resolve, reject) => {
    jwt.verify(token, process.env.TOKEN_SECRET, (err, decoded) => {
      if (err) {
        reject(err);
      } else {
        resolve(decoded);
      }
    });
  });
}
exports.generateSaviorAttendance = function (io, socket) {
  socket.on("generate_savior_attendance", async (reqData) => {
    let user_token = await verifyToken(`${socket.handshake.auth.token}`);
    const userId = user_token.crn_id;

    try {
      let stmt0 = await hrmsDB.query("SELECT `paid_emp_payroll`, `paid_salary_period`, `salary_draft_batch` FROM `tbl_draft_salary` WHERE `paid_salary_period` = :period AND `paid_emp_payroll` = :payroll ORDER BY `ID` DESC LIMIT 1", {
        replacements: {
          payroll: reqData.payroll,
          period: moment(reqData.period, "YYYY-MM").format("YYYY-MM"),
        },
        type: hrmsDB.QueryTypes.SELECT,
      });

      if (stmt0.length > 0) {
        socket.emit("toastr_error", {
          msg: "payroll preview is already generated, delete all the draft and generate again",
        });
        return;
      }

      let t1 = await hrmsDB.transaction();

      let stmt1 = await hrmsDB.query("SELECT * FROM `tbl_emp_basic` WHERE `payroll_id` = :contractor", {
        replacements: {
          contractor: reqData.payroll,
        },
        type: hrmsDB.QueryTypes.SELECT,
      });
      if (stmt1.length > 0) {
        let total_emp_code = stmt1.length;

        for (let i = 0; i < stmt1.length; i++) {
          let stmt2 = await saviorDB.query(
            "SELECT SUM(CASE WHEN status = 'P' THEN 1 ELSE 0 END) AS total_present, SUM(CASE WHEN status = 'A' THEN 1 ELSE 0 END) AS total_absent, SUM(CASE WHEN status = 'ABS' THEN 1 ELSE 0 END) AS total_abs, SUM(CASE WHEN status = 'HLD' THEN 1 ELSE 0 END) AS total_hld, SUM(CASE WHEN status = 'POH' THEN 1 ELSE 0 END) AS total_poh, SUM(CASE WHEN status = 'SRT' THEN 1 ELSE 0 END) AS total_srt, SUM(CASE WHEN status = 'WO' THEN 1 ELSE 0 END) AS total_wo, SUM(CASE WHEN status = 'PWO' THEN 1 ELSE 0 END) AS total_pow, SUM(CASE WHEN shiftattended = 'NYT' THEN 1 ELSE 0 END) AS total_nyt, SUM(otduration) AS ot_min, CAST(SUM(otduration) / 60 AS DECIMAL(10, 1)) AS ot_hours FROM tbltimeregister WHERE dateoffice >= :fromdate AND dateoffice < :todate AND paycode = :empcode",
            {
              replacements: {
                empcode: stmt1[i].emp_code,
                fromdate: moment(reqData.period, "YYYY-MM").startOf("month").format("YYYY-MM-DD"),
                todate: moment(reqData.period, "YYYY-MM").endOf("month").format("YYYY-MM-DD"),
              },
              type: saviorDB.QueryTypes.SELECT,
            }
          );

          if (stmt2.length > 0) {
            for (let j = 0; j < stmt2.length; j++) {
              await hrmsDB.query(
                "INSERT INTO tbl_attendance (attend_payroll, attend_emp_code, attend_month_for, attend_work_days, attend_ot_min, attend_ot_hrs, attend_night_allowance, attend_night_days, `attend_insert_dt`, `attend_in_by`, `attend_key`) VALUES (:payroll, :emp_code, :month_for, :work_days, :ot_min, :ot_hrs, :night_allowance, :night_days, :insert_dt, :insert_by, :attend_key)",
                {
                  replacements: {
                    payroll: reqData.payroll,
                    emp_code: stmt1[i].emp_code,
                    month_for: moment(reqData.period, "YYYY-MM").format("YYYY-MM"),
                    work_days: stmt2[j].total_present ?? 0,
                    ot_min: stmt2[j].ot_min,
                    ot_hrs: stmt2[j].ot_hours,
                    night_allowance: stmt2[j].total_nyt === null || stmt2[j].total_nyt === 0 ? "N" : "Y",
                    night_days: stmt2[j].total_nyt ?? 0,
                    insert_dt: moment().format("YYYY-MM-DD HH:mm:ss"),
                    insert_by: userId,
                    attend_key: helper.getUniqueNumber(),
                  },
                  type: hrmsDB.QueryTypes.INSERT,
                  transaction: t1,
                }
              );

              const totalRecords = total_emp_code;
              const recordsProcessed = i + 1;
              const recordsLeft = totalRecords - recordsProcessed;
              const percentage = (recordsProcessed / totalRecords) * 100;

              // Calculate the elapsed time
              const currentTime = new Date();
              if (i === 0) {
                startTime = currentTime; // Initialize startTime only at the beginning of the loop
              }
              const elapsedTime = currentTime - startTime; // Current time - start time
              const timePerRecord = elapsedTime / recordsProcessed; // Time per record
              const estimatedTimeLeft = timePerRecord * recordsLeft;

              // Convert estimatedTimeLeft from milliseconds to a more readable format
              const estimatedTimeLeftSeconds = Math.round(estimatedTimeLeft / 1000);
              const estimatedTimeLeftMinutes = Math.floor(estimatedTimeLeftSeconds / 60);
              const estimatedTimeLeftHours = Math.floor(estimatedTimeLeftMinutes / 60);

              // Calculate remaining minutes and seconds
              const remainingMinutes = estimatedTimeLeftMinutes % 60;
              const remainingSeconds = estimatedTimeLeftSeconds % 60;

              // Format the time as "00h:00m:00s"
              const formattedTime = `${estimatedTimeLeftHours.toString().padStart(2, "0")}h:${remainingMinutes.toString().padStart(2, "0")}m:${remainingSeconds.toString().padStart(2, "0")}s`;

              io.emit("progress_update", {
                total: totalRecords,
                processed: recordsProcessed,
                left: recordsLeft,
                percentage: percentage.toFixed(2),
                estimatedTimeLeft: formattedTime,
              });
            }
          }
        }

        await t1.commit();
        socket.emit("toastr_success", {
          msg: "attendance generated successfully",
        });
      } else {
        await t1.rollback();
        socket.emit("toastr_error", {
          msg: "an error occurred while importing attendance for employee code (" + item.attend_emp_code + ")",
        });
        return;
      }
    } catch (err) {
      socket.emit("toastr_error", {
        msg: "an error occurred while generating attendance draft - " + err.stack,
      });
      console.log(err.stack);
    }
  });
};
exports.saveSaviorAttendance = function (io, socket) {
  socket.on("save_savior_attendance", async (reqData) => {
    let user_token = await verifyToken(`${socket.handshake.auth.token}`);
    const userId = user_token.crn_id;

    try {
      let stmt0 = await hrmsDB.query("SELECT `paid_emp_payroll`, `paid_salary_period`, `salary_draft_batch` FROM `tbl_draft_salary` WHERE `paid_salary_period` = :period AND `paid_emp_payroll` = :payroll ORDER BY `ID` DESC LIMIT 1", {
        replacements: {
          payroll: reqData.payroll,
          period: moment(reqData.period, "YYYY-MM").format("YYYY-MM"),
        },
        type: hrmsDB.QueryTypes.SELECT,
      });

      if (stmt0.length > 0) {
        socket.emit("toastr_error", {
          msg: "payroll preview is already generated, delete all the draft and generate again",
        });
        return;
      }

      let t1 = await hrmsDB.transaction();

      let stmt1 = await hrmsDB.query("SELECT * FROM `tbl_emp_basic` WHERE `payroll_id` = :contractor AND status_id = 'A'", {
        replacements: {
          contractor: reqData.payroll,
        },
        type: hrmsDB.QueryTypes.SELECT,
      });
      if (stmt1.length > 0) {
        let total_emp_code = stmt1.length,
          totalInserted = 0;

        for (let i = 0; i < stmt1.length; i++) {
          let stmt2 = await saviorDB.query("SELECT dateoffice, in1, out2, hoursworked, otduration, status, shift, shiftstarttime, shiftendtime shiftattended FROM tbltimeregister WHERE dateoffice >= :fromdate AND dateoffice < :todate AND paycode = :empcode", {
            replacements: {
              empcode: stmt1[i].emp_code,
              fromdate: moment(reqData.period, "YYYY-MM").startOf("month").format("YYYY-MM-DD"),
              todate: moment(reqData.period, "YYYY-MM").endOf("month").format("YYYY-MM-DD"),
            },
            type: saviorDB.QueryTypes.SELECT,
          });

          if (stmt2.length > 0) {
            for (let j = 0; j < stmt2.length; j++) {
              await hrmsDB.query(
                "INSERT INTO tbl_attendance_log (log_date, log_empcode, log_in, log_out, log_status, workduration, otduration,`log_insert_by`, `log_key`, log_shift, log_shift_start, log_shift_end) VALUES (:date, :emp_code, :clockin, :clockout, :status, :workduration, :otduration,:insert_by, :log_key, :shift, :shift_start, :shift_end)",
                {
                  replacements: {
                    date: reqData.payroll,
                    emp_code: stmt1[i].emp_code,
                    clockin: stmt2[j].in1 == null ? "--" : stmt2[j].in1,
                    clockout: stmt2[j].out2 == null ? "--" : stmt2[j].out2,
                    status: stmt2[j].status,
                    workduration: stmt2[j].hoursworked,
                    otduration: stmt2[j].otduration,
                    insert_by: userId,
                    log_key: helper.getUniqueNumber(),
                    shift: stmt2[j].shift,
                    shift_start: stmt2[j].shiftstarttime,
                    shift_end: stmt2[j].shiftendtime,
                  },
                  type: hrmsDB.QueryTypes.INSERT,
                  transaction: t1,
                }
              );

              const totalRecords = total_emp_code;
              const recordsProcessed = i + 1;
              const recordsLeft = totalRecords - recordsProcessed;
              const percentage = (recordsProcessed / totalRecords) * 100;

              // Calculate the elapsed time
              const currentTime = new Date();
              if (i === 0) {
                startTime = currentTime; // Initialize startTime only at the beginning of the loop
              }
              const elapsedTime = currentTime - startTime; // Current time - start time
              const timePerRecord = elapsedTime / recordsProcessed; // Time per record
              const estimatedTimeLeft = timePerRecord * recordsLeft;

              // Convert estimatedTimeLeft from milliseconds to a more readable format
              const estimatedTimeLeftSeconds = Math.round(estimatedTimeLeft / 1000);
              const estimatedTimeLeftMinutes = Math.floor(estimatedTimeLeftSeconds / 60);
              const estimatedTimeLeftHours = Math.floor(estimatedTimeLeftMinutes / 60);

              // Calculate remaining minutes and seconds
              const remainingMinutes = estimatedTimeLeftMinutes % 60;
              const remainingSeconds = estimatedTimeLeftSeconds % 60;

              // Format the time as "00h:00m:00s"
              const formattedTime = `${estimatedTimeLeftHours.toString().padStart(2, "0")}h:${remainingMinutes.toString().padStart(2, "0")}m:${remainingSeconds.toString().padStart(2, "0")}s`;

              socket.emit("progress_update", {
                total: totalRecords,
                processed: recordsProcessed,
                left: recordsLeft,
                percentage: percentage.toFixed(2),
                estimatedTimeLeft: formattedTime,
              });
            }
          }
        }
        totalInserted++;

        if (total_emp_code === totalInserted) {
          await t1.rollback();
          socket.emit("toastr_success", {
            msg: "attendance generated successfully",
          });
        } else {
          await t1.rollback();
          socket.emit("toastr_warning", {
            msg: "Some records failed to insert",
          });
        }
      } else {
        await t1.rollback();
        socket.emit("toastr_error", {
          msg: "an error occurred while importing attendance for employee code (" + item.attend_emp_code + ")",
        });
        return;
      }
    } catch (err) {
      socket.emit("toastr_error", {
        msg: "an error occurred while generating attendance draft - " + err.stack,
      });
      console.log(err.stack);
    }
  });
};
//UPDATE NEW CODE (array date 5 se start h to bki date pe A ayega)
exports.automateAttendance = async function (data, uid, emit_hrms_notifications, expression, socket, io) {
  const t = await hrmsDB.transaction();
  try {

    const insertTimeDt = moment(new Date()).format("YYYY-MM-DD HH:mm:ss");
    const email = await hrmsDB.query("SELECT log_email_address FROM hrms_login WHERE log_user_id = :code", {
      replacements: {
        code: uid,
      },
      type: hrmsDB.QueryTypes.SELECT,
    });


    const from_date = moment(JSON.parse(data).period, "MM-YYYY").format("YYYY-MM");




    const month = from_date.split("-")[1];
    let days = 0;
    if (month == "01" || month == "03" || month == "05" || month == "07" || month == "08" || month == "10" || month == "12") {
      days = 31;
    }
    else if (month == "04" || month == "06" || month == "09" || month == "11") {
      days = 30;
    }
    else {
      days = 29;
    }



    let arr = [];
    let totalQueries = 0;
    let count = 0;

    const stmt = await hrmsDB.query("SELECT emp_code,payroll_branch, CONCAT(emp_f_name,' ',emp_l_name) AS name FROM tbl_emp_basic WHERE payroll_id = :payroll AND emp_status IN ('H', 'A') and emp_type='WC' ORDER BY emp_code ASC ", {
      replacements: {
        payroll: JSON.parse(data).payroll,
      },
      type: hrmsDB.QueryTypes.SELECT,
    });

    let arr_header = ["SR NO", "CARD NO", "Employee Name", "Father Name", "Location"];
    for (let m = 1; m <= days; m++) {
      arr_header.push(m);
    }
    arr_header.push("Present Days", "EL", "SL", "W OFF", "HLD", "Absent Days", "SRT", "POH", "CO", "WFH", "POW", "Paid Days");
    let stmt1;
    for (let k = 0; k < stmt.length; k++) {
      const father_name = await hrmsDB.query("SELECT emp_father_name FROM tbl_emp_family WHERE emp_code = :emp_code ", {
        replacements: {
          emp_code: stmt[k].emp_code,
        },
        type: hrmsDB.QueryTypes.SELECT,
      });

      const location = await hrmsDB.query("SELECT branch_name FROM master_branch WHERE branch_key = :key ", {
        replacements: {
          key: stmt[k].payroll_branch,
        },
        type: hrmsDB.QueryTypes.SELECT,
      });
      if (father_name.length > 0) {
        if (father_name[0].emp_father_name == null) {
          father_name[0].emp_father_name = "";
        }
      }
      if (location.length > 0) {
        if (location[0].branch_name == null) {
          location[0].branch_name = "";
        }
      }

      let short_leave = 0;
      let arr_data = [k + 1, stmt[k].emp_code, stmt[k].name, father_name[0]?.emp_father_name ?? "", location[0].branch_name],
        present_days = 0,
        absent_days = 0,
        srt = 0,
        el = 0,
        sl = 0,
        w_off = 0,
        hld = 0,
        poh = 0,
        co = 0,
        wfh = 0,
        pow = 0;

      let stmt12 = await saviorDB.query(
        "SELECT paycode, ISNULL(CONVERT(varchar, dateoffice, 105) + ' ' + CONVERT(varchar, dateoffice, 108), '--') AS date_formatted, shiftstarttime, shiftendtime, ISNULL(CONVERT(varchar, in1, 105) + ' ' + CONVERT(varchar, in1, 108), '--') AS in1_formatted,ISNULL(CONVERT(varchar, out2, 105) + ' ' + CONVERT(varchar, out2, 108), '--') AS out2_formatted, ISNULL(DATENAME(dw, dateoffice), '--') AS day, ISNULL(CASE WHEN in1 IS NOT NULL AND out2 IS NOT NULL THEN CONVERT(varchar, DATEADD(SECOND, DATEDIFF(SECOND, in1, out2), 0), 108) ELSE '' END, '--') AS total_time, CASE WHEN otduration IS NOT NULL THEN CAST(otduration / 60.0 AS INT) ELSE 0  END AS otduration_in_hours,shift, shiftattended, status AS savior_status, CASE WHEN status = 'MIS' THEN 'MIS' WHEN in1 IS NULL AND out1 IS NULL THEN STATUS WHEN CONVERT(VARCHAR(8), DATEADD(SECOND, DATEDIFF(SECOND, in1, out2), 0), 108) BETWEEN '00:00:00' AND '04:29:59' THEN 'A' WHEN CONVERT(VARCHAR(8), DATEADD(SECOND, DATEDIFF(SECOND, in1, out2), 0), 108) BETWEEN '04:30:00' AND '08:59:59' THEN 'HD' WHEN CONVERT(VARCHAR(8), DATEADD(SECOND, DATEDIFF(SECOND, in1, out2), 0), 108) >= '09:00:00' THEN 'P' ELSE 'NA' END AS policy_status FROM tbltimeregister WHERE paycode = :emp_code AND CONVERT(VARCHAR(7), dateoffice, 120) = :dt ORDER BY dateoffice ASC",
        {
          replacements: {
            emp_code: stmt[k].emp_code,
            dt: from_date,
          },
          type: saviorDB.QueryTypes.SELECT,
        }
      );
      let status;
      let without_joining;
      if (stmt12.length > 0) {
        without_joining = stmt12[0].date_formatted.split(" ")[0].split("-")[0];
      } else {
        without_joining = 0;
      }

      for (let h = 1; h < without_joining; h++) {
        arr_data.push("--");
      }

      for (let g = 0; g < stmt12.length; g++) {

        const od = await hrmsDB.query("SELECT COALESCE(SUM(day), 0) AS day, leave_type FROM tbl_leave_breakup WHERE emp_code = :emp_code AND date = :date AND leave_type = 'OD' GROUP BY date", {
          replacements: {
            emp_code: stmt[k].emp_code,
            date: moment(from_date, "YYYY-MM-DD").add(g, "days").format("YYYY-MM-DD"),
          },
          type: hrmsDB.QueryTypes.SELECT,
        })
        if (od.length > 0) {
          arr_data.push("P");
          present_days++
        } else {

          if (stmt12[g].policy_status.trim() == "WO" || stmt12[g].savior_status.trim() == "POW") {
            arr_data.push("WO");
            w_off++;
          } else {
            totalQueries += stmt12.length; // Increment totalQueries based on the current stmt1 length

            status = stmt12[g].policy_status.trim();

            if (status == "A") {
              let stmt13 = await hrmsDB.query("SELECT COALESCE(SUM(day), 0) AS day, leave_type,start_time FROM tbl_leave_breakup WHERE emp_code = :emp_code AND date = :date AND leave_status = 'APR' GROUP BY date", {
                replacements: {
                  emp_code: stmt[k].emp_code,
                  date: moment(from_date, "YYYY-MM-DD").add(g, "days").format("YYYY-MM-DD"),
                },
                type: hrmsDB.QueryTypes.SELECT,
              });
              if (stmt13.length > 0) {
                const { day, leave_type, start_time } = stmt13[0];

                if (day === 1 && leave_type === "SL") {
                  status = "SL";
                  sl = sl + 1;
                } else if (day === 0.5 && leave_type === "SL" && start_time == "09:00 AM") {
                  let slP = await saviorDB.query("SELECT hoursworked FROM tbltimeregister WHERE dateoffice BETWEEN :fromDt AND :toDate AND paycode = :emp_code ORDER BY dateoffice ASC", {
                    replacements: {
                      emp_code: stmt[k].emp_code,
                      fromDt: moment(from_date, "YYYY-MM-DD").add(g, "days").format("YYYY-MM-DD"),
                      toDate: moment(from_date, "YYYY-MM-DD").add(g, "days").format("YYYY-MM-DD"),
                    },
                    type: saviorDB.QueryTypes.SELECT,
                  });
                  if (slP[0].hoursworked >= 270) {
                    status = "SL/P";
                    sl = sl + 0.5;
                    present_days = present_days + 0.5;
                  } else {
                    status = "SL/A";
                    absent_days = absent_days + 0.5;
                    sl = sl + 0.5;
                  }
                } else if (day === 0.5 && leave_type === "SL" && start_time == "01:30 PM") {
                  let Psl = await saviorDB.query("SELECT hoursworked FROM tbltimeregister WHERE dateoffice BETWEEN :fromDt AND :toDate AND paycode = :emp_code ORDER BY dateoffice ASC", {
                    replacements: {
                      emp_code: stmt[k].emp_code,
                      fromDt: moment(from_date, "YYYY-MM-DD").add(g, "days").format("YYYY-MM-DD"),
                      toDate: moment(from_date, "YYYY-MM-DD").add(g, "days").format("YYYY-MM-DD"),
                    },
                    type: saviorDB.QueryTypes.SELECT,
                  });
                  if (Psl[0].hoursworked >= 270) {
                    status = "P/SL";
                    sl = sl + 0.5;
                    present_days = present_days + 0.5;
                  } else {
                    status = "A/SL";
                    absent_days = absent_days + 0.5;
                    sl = sl + 0.5;
                  }
                } else if (day === 1 && leave_type === "EL") {
                  status = "EL";
                  el = el + 1;
                } else if (day == 0.5 && leave_type === "EL" && start_time == "09:00 AM") {
                  let elP = await saviorDB.query("SELECT hoursworked FROM tbltimeregister WHERE dateoffice BETWEEN :fromDt AND :toDate AND paycode = :emp_code ORDER BY dateoffice ASC", {
                    replacements: {
                      emp_code: stmt[k].emp_code,
                      fromDt: moment(from_date, "YYYY-MM-DD").add(g, "days").format("YYYY-MM-DD"),
                      toDate: moment(from_date, "YYYY-MM-DD").add(g, "days").format("YYYY-MM-DD"),
                    },
                    type: saviorDB.QueryTypes.SELECT,
                  });
                  if (elP[0].hoursworked >= 270) {
                    status = "EL/P";
                    el = el + 0.5;
                    present_days = present_days + 0.5;
                  } else {
                    status = "EL/A";
                    absent_days = absent_days + 0.5;
                    el = el + 0.5;
                  }
                } else if (day == 0.5 && leave_type === "EL" && start_time == "01:30 PM") {
                  let Pel = await saviorDB.query("SELECT hoursworked FROM tbltimeregister WHERE dateoffice BETWEEN :fromDt AND :toDate AND paycode = :emp_code ORDER BY dateoffice ASC", {
                    replacements: {
                      emp_code: stmt[k].emp_code,
                      fromDt: moment(from_date, "YYYY-MM-DD").add(g, "days").format("YYYY-MM-DD"),
                      toDate: moment(from_date, "YYYY-MM-DD").add(g, "days").format("YYYY-MM-DD"),
                    },
                    type: saviorDB.QueryTypes.SELECT,
                  });
                  if (Pel[0].hoursworked >= 270) {
                    status = "P/EL";
                    el = el + 0.5;
                    present_days = present_days + 0.5;
                  } else {
                    status = "A/EL";
                    absent_days = absent_days + 0.5;
                    el = el + 0.5;
                  }
                }
                else if (day == 1 && leave_type === "CL") {
                  status = "CO";
                  co = co + 1;
                }
                else if (day == 0.5 && leave_type === "CL" && start_time == "09:00 AM") {
                  let clP = await saviorDB.query("SELECT hoursworked FROM tbltimeregister WHERE dateoffice BETWEEN :fromDt AND :toDate AND paycode = :emp_code ORDER BY dateoffice ASC", {
                    replacements: {
                      emp_code: stmt[k].emp_code,
                      fromDt: moment(from_date, "YYYY-MM-DD").add(g, "days").format("YYYY-MM-DD"),
                      toDate: moment(from_date, "YYYY-MM-DD").add(g, "days").format("YYYY-MM-DD"),
                    },
                    type: saviorDB.QueryTypes.SELECT,
                  });
                  if (clP[0].hoursworked >= 270) {
                    status = "CO/P";
                    co = co + 1;
                    present_days = present_days + 1;
                  } else {
                    status = "CO/A";
                    absent_days = absent_days + 1;
                    co = co + 1;
                  }
                }
                else if (day == 0.5 && leave_type === "CL" && start_time == "01:30 PM") {
                  let Pcl = await saviorDB.query("SELECT hoursworked FROM tbltimeregister WHERE dateoffice BETWEEN :fromDt AND :toDate AND paycode = :emp_code ORDER BY dateoffice ASC", {
                    replacements: {
                      emp_code: stmt[k].emp_code,
                      fromDt: moment(from_date, "YYYY-MM-DD").add(g, "days").format("YYYY-MM-DD"),
                      toDate: moment(from_date, "YYYY-MM-DD").add(g, "days").format("YYYY-MM-DD"),
                    },
                    type: saviorDB.QueryTypes.SELECT,
                  });
                  if (Pcl[0].hoursworked >= 270) {
                    status = "P/CO";
                    co = co + 1;
                    present_days = present_days + 1;
                  } else {
                    status = "A/CO";
                    absent_days = absent_days + 1;
                    co = co + 1;
                  }
                }
                else if (leave_type === "OD") {
                  status = "P";
                  present_days = present_days + 1;
                } else if (leave_type === "WFH") {
                  status = "WFH";
                  wfh = wfh + 1;
                } else if (leave_type === "CL") {
                  status = "CO";
                  co = co + 1;
                }
              } else {
                status = "A";
                absent_days = absent_days + 1;
              }
            } else if (status == "POH") {
              status = "POH";
              poh = poh + 1;
            } else if (status == "POW") {
              status = "POW";
              pow = pow + 1;
            }

            /////////////////////////////////////////////////
            else if (status == "HD") {
              if (stmt12[g].total_time > "08:00:00" && stmt12[g].total_time < "09:00:00" && stmt12[g].policy_status.trim() === "HD") {
                short_leave++;
                if (short_leave > 3) {
                  status = "HD";
                  present_days = present_days + 0.5;
                  absent_days = absent_days + 0.5;
                } else {
                  status = "SRT";
                  srt = srt + 1;
                }
              } else {
                let stmt11 = await hrmsDB.query("SELECT COALESCE(SUM(day), 0) AS day, leave_type,start_time FROM tbl_leave_breakup WHERE emp_code = :emp_code AND date = :date AND leave_status = 'APR' GROUP BY date", {
                  replacements: {
                    emp_code: stmt[k].emp_code,
                    date: moment(from_date, "YYYY-MM-DD").add(g, "days").format("YYYY-MM-DD"),
                  },
                  type: hrmsDB.QueryTypes.SELECT,
                });

                if (stmt11.length > 0) {
                  const { day, leave_type, start_time } = stmt11[0];
                  if (day == 0.5 && leave_type === "EL" && start_time == "09:00 AM") {
                    let elP = await saviorDB.query("SELECT hoursworked FROM tbltimeregister WHERE dateoffice BETWEEN :fromDt AND :toDate AND paycode = :emp_code ORDER BY dateoffice ASC", {
                      replacements: {
                        emp_code: stmt[k].emp_code,
                        fromDt: moment(from_date, "YYYY-MM-DD").add(g, "days").format("YYYY-MM-DD"),
                        toDate: moment(from_date, "YYYY-MM-DD").add(g, "days").format("YYYY-MM-DD"),
                      },
                      type: saviorDB.QueryTypes.SELECT,
                    });
                    if (elP[0].hoursworked >= 270) {
                      status = "EL/P";
                      el = el + 0.5;
                      present_days = present_days + 0.5;
                    } else {
                      status = "EL/A";
                      absent_days = absent_days + 0.5;
                      el = el + 0.5;
                    }
                  } else if (day == 0.5 && leave_type === "EL" && start_time == "01:30 PM") {
                    let Pel = await saviorDB.query("SELECT hoursworked FROM tbltimeregister WHERE dateoffice BETWEEN :fromDt AND :toDate AND paycode = :emp_code ORDER BY dateoffice ASC", {
                      replacements: {
                        emp_code: stmt[k].emp_code,
                        fromDt: moment(from_date, "YYYY-MM-DD").add(g, "days").format("YYYY-MM-DD"),
                        toDate: moment(from_date, "YYYY-MM-DD").add(g, "days").format("YYYY-MM-DD"),
                      },
                      type: saviorDB.QueryTypes.SELECT,
                    });
                    if (Pel[0].hoursworked >= 270) {
                      status = "P/EL";
                      el = el + 0.5;
                      present_days = present_days + 0.5;
                    } else {
                      status = "A/EL";
                      absent_days = absent_days + 0.5;
                      el = el + 0.5;
                    }
                  } else if (day === 0.5 && leave_type === "SL" && start_time == "09:00 AM") {
                    let slP = await saviorDB.query("SELECT hoursworked FROM tbltimeregister WHERE dateoffice BETWEEN :fromDt AND :toDate AND paycode = :emp_code ORDER BY dateoffice ASC", {
                      replacements: {
                        emp_code: stmt[k].emp_code,
                        fromDt: moment(from_date, "YYYY-MM-DD").add(g, "days").format("YYYY-MM-DD"),
                        toDate: moment(from_date, "YYYY-MM-DD").add(g, "days").format("YYYY-MM-DD"),
                      },
                      type: saviorDB.QueryTypes.SELECT,
                    });
                    if (slP[0].hoursworked >= 270) {
                      status = "SL/P";
                      sl = sl + 0.5;
                      present_days = present_days + 0.5;
                    } else {
                      status = "SL/A";
                      absent_days = absent_days + 0.5;
                      sl = sl + 0.5;
                    }
                  } else if (day === 0.5 && leave_type === "SL" && start_time == "01:30 PM") {
                    let Psl = await saviorDB.query("SELECT hoursworked FROM tbltimeregister WHERE dateoffice BETWEEN :fromDt AND :toDate AND paycode = :emp_code ORDER BY dateoffice ASC", {
                      replacements: {
                        emp_code: stmt[k].emp_code,
                        fromDt: moment(from_date, "YYYY-MM-DD").add(g, "days").format("YYYY-MM-DD"),
                        toDate: moment(from_date, "YYYY-MM-DD").add(g, "days").format("YYYY-MM-DD"),
                      },
                      type: saviorDB.QueryTypes.SELECT,
                    });
                    if (Psl[0].hoursworked >= 270) {
                      status = "P/SL";
                      sl = sl + 0.5;
                      present_days = present_days + 0.5;
                    } else {
                      status = "A/SL";
                      absent_days = absent_days + 0.5;
                      sl = sl + 0.5;
                    }
                  }
                  else if (day == 0.5 && leave_type === "CL" && start_time == "09:00 AM") {
                    status = "CL/P";
                    absent_days = absent_days + 0.5;
                    co = co + 0.5;
                  }
                  else if (day == 0.5 && leave_type === "CL" && start_time == "01:30 PM") {
                    status = "P/CL";
                    present_days = present_days + 0.5;
                    co = co + 0.5;
                  }
                } else {
                  status = "HD";
                  present_days = present_days + 0.5;
                  present_days = present_days + 0.5;
                }
              }
            } else if (status == "MIS") {
              status = "MIS";
              absent_days = absent_days + 1;
            } else if (status == "P") {
              present_days++;
            }
            if (status == "HLD") {
              hld++;
            }
            arr_data.push(status);
            ///////////////////////////////////////////////
          }
        }
      }

      // check from leave _breakup if above date == leave table breakup date status == APR then show status
      const totalRecords = stmt.length;
      const recordsProcessed = k + 1;
      const recordsLeft = totalRecords - recordsProcessed;
      const percentage = (recordsProcessed / totalRecords) * 100;

      // Calculate the elapsed time
      const currentTime = new Date();
      if (k === 0) {
        startTime = currentTime; // Initialize startTime only at the beginning of the loop
      }
      const elapsedTime = currentTime - startTime; // Current time - start time
      const timePerRecord = elapsedTime / recordsProcessed; // Time per record
      const estimatedTimeLeft = timePerRecord * recordsLeft;

      // Convert estimatedTimeLeft from milliseconds to a more readable format
      const estimatedTimeLeftSeconds = Math.round(estimatedTimeLeft / 1000);
      const estimatedTimeLeftMinutes = Math.floor(estimatedTimeLeftSeconds / 60);
      const estimatedTimeLeftHours = Math.floor(estimatedTimeLeftMinutes / 60);

      // Calculate remaining minutes and seconds
      const remainingMinutes = estimatedTimeLeftMinutes % 60;
      const remainingSeconds = estimatedTimeLeftSeconds % 60;

      // Format the time as "00h:00m:00s"
      const formattedTime = `${estimatedTimeLeftHours.toString().padStart(2, "0")}h:${remainingMinutes.toString().padStart(2, "0")}m:${remainingSeconds.toString().padStart(2, "0")}s`;
      io.in(uid).emit("empSvrAttend_progress", {
        percentage: percentage.toFixed(2),
        remainingTime: formattedTime,
        totalRecords: totalRecords,
        recordsProcessed: recordsProcessed,
        recordsLeft: recordsLeft,
      })
      console.log(`Progress: ${percentage.toFixed(2)}% | Remaining time: ${formattedTime} | Total Records: ${totalRecords} | Records Processed: ${recordsProcessed} | Records Left: ${recordsLeft} `);
      // }
      arr_data.push(present_days, el, sl, w_off, hld, absent_days, srt, poh, co, wfh, pow, present_days + el + sl + w_off + hld + srt + poh + co + wfh + pow);
      arr.push(arr_data);
      count++;
      const st1 = await hrmsDB.query("SELECT attend_month_for FROM tbl_attendance WHERE attend_month_for = :month ", {
        replacements: {
          month: moment(from_date, "MM-YYYY").format("YYYY-MM"),
        },
        type: hrmsDB.QueryTypes.SELECT,
      });
      // if (st1.length > 0) {
      //   await hrmsDB.query("TRUNCATE tbl_attendance")
      // }
      let st = await hrmsDB.query("INSERT INTO `tbl_attendance` (`attend_payroll`, `attend_emp_code`, `attend_month_for`, `attend_work_days`, `attend_leave_days`, `attend_ot_hrs`,`attend_night_allowance`,`attend_night_days`,`attend_arrear`,`attend_loan`,`attend_advance`, `attend_incometax`,`attend_vpf`,`attend_other_deduction`,`attend_insert_dt`,`attend_in_by`,`batch_key`,`attend_key`,`draft_attendance_status`,`attend_reimbursement`,`attend_other_earning`,`attend_medium`) VALUES(:payroll,:emp_code,:month,:work,:leave,:ot,:nig_allow,:nig_days,:arrear,:loan,:advance,:incometax,:vpf,:other_deduction,:insert_dt,:in_by,:batch_key,:key,'N',:reimbursement,:other_earning,:other_medium)", {
        replacements: {
          payroll: JSON.parse(data).payroll,
          emp_code: stmt[k].emp_code,
          month: from_date,
          work: present_days,
          leave: el + sl + co,
          ot: 0,
          nig_allow: "N",
          nig_days: 0,
          arrear: 0,
          loan: 0,
          advance: 0,
          incometax: 0,
          vpf: 0,
          other_deduction: 0,
          insert_dt: moment(from_date, "YYYY-MM-DD").format("YYYY-MM-DD"),
          in_by: uid,
          batch_key: "",
          key: helper.uniqueID(),
          reimbursement: 0,
          other_earning: 0,
          other_medium: 0
        },
        type: hrmsDB.QueryTypes.INSERT,
        transaction: t
      })
    }

    if (count == stmt.length) {
      t.commit();
      arr.unshift(arr_header);

      let randKey = Math.floor(Math.random() * (999 - 100 + 1)) + 100;
      let fileName = `SAR${randKey}.xlsx`;

      const worksheet = xlsx.utils.aoa_to_sheet(arr);
      const workbook = xlsx.utils.book_new();
      xlsx.utils.book_append_sheet(workbook, worksheet, "Savior Attendance");

      // Use xlsx.write to generate the Excel file content
      const excelBuffer = xlsx.write(workbook, { bookType: "xlsx", type: "buffer" });

      // Write the content to the file
      fs.writeFileSync(`./files/${fileName}`, excelBuffer);

      let updateStatus = await hrmsDB.query("UPDATE `user_files_req` SET `status` = 'complete', `other_data` = :other WHERE `user_id` = :uid AND `req_code` = :expression AND `module_name` = 'HRMS' AND JSON_UNQUOTE(JSON_EXTRACT(`other_data`, '$.payroll')) = :payrollValue", {
        replacements: {
          expression: expression,
          uid: uid,
          payrollValue: JSON.parse(data).payroll,
          other: JSON.stringify({
            fileName: fileName,
            fileUrl: `./files/${fileName}`,
          }),
        },
        type: hrmsDB.QueryTypes.UPDATE,
      });

      if (updateStatus.length > 0) {
        emit_hrms_notifications();
        helper.sendMail(email[0].log_email_address, null, "Savior Attendance Report", "File Downloaded Successfully", { path: `./files/${fileName}` });
        return;
      }
    }
  } catch (error) {
    console.error("Error:", error);
    // Handle the error, emit an error event, or log it as needed.
  }
};
