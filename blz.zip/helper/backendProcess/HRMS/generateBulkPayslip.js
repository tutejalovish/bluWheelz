const multer = require("multer");
const path = require("path");
const moment = require("moment");
const archiver = require("archiver");
const progress = require("progress");
const fs = require("fs");
const helper = require("./../../helper");
const html_to_pdf = require("html-pdf-node");

const { hrmsDB } = require("./../../../config/database");
exports.EmployeePayslip = async function (data, uid, emit_hrms_notifications, expression,socket) {
  const t = await hrmsDB.transaction();
  try {
    const email = await hrmsDB.query("SELECT log_email_address FROM hrms_login WHERE log_user_id = :code", {
      replacements: {
        code: uid,
      },
      type: hrmsDB.QueryTypes.SELECT,
    });

    let startTime = new Date();
    const pdfFolder = path.join(__dirname, "../../../files/" + JSON.parse(data).newFolder);
    if (!fs.existsSync(pdfFolder)) {
      fs.mkdirSync(pdfFolder);
    }

    const fromdate = moment(JSON.parse(data).period, "MM-YYYY").format("YYYY-MM");

    const getEmp = await hrmsDB.query("SELECT * FROM `tbl_final_salary` WHERE `final_salary_period` = :period AND `final_emp_payroll` = :contractor ORDER BY ID DESC", {
      replacements: { period: moment(fromdate, "YYYY-MM-DD").format("YYYY-MM"), contractor: JSON.parse(data).payroll },
      type: hrmsDB.QueryTypes.SELECT,
    });
    if (getEmp.length > 0) {
      const progressBar = new progress(":bar :current/:total", { total: getEmp.length });
      const generatedPdfFiles = [];

      for (let i = 0; i < getEmp.length; i++) {
        const emp = Buffer.from(getEmp[i].final_emp_code).toString("base64");
        const empDecoded = Buffer.from(emp, "base64").toString("utf-8");
        const payroll = Buffer.from(getEmp[i].final_emp_payroll.toString()).toString("base64");
        const month = Buffer.from(getEmp[i].final_salary_period).toString("base64");

        let stmt = await hrmsDB.query("SELECT * FROM `tbl_emp_basic` WHERE `emp_code` = :empcode", {
          replacements: { empcode: empDecoded },
          type: hrmsDB.QueryTypes.SELECT,
        });
        if (stmt.length > 0) {
          let file;
          if (stmt[0].emp_type == "BC" || stmt[0].emp_type == "GC") {
            file = {
              url: `https://hrms.mscorpres.online/app/print/payslip_worker.php?emp=${emp}&payroll=${payroll}&month=${month}`,
            };
          } else if (stmt[0].emp_type == "WC") {
            file = {
              url: `https://hrms.mscorpres.online/app/print/payslip_wc.php?emp=${emp}&payroll=${payroll}&month=${month}`,
            };
          } else {
            console.log("unconfigured collar found, contact to system administrator");
          }
          let options = { format: "A4", printBackground: true };
          await html_to_pdf
            .generatePdf(file, options)
            .then(async (pdfBuffer) => {
              const pdfFilename = path.join(pdfFolder, `${empDecoded}.pdf`);
              fs.writeFileSync(pdfFilename, pdfBuffer);
              generatedPdfFiles.push(pdfFilename);
              progressBar.tick();

              // CALCULATE PROGRESS VALUES
              const progressTotal = progressBar.total;
              const progressDone = progressBar.curr;

              // UPDATE PROGRESS
              await hrmsDB.query("UPDATE `user_files_req` SET other_data = JSON_SET( other_data, '$.progress_total', :progressTotal, '$.progress_done', :progressDone ) WHERE JSON_UNQUOTE(JSON_EXTRACT(other_data, '$.transaction'))  = :transaction", {
                replacements: {
                  progressTotal: progressTotal,
                  progressDone: progressDone,
                  transaction: JSON.parse(data).transaction,
                },
                type: hrmsDB.QueryTypes.UPDATE,
                transaction: t,
              });
            })
            .catch((err) => {
              t.rollback();
              console.log(err);
              console.log("Error while generating pdf");
            });
        } else {
          await t.rollback();
          console.log("no data found......................");
        }
        const totalRecords = getEmp.length;
        const recordsProcessed = i+1;
        const recordsLeft = totalRecords - recordsProcessed;
        const percentage = (recordsProcessed / totalRecords) * 100;

        // Calculate the elapsed time
        const currentTime = new Date();
        if (i === 0) {
          startTime = currentTime; // Initialize startTime only at the beginning of the loop
        }
        const elapsedTime = currentTime - startTime; // Current time - start time
        const timePerRecord = elapsedTime / recordsProcessed; // Time per record
        const estimatedTimeLeft = timePerRecord * recordsLeft;

        // Convert estimatedTimeLeft from milliseconds to a more readable format
        const estimatedTimeLeftSeconds = Math.round(estimatedTimeLeft / 1000);
        const estimatedTimeLeftMinutes = Math.floor(estimatedTimeLeftSeconds / 60);
        const estimatedTimeLeftHours = Math.floor(estimatedTimeLeftMinutes / 60);

        // Calculate remaining minutes and seconds
        const remainingMinutes = estimatedTimeLeftMinutes % 60;
        const remainingSeconds = estimatedTimeLeftSeconds % 60;

        // Format the time as "00h:00m:00s"
        const formattedTime = `${estimatedTimeLeftHours.toString().padStart(2, "0")}h:${remainingMinutes.toString().padStart(2, "0")}m:${remainingSeconds.toString().padStart(2, "0")}s`;
        socket.emit("genBulkPayslip", {
          percentage: percentage.toFixed(2),
          remainingTime: formattedTime,
          totalRecords: totalRecords,
          recordsProcessed: recordsProcessed,
          recordsLeft: recordsLeft,
        });
        console.log(`Progress: ${percentage.toFixed(2)}% | Remaining time: ${formattedTime} | Total Records: ${totalRecords} | Records Processed: ${recordsProcessed} | Records Left: ${recordsLeft} `);
      }

      const zipFilename = path.join(__dirname, "../../../files/" + JSON.parse(data).newFolder + ".zip");
      const output = fs.createWriteStream(zipFilename);
      const archive = archiver("zip", {
        zlib: { level: 9 },
      });
      output.on("close", async () => {
        const st = await hrmsDB.query(
          "UPDATE `user_files_req` SET `status` = 'complete', `other_data` = JSON_SET( other_data, '$.filename', :filename, '$.fileurl', :fileurl ) WHERE JSON_UNQUOTE(JSON_EXTRACT(other_data, '$.transaction')) = :transaction AND `module_name` = 'HRMS'",
          {
            replacements: {
              expression: expression,
              transaction: JSON.parse(data).transaction,
              filename: "zipFilename",
              fileurl: "urlhere",
            },
            type: hrmsDB.QueryTypes.UPDATE,
            transaction: t,
          }
        );
        if (st.length > 0) {
          helper.sendMail(email[0].log_email_address, null, "Bulk Payslip Report", "File Downloaded Successfully", { path: `./files/${zipFilename}` });
        }
        t.commit();
        emit_hrms_notifications();
        const downloadUrl = `/download?file=${encodeURIComponent(zipFilename)}`;
        console.log("Zip file generated successfully");
        return;
      });

      archive.pipe(output);

      for (const pdfFile of generatedPdfFiles) {
        archive.file(pdfFile, { name: path.basename(pdfFile) });
      }

      archive.finalize();
    } else {
      t.rollback();
      console.log("no data found--------------------------");
    }
  } catch (err) {
    t.rollback();
    console.log("Employee Payslip : ", err.stack);
    // return res.json({
    //   status: "error",
    //   msg: "ERROR",
    //   error: err.stack,
    //   code: 500,
    // });
  }
};
