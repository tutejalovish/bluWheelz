const moment = require("moment");
const fs = require("fs");
const helper = require("./../../helper");
const { verifyToken, error_log, emit_error_msg, emit_notifications, emit_hrms_notifications } = require("./../../utils");
const xlsx = require("xlsx");

const { hrmsDB, saviorDB } = require("./../../../config/database");
exports.EmployeeSalaryAttendance = async function (data, uid, emit_hrms_notifications, expression, socket) {
  const t = await hrmsDB.transaction();
  try {
    let startTime = moment(); // Record start time using moment
    const email = await hrmsDB.query("SELECT log_email_address FROM hrms_login WHERE log_user_id = :code", {
      replacements: {
        code: uid,
      },
      type: hrmsDB.QueryTypes.SELECT,
    });

    const date = JSON.parse(data).period.match(/([0-9]{2})-([0-9]{2})-([0-9]{4})/g);
    const from_date = moment(date[0], "DD-MM-YYYY").format("YYYY-MM-DD");
    const to_date = moment(date[1], "DD-MM-YYYY").format("YYYY-MM-DD");

    const days = moment(to_date).diff(moment(from_date), "days") + 1;

    let arr = [];
    await hrmsDB.query("DELETE FROM tbl_attendance WHERE attend_payroll = :payroll AND attend_month_for = :month AND attend_medium  = 'auto' AND draft_attendance_status = 'N'", {
      replacements: {
        payroll: JSON.parse(data).payroll,
        month: moment(from_date.split(" ")[0]).format("YYYY-MM"),
      },
      type: hrmsDB.QueryTypes.DELETE,
      transaction: t
    })

    const stmt = await hrmsDB.query("SELECT emp_code, CONCAT(emp_f_name,' ',emp_l_name) AS name FROM tbl_emp_basic WHERE payroll_id = :payroll  AND emp_type='WC' AND emp_status IN ('A', 'H') AND emp_join_status = 'P' ORDER BY emp_code ASC", {
      replacements: {
        payroll: JSON.parse(data).payroll,
      },
      type: hrmsDB.QueryTypes.SELECT,
    });
    stmt0 = await hrmsDB.query("SELECT `batch_key` FROM `tbl_attendance` GROUP BY `batch_key` ORDER BY LENGTH(`batch_key`) DESC, `batch_key` DESC LIMIT 0,1", {
      type: hrmsDB.QueryTypes.SELECT,
    });
    let batchCode;
    if (stmt0.length > 0) {
      batchCode = stmt0[0].batch_key;

      let strings = batchCode.replace(/[0-9]/g, "");
      let digits = (parseInt(batchCode.replace(/[^0-9]/g, "")) + 1).toString();
      if (digits.length < 3) digits = ("000" + digits).substr(-3);
      batchCode = strings + digits;
    } else {
      batchCode = "ATD001";
    }

    let stmt1;
    for (let k = 0; k < stmt.length; k++) {
      let work_day = 0;
      let leave_day = 0;

      stmt1 = await saviorDB.query(
        `SELECT CASE WHEN shiftstarttime IS NULL AND shiftendtime IS NULL THEN STATUS WHEN CONVERT( VARCHAR(8), DATEADD(SECOND, hoursworked * 60, 0), 108 ) BETWEEN '00:00:00' AND '04:29:59' THEN 'A' WHEN CONVERT( VARCHAR(8), DATEADD(SECOND, hoursworked * 60, 0), 108 ) BETWEEN '04:30:00' AND '08:44:59' THEN 'HD' WHEN CONVERT( VARCHAR(8), DATEADD(SECOND, hoursworked * 60, 0), 108 ) >= '08:45:00' THEN 'P' ELSE 'NA' END AS new_status, CONVERT( VARCHAR(8), DATEADD(SECOND, hoursworked * 60, 0), 108 ) AS total_hours FROM tbltimeregister WHERE dateoffice BETWEEN :fromDt AND :toDate AND paycode = :emp_code ORDER BY dateoffice ASC`,
        {
          replacements: {
            emp_code: stmt[k].emp_code,
            fromDt: from_date,
            toDate: to_date,
          },
          type: saviorDB.QueryTypes.SELECT,
        }
      );

      for (let d = 0; d < stmt1.length; d++) {
        let status = stmt1[d].new_status.trim();
        if (status == "A") {
          let stmt12 = await hrmsDB.query("SELECT COALESCE(SUM(day), 0) AS day, leave_type FROM tbl_leave_breakup WHERE emp_code = :emp_code  AND date = :date AND leave_status = 'APR' GROUP BY date", {
            replacements: {
              emp_code: stmt[k].emp_code,
              date: moment(from_date, "YYYY-MM-DD").add(d, "days").format("YYYY-MM-DD"),
            },
            type: hrmsDB.QueryTypes.SELECT,
          });
          if (stmt12.length > 0) {
            const { day, leave_type } = stmt12[0];
            if (day === 1 && leave_type === "SL") {
              status = "SL";
              leave_day++;
            } else if (day === 0.5 && leave_type === "SL") {
              status = "SL-HD";
              leave_day = leave_day + 0.5;
              work_day = work_day + 0.5;
            } else if (day === 1 && leave_type === "EL") {
              status = "EL";
              leave_day++;
            } else if (day === 0.5 && leave_type === "EL") {
              status = "EL-HD";
              leave_day = leave_day + 0.5;
              work_day = work_day + 0.5;
            } else if (day === 0.5 && leave_type === "WFH") {
              status = "WFH-HD";
              leave_day = leave_day + 0.5;
              work_day = work_day + 0.5;
            } else if (day === 1 && leave_type === "WFH") {
              status = "WFH";
              work_day++;
            } else if (day === 0.5 && leave_type === "CL") {
              status = "CO-HD";
              leave_day = leave_day + 0.5;
              work_day = work_day + 0.5;
            } else if (day === 1 && leave_type === "CL") {
              status = "CO";
              leave_day++;
            } else if (day === 0.25 && leave_type === "OD") {
              status = "OD-1";
              work_day++;
            } else if (day === 0.5 && leave_type === "OD") {
              status = "OD-2";
              work_day++;
            } else if (day === 0.75 && leave_type === "OD") {
              status = "OD-3";
              work_day++;
            } else if (day === 1 && leave_type === "OD") {
              status = "OD";
              work_day++;
            }
          }
        }

        if (status == "P") {
          work_day++;
        } else if (status == "A") {
          leave_day++;
        } else if (status == "WO") {
          work_day++;
        } else if (status == "HLD") {
          work_day++;
        } else if (status == "SRT") {
          leave_day++;
        }
        if (status == "HLD") {
          work_day++;
        }
        if (status == "HD") {
          leave_day = leave_day + 0.5;
          work_day = work_day + 0.5;
        }
      }
      arr.push({
        EMP_ID: stmt[k].emp_code,
        EMP_WORK_DAY: work_day,
        EMP_LEAVE_DAY: leave_day,
        EMP_WORK_HOURS: 0,
        NIGHT_ALLOWANCE: "N",
        NIGHT_DAYS: 0,
        ARREAR: 0,
        LOAN: 0,
        ADVANCE: 0,
        INCOME_TAX: 0,
        OTHER_DEDUCION: 0,
        VPF: 0,
      });


      let stmt2 = await hrmsDB.query(
        "INSERT INTO tbl_attendance(attend_payroll,attend_emp_code,attend_month_for,attend_work_days,attend_leave_days,attend_ot_hrs,attend_night_allowance,attend_night_days,attend_arrear,attend_loan,attend_advance,attend_incometax,attend_vpf,attend_other_deduction,attend_insert_dt,attend_in_by,batch_key,attend_key,draft_attendance_status,attend_reimbursement,attend_other_earning,attend_medium) VALUES(:payroll,:empcode,:month,:wday,:lday,:ofhrs,:nallow,:nday,:arrears,:loan,:advance,:itax,:vpf,:other_deduction,:insertdt,:in_by,:batch_key,:attend_key,:draft_status,:reimbursement,:other_earning,:medium)",
        {
          replacements: {
            payroll: JSON.parse(data).payroll,
            empcode: stmt[k].emp_code,
            month: moment(from_date.split(" ")[0]).format("YYYY-MM"),
            wday: work_day,
            lday: leave_day,
            ofhrs: 0,
            nallow: "N",
            nday: 0,
            arrears: 0,
            loan: 0,
            advance: 0,
            itax: 0,
            vpf: 0,
            other_deduction: 0,
            insertdt: new Date(),
            in_by: uid,
            batch_key: batchCode,
            attend_key: helper.getUniqueNumber(),
            draft_status: 'N',
            reimbursement: 0,
            other_earning: 0,
            medium: "auto"
          },
          type: hrmsDB.QueryTypes.INSERT,
          transaction: t,
        }
      );
      const totalRecords = stmt.length;
      const recordsProcessed = k + 1;
      const recordsLeft = totalRecords - recordsProcessed;
      const percentage = (recordsProcessed / totalRecords) * 100;

      // Calculate the elapsed time
      let currentTime = new Date();
      if (k === 0) {
        startTime = currentTime; // Initialize startTime only at the beginning of the loop
      }
      const elapsedTime = currentTime - startTime; // Current time - start time
      const timePerRecord = elapsedTime / recordsProcessed; // Time per record
      const estimatedTimeLeft = timePerRecord * recordsLeft;

      // Convert estimatedTimeLeft from milliseconds to a more readable format
      const estimatedTimeLeftSeconds = Math.round(estimatedTimeLeft / 1000);
      const estimatedTimeLeftMinutes = Math.floor(estimatedTimeLeftSeconds / 60);
      const estimatedTimeLeftHours = Math.floor(estimatedTimeLeftMinutes / 60);

      // Calculate remaining minutes and seconds
      const remainingMinutes = estimatedTimeLeftMinutes % 60;
      const remainingSeconds = estimatedTimeLeftSeconds % 60;

      // Format the time as "00h:00m:00s"
      const formattedTime = `${estimatedTimeLeftHours.toString().padStart(2, "0")}h:${remainingMinutes.toString().padStart(2, "0")}m:${remainingSeconds.toString().padStart(2, "0")}s`;

      socket.emit("progress_update", {
        Progress: percentage.toFixed(2),
        remaining_time: formattedTime,
        total_records: totalRecords,
        recordsProcessed: recordsProcessed,
        recordsLeft: recordsLeft,
      });
    }
    await t.commit();
    let randKey = Math.floor(Math.random() * (999 - 100 + 1)) + 100;
    let fileName = `SAR${randKey}.xlsx`;

    const worksheet = xlsx.utils.json_to_sheet(arr);
    const workbook = xlsx.utils.book_new();
    xlsx.utils.book_append_sheet(workbook, worksheet, "report data");

    // Use xlsx.write to generate the Excel file content
    const excelBuffer = xlsx.write(workbook, { bookType: "xlsx", type: "buffer" });

    // Write the content to the file
    fs.writeFileSync(`./files/${fileName}`, excelBuffer);

    let updateStatus = await hrmsDB.query("UPDATE `user_files_req` SET `status` = 'complete', `other_data` = :other WHERE `user_id` = :uid AND `req_code` = :expression AND `module_name` = 'HRMS' AND JSON_UNQUOTE(JSON_EXTRACT(`other_data`, '$.payroll')) = :payrollValue", {
      replacements: {
        expression: expression,
        uid: uid,
        payrollValue: JSON.parse(data).payroll,
        other: JSON.stringify({
          fileName: fileName,
          fileUrl: `./files/${fileName}`,
        }),
      },
      type: hrmsDB.QueryTypes.UPDATE,
    });

    if (updateStatus.length > 0) {
      emit_hrms_notifications();
      helper.sendMail(email[0].log_email_address, null, "Employee Savior Salary Attendance Report", "File Downloaded Successfully", { path: `./files/${fileName}` });
      return;
    }
  } catch (error) {
    error_log({ stack: error.stack });
  }
};