const multer = require("multer");
const path = require("path");
const moment = require("moment");
const xlsx = require("xlsx");
const helper = require("./../../helper");

const { hrmsDB } = require("./../../../config/database");

exports.EmployeeList = async function (data, uid, emit_hrms_notifications, expression,socket , io) {
  console.log("Received***********************");
  try {
    const email = await hrmsDB.query("SELECT log_email_address FROM hrms_login WHERE log_user_id = :code", {
      replacements: {
        code:  uid
      },
      type: hrmsDB.QueryTypes.SELECT,
    });

    let startTime= new Date();
    const date = JSON.parse(data).period.match(/([0-9]{2})-([0-9]{2})-([0-9]{4})/g);
    const fromdate = moment(date[0], "DD-MM-YYYY").format("YYYY-MM-DD");
    const todate = moment(date[1], "DD-MM-YYYY").format("YYYY-MM-DD");

    // if (moment(date[1], "DD-MM-YYYY").diff(moment(date[0], "DD-MM-YYYY"), "days") > "90") {
    //   socket.emit("toastr_error", {
    //     msg: "you can not download more than 90 days data",
    //   });
    //   return;
    // }

    let stmt1 = await hrmsDB.query("SELECT * FROM `tbl_emp_basic` WHERE `payroll_id` = :payroll AND DATE_FORMAT(insert_dt,'%Y-%m-%d') BETWEEN :datefrom AND :dateto", {
      replacements: {
        payroll: JSON.parse(data).payroll,
        datefrom: fromdate,
        dateto: todate,
      },
      type: hrmsDB.QueryTypes.SELECT,
    });
    // return
    if (stmt1.length > 0) {
      let result = [];
      let count = 0;
      stmt1.forEach(async (element) => {
        let stmt2 = await hrmsDB.query(
          "SELECT `tbl_emp_basic`.*, COALESCE(tbl_emp_contact.emp_emr_contact_no_1, 'N/A') AS emergency_contact_primary, COALESCE(tbl_emp_contact.emp_emr_contact_no_2, 'N/A') AS emergency_contact_secondary, `master_branch`.`branch_name`, `tbl_emp_bank`.`emp_bank_name`, `tbl_emp_bank`.`emp_bank_ifsc`, `tbl_emp_bank`.`emp_bank_ac_no`, `reporting_officer_dprt`.`department_key` AS `reporting_officer_department_key`, `reporting_officer_dprt`.`department_name` AS `reporting_officer_department_name`, `reporting_officer_des`.`designation_key` AS `reporting_officer_designation_key`, `reporting_officer_des`.`designation_name` AS `reporting_officer_designation_name`, `position_dprt`.`department_key` AS `position_department_key`, `position_dprt`.`department_name` AS `position_department_name`, `position_des`.`designation_key` AS `position_designation_key`, `position_des`.`designation_name` AS `position_designation_name`, `master_sub_department`.`sub_department_key`, `master_sub_department`.`sub_department_name`, `master_grade`.`grade_key`, `master_grade`.`grade_name`, `master_unit`.`unit_key`, `master_unit`.`unit_name`, `master_emp_type`.`emp_type_key`, `master_emp_type`.`emp_type`, `emp_amount_to_pay`.`amount_key`, `emp_amount_to_pay`.`amount`, `emp_office_data`.`emp_report_officer`, `tbl_emp_family`.`emp_father_name`, `tbl_emp_family`.`emp_mother_name`, `tbl_emp_family`.`emp_married`, `tbl_emp_family`.`emp_marriage_anniversary`, `tbl_emp_family`.`emp_spouse`, `tbl_emp_family`.`emp_child_count`, `tbl_emp_benifits`.`emp_pt`, `tbl_emp_benifits`.`emp_esi`, `tbl_emp_benifits`.`emp_uan`, `tbl_emp_benifits`.`emp_pan`, `emp_office_data`.`emp_report_hr`, `emp_office_data`.`emp_profile` FROM `tbl_emp_basic` LEFT JOIN `emp_office_data` ON `tbl_emp_basic`.`emp_code` = `emp_office_data`.`emp_code` LEFT JOIN `master_department` `reporting_officer_dprt` ON `emp_office_data`.`emp_manager_department` = `reporting_officer_dprt`.`department_key` LEFT JOIN `master_designation` `reporting_officer_des` ON `emp_office_data`.`emp_designation` = `reporting_officer_des`.`designation_key` LEFT JOIN `master_department` `position_dprt` ON `emp_office_data`.`emp_manager_department` = `position_dprt`.`department_key` LEFT JOIN `master_sub_department` ON `emp_office_data`.`emp_sub_department` = `master_sub_department`.`sub_department_key` LEFT JOIN `master_designation` `position_des` ON `emp_office_data`.`emp_designation` = `position_des`.`designation_key` LEFT JOIN `master_grade` ON `emp_office_data`.`emp_grade` = `master_grade`.`grade_key` LEFT JOIN `master_unit` ON `emp_office_data`.`emp_unit` = `master_unit`.`unit_key` LEFT JOIN `master_emp_type` ON `emp_office_data`.`emp_type` = `master_emp_type`.`emp_type_key` LEFT JOIN `emp_amount_to_pay` ON `emp_office_data`.`emp_salary_currency` = `emp_amount_to_pay`.`amount_key` LEFT JOIN `tbl_emp_family` ON `tbl_emp_family`.`emp_code` = `tbl_emp_basic`.`emp_code` LEFT JOIN `tbl_emp_benifits` ON `tbl_emp_benifits`.`emp_code` = `tbl_emp_basic`.`emp_code` LEFT JOIN `master_branch` ON `master_branch`.`branch_key` = `tbl_emp_basic`.`payroll_branch` LEFT JOIN `tbl_emp_bank` ON `tbl_emp_bank`.`emp_code` = `tbl_emp_basic`.`emp_code` LEFT JOIN tbl_emp_contact ON tbl_emp_contact.emp_code = tbl_emp_basic.emp_code WHERE `tbl_emp_basic`.`emp_code` = :employee_code",
          {
            replacements: {
              employee_code: element.emp_code,
            },
            type: hrmsDB.QueryTypes.SELECT,
          }
        );
        if (stmt2.length > 0) {
          result.push({
            EMP_CODE: stmt2[0].emp_code,
            EMP_NAME: stmt2[0].emp_f_name + " " + stmt2[0].emp_l_name,
            FATHER_NAME: stmt2[0].emp_father_name ?? "N/A",
            MOTHER_NAME: stmt2[0].emp_mother_name ?? "N/A",
            DOB: moment(stmt2[0].emp_dob, "YYYY-MM-DD").format("DD-MM-YYYY") ?? "N/A",
            DOJ: moment(stmt2[0].emp_doj, "YYYY-MM-DD").format("DD-MM-YYYY") ?? "N/A",
            GENDER: stmt2[0].emp_gender ?? "N/A",
            BLOOD_GROUP: stmt2[0].emp_blood_group ?? "N/A",
            DESIGNATION: stmt2[0].position_designation_name == null ? "N/A" : stmt2[0].position_designation_name,
            DEPARTMENT: stmt2[0].position_department_name == null ? "N/A" : stmt2[0].position_department_name,
            SUB_DPT_NAME: stmt2[0].sub_department_name == null ? "N/A" : stmt2[0].sub_department_name,
            MARRIED_STATUS: stmt2[0].emp_married ?? "N/A",
            SPOUSE_NAME: stmt2[0].emp_spouse ?? "N/A",
            PRIMARY_EMERG_CONTACT: stmt2[0].emergency_contact_primary,
            SECONDARY_EMERG_CONTACT: stmt2[0].emergency_contact_secondary,
            LOCATION: stmt2[0].branch_name ?? "N/A",
            GRADE: stmt2[0].grade_name == null ? "N/A" : stmt2[0].grade_name,
            CATEGORY: stmt2[0].emp_type == null ? "N/A" : stmt2[0].emp_type,
            ESI: stmt2[0].emp_esi ?? "N/A",
            UAN: stmt2[0].emp_uan ?? "N/A",
            AADHAAR_NO: stmt2[0].emp_aadhaar_no ?? "N/A",
            PAN: stmt2[0].emp_pan ?? "N/A",
            PT: stmt2[0].emp_pt ?? "N/A",
            BANK: stmt2[0].emp_bank_name ?? "N/A",
            IFSC: stmt2[0].emp_bank_ifsc ?? "N/A",
            AC: stmt2[0].emp_bank_ac_no ?? "N/A",
            REPORT_OFFICER: stmt2[0].emp_report_officer ?? "N/A",
            REPORT_OFFICER_DESIGNATION: stmt2[0].reporting_officer_designation_name == null ? "N/A" : stmt2[0].reporting_officer_designation_name,
            REPORTING_OFFICER_DPT: stmt2[0].reporting_officer_department_name == null ? "N/A" : stmt2[0].reporting_officer_department_name,
            REPORT_HR: stmt2[0].emp_report_hr ?? "N/A",
            JOB_PROFILE: stmt2[0].emp_profile ?? "N/A",
            STATUS:
              stmt2[0].emp_status == "A" ? "Active" : stmt2[0].emp_status == "T" ? "Terminated" : stmt2[0].emp_status == "S" ? "Suspended" : stmt2[0].emp_status == "H" ? "Hold" : stmt2[0].emp_status == "RT" ? "Retired" : stmt2[0].emp_status == "RS" ? "Resigned" : "N/A",
          });
          count++;
          const totalRecords = stmt1.length;
          const recordsProcessed = count ;
          const recordsLeft = totalRecords - recordsProcessed;
          const percentage = (recordsProcessed / totalRecords) * 100;

          // Calculate the elapsed time
          const currentTime = new Date();
          if (count === 0) {
            startTime = currentTime; // Initialize startTime only at the beginning of the loop
          }
          const elapsedTime = currentTime - startTime; // Current time - start time
          const timePerRecord = elapsedTime / recordsProcessed; // Time per record
          const estimatedTimeLeft = timePerRecord * recordsLeft;

          // Convert estimatedTimeLeft from milliseconds to a more readable format
          const estimatedTimeLeftSeconds = Math.round(estimatedTimeLeft / 1000);
          const estimatedTimeLeftMinutes = Math.floor(estimatedTimeLeftSeconds / 60);
          const estimatedTimeLeftHours = Math.floor(estimatedTimeLeftMinutes / 60);

          // Calculate remaining minutes and seconds
          const remainingMinutes = estimatedTimeLeftMinutes % 60;
          const remainingSeconds = estimatedTimeLeftSeconds % 60;

          // Format the time as "00h:00m:00s"
          const formattedTime = `${estimatedTimeLeftHours.toString().padStart(2, "0")}h:${remainingMinutes.toString().padStart(2, "0")}m:${remainingSeconds.toString().padStart(2, "0")}s`;
          io.in(uid).emit("empListProgress", {
            percentage: percentage.toFixed(2),
            remainingTime: formattedTime,
            totalRecords: totalRecords,
            recordsProcessed: recordsProcessed,
            recordsLeft: recordsLeft,
          });
          console.log(`Progress: ${percentage.toFixed(2)}% | Remaining time: ${formattedTime} | Total Records: ${totalRecords} | Records Processed: ${recordsProcessed} | Records Left: ${recordsLeft} `);
          if (stmt1.length == count) {
            const modifiedResult = result.map((obj) => {
              const modifiedObj = {};
              for (const key in obj) {
                modifiedObj[key.replace(/_/g, " ")] = obj[key];
              }
              return modifiedObj;
            });

            const worksheet = xlsx.utils.json_to_sheet(modifiedResult);

            const workbook = xlsx.utils.book_new();

            xlsx.utils.book_append_sheet(workbook, worksheet, "Employee Details");

            //buffer we use to handle the big file
            xlsx.write(workbook, { bookType: "csv", type: "buffer" });

            let randKey = Math.floor(Math.random() * (999 - 100 + 1)) + 100;

            xlsx.writeFile(workbook, "./files/masterEmpRecords" + randKey + ".xlsx");
            let fileName = `masterEmpRecords${randKey}.xlsx`;
            let stmt = await hrmsDB.query("UPDATE `user_files_req` SET `status` = 'complete', `other_data` = :other WHERE `user_id`= :uid AND `req_code` = :expression AND `module_name` = 'HRMS'", {
              replacements: {
                expression: expression,
                uid: uid,
                other: JSON.stringify({
                  fileName: fileName,
                  fileUrl: "./files/masterEmpRecords" + randKey + ".xlsx",
                }),
              },
              type: hrmsDB.QueryTypes.UPDATE,
            });
            if(stmt.length>0)
            {
              helper.sendMail(email[0].log_email_address, null, "Employee List Report", "File Downloaded Successfully", { path: `./files/${fileName}` });
            }
            emit_hrms_notifications();
            return;
          }
        }
      });
    } else {
      // no data found related to payroll id
    }
  } catch (err) {
    console.log("Employee List : ", err.stack);
    return res.json({
      status: "error",
      msg: "ERROR",
      error: err.stack,
      code: 500,
    });
  }
};
