const instances = 6380;

const axios = require('axios');
const apiToken = 'DqC7FHJi5i92FMT0r494oZFmVqVWINOkLrx49Oj5828ac763';
const config = {
    headers: {
        'Authorization': 'Bearer ' + apiToken,
        'Accept': 'application/json',
        'Content-Type': 'application/json'
    }
};

exports.send = async function ({ message, chatId }) {
    try{
    const payload = { message: message, chatId: chatId + '@c.us' };
    const response = await axios.post(`https://waapi.app/api/v1/instances/${instances}/client/action/send-message`, payload, config);
    return response?.data;
    }catch(err){
        return err
    }
}