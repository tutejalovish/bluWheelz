require("dotenv").config();

const { verifyToken, error_log } = require("./utils")
const { hrmsDB } = require("./../config/database");
const eventEmitter = require("./events")
const helper=require("./helper")
const fs = require("fs");
const path = require('path');
let activeSockets = [];
// var serialNumber = require('serial-number');

exports.myFunction = function (io) {
  io.on("connection", async (socket) => {
    try {
  
      const t=await hrmsDB.transaction();
      let st=await hrmsDB.query("SELECT holiday_name,holiday_date_from,holiday_date_to,sendMail FROM master_holiday ", {       
        type: hrmsDB.QueryTypes.SELECT,
      });
      // serialNumber(function (err, value) {
      //   console.log(value);
      //  });

      if(st.length>0){
        for(let i=0;i<st.length;i++){        
          let today=moment().format('YYYY-MM-DD');          
          if(today==moment(st[i].holiday_date_from,"YYYY-MM-DD").subtract(1, 'days').format('YYYY-MM-DD')){  
            if(st[i].sendMail=='Y'){
              return 
            } 
            let updateSt=await hrmsDB.query("UPDATE master_holiday SET sendMail='Y' WHERE holiday_date_from = :date ", {
              replacements: {
                date: st[i].holiday_name
              },
              type: hrmsDB.QueryTypes.UPDATE,
              transaction: t
            });
            if(updateSt.length>0){

            const emailRequestTemplateStr = fs.readFileSync(path.join(__dirname, "../helper/MailTemplate/holidayTemplate.html"), "utf-8");
            const personalizedTemplate = emailRequestTemplateStr.replace('<%= occasion %>', st[i].holiday_name);        
            // helper.sendMail("lovish.kumar@mscorpres.in",null,"Holiday",personalizedTemplate,null)
            await t.commit();
            }
            else{
              await t.rollback();
            }
          }
        }        
       
      }
      // let user = await verifyToken(socket.handshake.auth.token);
      // socket.join(user.crn_id);
      socket.join("MS0000");

      require("./SOCKETS/notification").notification(io, socket);
      require("./SOCKETS/HRMS/generateDraft").generateDraft(io, socket);
      require("./SOCKETS/HRMS/generateSaviorAttendance").generateSaviorAttendance(io, socket);
      require("./SOCKETS/HRMS/requestReceiver").request(io, socket);
      require("./SOCKETS/HRMS/sendBulkSms").sendBulkSms(io, socket);

      console.log("user connected");

      eventEmitter.on("attendance", (data) => {
        console.log("listening: attendance--------------------------------------------------------------", data);

        const totalRow = data.totalrows
        const currentRow = data.currentrow

        const percentage = (currentRow / totalRow) * 100;

        socket.in(data.user).emit("attendance", { ...data, percentage });
      })

      // var events = require('events');
      // var eventEmitter = new events.EventEmitter();

      // eventEmitter.on('scream', function () {
      //   console.log("scream");
      //   socket.emit('scream', 'scream');
      // })

      // setInterval(() => {
      //   eventEmitter.emit('scream');
      // }, 2000)

      // return

    }
    catch (err) {
      error_log({ stack: err.stack });
    }

  });

};
