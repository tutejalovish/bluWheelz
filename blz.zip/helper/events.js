var events = require('events');
var eventEmitter = new events.EventEmitter();

// require("./events/uploadAttendance").uploadAttendance(eventEmitter)

module.exports = eventEmitter


// setTimeout(() => {
//     console.log("events loaded" , eventEmitter.eventNames())
// },10000)