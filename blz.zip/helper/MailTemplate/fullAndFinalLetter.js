exports.generateFullAndFinalLetter = function generateFullAndFinalLetter(data) {    
    return `
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Full & Final Settlement Statement</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid black;
        }
        th, td {
            padding: 8px;
            text-align: left;
        }
        .no-border {
            border: none;
        }
    </style>
</head>
<body>
    <h2>Full & Final Settlement Statement</h2>
    <p>${data.companyName}<br>
    ${data.companyAddress}</p>

    <table>
        <tr>
            <th>Name of the employee</th>
            <td>${data.name}</td>
            <th>F&F Date</th>
            <td>${data.fullAndFinalDate}</td>
        </tr>
        <tr>
            <th>Employee ID</th>
            <td>${data.empCode}</td>
            <th>Joining Date</th>
            <td>${data.joiningDate}</td>
        </tr>
        <tr>
            <th>Designation</th>
            <td>${data.designation}</td>
            <th>Date of Resignation</th>
            <td>${data.resignationDate}</td>
        </tr>
        <tr>
            <th>Department</th>
            <td>${data.department}</td>
            <th>Date of Leaving</th>
            <td>${data.leavingDate}</td>
        </tr>
    </table>

    <h3>Salary particulars</h3>
    <table>
        <tr>
            <th>For the month</th>
            <td>${data.month}</td>
            <th>Total Days in the month</th>
            <td>${data.monthTotalDays}</td>
            <th>Paid days</th>
            <td>${data.monthPaidDays}</td>
        </tr>
    </table>

    <h3>Earnings</h3>
    <table>
        <tr>
            <th>Description</th>
            <th>Actual</th>
            <th>Earned</th>
        </tr>
        <tr>
            <td>Basic Salary</td>
            <td>${data.actualBasic}</td>
            <td>${data.earnedBasic}</td>
        </tr>
        <tr>
            <td>HRA</td>
            <td>${data.actualHra}</td>
            <td>${data.earnedHra}</td>
        </tr>
        <tr>
            <td>Education Allowance</td>
            <td>${data.actualEducationAllowance}</td>
            <td>${data.earnedEducationAllowance}</td>
        </tr>
        <tr>
            <td>Books & Periodicals</td>
            <td>${data.actualBooksAndPeriodicals}</td>
            <td>${data.earnedBooksAndPeriodicals}</td>
        </tr>
        <tr>
            <td>Mobile Allowance</td>
            <td>${data.actualMobileAllowance}</td>
            <td>${data.earnedMobileAllowance}</td>
        </tr>
        <tr>
            <td>Uniform Allowance</td>
            <td>${data.actualUniformAllowance}</td>
            <td>${data.earnedUniformAllowance}</td>
        </tr>
        <tr>
            <td>LTA</td>
            <td>${data.actualLta}</td>
            <td>${data.earnedLta}</td>
        </tr>
        <tr>
            <td>Conveyance Allowance</td>
            <td>${data.actualConveyance}</td>
            <td>${data.earnedConveyance}</td>
        </tr>
        <tr>
            <th>Total</th>
            <th>${data.actualTotal}</th>
            <th>${data.earnedTotal}</th>
        </tr>
    </table>

    <h3>Less Deductions (-)</h3>
    <table>
        <tr>
            <th>Description</th>
            <th>Amount</th>
        </tr>
        <tr>
            <td>EPF @12%</td>
            <td>${data.earnedEPF}</td>
        </tr>
        <tr>
            <td>ESIC @0.75%</td>
            <td>${data.earnedESIC}</td>
        </tr>
        <tr>
            <td>Medical Insurance</td>
            <td>${data.medicalInsurance}</td>
        </tr>
        <tr>
            <td>Other Deduction</td>
            <td>${data.otherDeduction}</td>
        </tr>
        
        <tr>
            <td>Salary advance</td>
            <td>${data.salaryAdvance}</td>
        </tr>
        <tr>
            <td>Notice Deduction (${data.noticePeriodDeductionDays})</td>
            <td>${data.noticeDeduction}</td>
        </tr>
        <tr>
            <td>Leave (Negative)</td>
            <td>${data.leaveNegative}</td>
        </tr>
        <tr>
            <th>Total Deductions</th>
            <th>${data.totalDeduction}</th>
        </tr>
    </table>

    <h3>Other Earnings</h3>
    <table>
        <tr>
            <th>Description</th>
            <th>Eligibility Period</th>
            <th>Amount</th>
        </tr>
        <tr>
            <td>Leave encashment (Days)</td>
            <td>${data.leaveDays}</td>
            <td>${data.earnedLeaveEncashment}</td>
        </tr>
        <tr>
            <td>Gratuity (Years)</td>
            <td>${data.gratuityYears}</td>
            <td>${data.earnedGratuity}</td>
        </tr>
        <tr>
            <td>Incentives if any</td>
            <td>0</td>
            <td>0</td>
        </tr>
        <tr>
            <td>Reimbursement</td>
            <td>${data.reimbursement}</td>
            <td>${data.reimbursementEncashment}</td>
        </tr>
        <tr>
        <td>Arrear</td>
        <td>--</td>
        <td>${data.arrears}</td>
        </tr>
         <tr>
        <td>Bonus</td>
        <td>--</td>
        <td>${data.bonus}</td>
        </tr>
         <tr>
        <td>Notice Pay</td>
        <td>--</td>
        <td>${data.noticePay}</td>
        </tr>
        <tr>
            <th>Total</th>
            <th colspan="2">${data.otherEarnings}</th>
        </tr>
    </table>

    <h3>Net Payable (Rs)</h3>
    <table>
        <tr>
            <th>Net Payable</th>
            <td>${data.netPayable}</td>
        </tr>
        <tr>
            <th>Amount in Words</th>
            <td>${data.amountInWords}</td></td>
        </tr>
    </table>

    <h3>Prepared By:</h3>
    <table class="no-border">
        <tr>
            <td class="no-border">Prepared By: _________________</td>
            <td class="no-border">Verified By: ___________________</td>
            <td class="no-border">Approved By: ___________________</td>
        </tr>
    </table>

    <h3>Declaration</h3>
    <p>I ______________, received full and final settlement of my account with the company and confirm that nothing is due from the company.</p>

    <table class="no-border">
        <tr>
            <td class="no-border">Signature: ___________________</td>
            <td class="no-border">Date: ___________________</td>
        </tr>
    </table>
</body>
</html>
`;
}

