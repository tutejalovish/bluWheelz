const dns = require("dns");
require("dotenv").config();
const moment = require("moment");
const nodemailer = require("nodemailer");
const crypto = require("crypto");
const uuid = require("uuid");
const { hrmsDB } = require("../config/database");
const { default: axios } = require("axios");
exports.RSAEncryption = function () {
  const crypto = require("crypto");

  const { privateKey, publicKey } = crypto.generateKeyPairSync("rsa", {
    modulusLength: 4096,
    publicKeyEncoding: {
      type: "pkcs1",
      format: "pem",
    },
    privateKeyEncoding: {
      type: "pkcs8",
      format: "pem",
    },
    secureOptions: crypto.constants.SSL_OP_NO_TLSv1,
  });

  return { privateKey, publicKey };
};

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: process.env.SMTP_PORT,
  secure: process.env.SMTP_SECURE,
  auth: {
    user: process.env.SMTP_USERID,
    pass: process.env.SMTP_USERPASS,
  },
});

exports.getOs = function (req) {
  var ua = req.headers["user-agent"],
    $ = {};

  if (/mobile/i.test(ua)) $.Mobile = true;

  if (/like Mac OS X/.test(ua)) {
    $.iOS = /CPU( iPhone)? OS ([0-9\._]+) like Mac OS X/.exec(ua)[2].replace(/_/g, ".");
    $.iPhone = /iPhone/.test(ua);
    $.iPad = /iPad/.test(ua);
  }

  if (/Android/.test(ua)) $.Android = /Android ([0-9\.]+)[\);]/.exec(ua)[1];

  if (/webOS\//.test(ua)) $.webOS = /webOS\/([0-9\.]+)[\);]/.exec(ua)[1];

  if (/(Intel|PPC) Mac OS X/.test(ua)) $.Mac = /(Intel|PPC) Mac OS X ?([0-9\._]*)[\)\;]/.exec(ua)[2].replace(/_/g, ".") || true;

  if (/Windows NT/.test(ua)) $.Windows = /Windows NT ([0-9\._]+)[\);]/.exec(ua)[1];

  return $;
};

exports.getIp = function (req) {
  return req.headers["x-forwarded-for"] || req.connection.remoteAddress;
};

exports.getBrowser = function (req) {
  var ua = req.headers["user-agent"],
    $ = {};

  if (/MSIE|Trident/.test(ua)) $.name = "Internet Explorer";
  else if (/Firefox/.test(ua)) $.name = "Firefox";
  else if (/Chrome/.test(ua)) $.name = "Chrome";
  else if (/Safari/.test(ua)) $.name = "Safari";
  else if (/Opera/.test(ua)) $.name = "Opera";
  else if (/OPR/.test(ua)) $.name = "Opera";
  else if (/Edge/.test(ua)) $.name = "Edge";
  else if (/Yandex/.test(ua)) $.name = "Yandex";
  else if (/Konqueror/.test(ua)) $.name = "Konqueror";
  else if (/CriOS/.test(ua)) $.name = "Chrome";
  else if (/rv:11/.test(ua)) $.name = "IE";
  else $.name = "Unknown";

  if (/Trident/.test(ua)) $.version = /rv:([0-9\.]+)/.exec(ua)[1];
  else if (/MSIE/.test(ua)) $.version = /MSIE ([0-9\.]+)/.exec(ua)[1];
  else if (/Firefox/.test(ua)) $.version = /Firefox\/([0-9\.]+)/.exec(ua)[1];
  else if (/Chrome/.test(ua)) $.version = /Chrome\/([0-9\.]+)/.exec(ua)[1];
  else if (/OPR/.test(ua)) $.version = /OPR\/([0-9\.]+)/.exec(ua)[1];
  else if (/Yandex/.test(ua)) $.version = /Yandex\/([0-9\.]+)/.exec(ua)[1];
  else if (/Konqueror/.test(ua)) $.version = /Konqueror\/([0-9\.]+)/.exec(ua)[1];
  else if (/Safari/.test(ua)) $.version = /Version\/([0-9\.]+)/.exec(ua)[1];
  else if (/CriOS/.test(ua)) $.version = /CriOS\/([0-9\.]+)/.exec(ua)[1];
  else if (/Edge/.test(ua)) $.version = /Edge\/([0-9\.]+)/.exec(ua)[1];
  else $.version = "Unknown";

  if ($.name == "IE") {
    $.version = $.version.split(".")[0];
  }

  return $;
};

// random number generator
exports.randomNumber = function (min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
};

// Convert DOC TO PDF
exports.convertDocToPdf = async function (file) {  
  
  
    if (file) {
      const convertToPdf = await axios.post(
        "https://apisite.in/doc-to-pdf/convert",
        {
          url: file,
          isProtected: 0,
        },
        {
          headers: {
            Authorization: "123",
          },
        }
      );
      return convertToPdf.data.data.filePath.split("/")[1];
    }
};

// GET UNIQUE NUMBER [23-08-2023]
exports.getUniqueNumber = function () {
  const uuidWithoutHyphens = uuid.v4().replace(/-/g, ""); // Generate UUID and remove hyphens
  return uuidWithoutHyphens;
};

//Generate Unique 5 digit code
exports.generateUniqueFiveDigitCode=function() {
  // Generate a UUID and convert it to a base-10 integer
  const uniqueNo = uuid.v4().replace(/[^0-9]/g, '');  
  // Extract the Last 5 digits from the integer
  return parseInt(uniqueNo.substring(uniqueNo.length - 5), 10);
};

//FILE SIZE [27-08-2022]
exports.fileSize = function (bytes, decimalPoint) {
  if (bytes == 0) return "0 Bytes";
  var k = 1000,
    dm = decimalPoint || 2,
    sizes = ["Bytes", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"],
    i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + " " + sizes[i];
};

// 15-07-2022
//transporter.verify().then(console.log).catch(console.error);
exports.sendMail = async function (to, cc = null, subject, message, attachments = null) {
  let mail_res;

  mail_res = await transporter
    .sendMail({
      from: process.env.SMTP_USERNAME + " " + process.env.SMTP_USERID,
      to: to,
      cc: cc,
      subject: subject,
      html: message,
      attachments: attachments,
    })
    .then((info) => {
      return {
        code: 200,
        messageId: info.messageId,
      };
    })
    .catch((err) => {
      return {
        code: 500,
        error: err,
      };
    });
  return mail_res;
};

// 18-07-2022
exports.truncateWithEllipse = function (text, max) {
  return text.substr(0, max - 1) + (text.length > max ? "..." : "");
};

exports.random_color = function () {
  let letters = "0123456789ABCDEF";
  let color = "#";
  for (let i = 0; i < 6; i++) {
    color += letters[Math.floor(Math.random() * 16)];
  }
  return color;
};

exports.amount_to_word = function (amountInDigits) {
  const numberToWords = (num) => {
      const singleDigits = ["", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine"];
      const twoDigits = ["Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"];
      const tensMultiple = ["", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"];
      const placeValues = ["", "Thousand", "Lac", "Crore"];

      if (num === 0) {
          return "Zero";
      }

      if (num > 999999999) {
          return "Number too large";
      }

      const convertHundreds = (n) => {
          let result = "";
          if (n > 99) {
              result += singleDigits[Math.floor(n / 100)] + " Hundred ";
              n %= 100;
          }
          if (n > 19) {
              result += tensMultiple[Math.floor(n / 10)] + " " + singleDigits[n % 10];
          } else if (n >= 10) {
              result += twoDigits[n - 10];
          } else if (n > 0) {
              result += singleDigits[n];
          }
          return result.trim();
      };

      const getWords = (num) => {
          let result = "";
          let placeIndex = 0;

          while (num > 0) {
              let part = 0;

              // Handle thousands and above
              if (placeIndex === 1 || placeIndex === 2) {
                  part = num % 100;
                  num = Math.floor(num / 100);
              } else {
                  part = num % 1000;
                  num = Math.floor(num / 1000);
              }

              if (part > 0) {
                  let partWord = convertHundreds(part);
                  if (placeIndex > 0) {
                      partWord += " " + placeValues[placeIndex];
                  }
                  result = partWord + " " + result;
              }
              placeIndex++;
          }

          return result.trim();
      };

      return getWords(num);
  };

  return numberToWords(amountInDigits);
};


exports.saveLogs = async function (db, message, req, transaction) {
  let result = await db
    .query("INSERT INTO `ims_invt_loggers` ( `logger_key`, `insert_date`, `insert_by`, `message`) VALUES (:log_key, :insert_key, :insert_by, :message)", {
      replacements: {
        log_key: exports.getUniqueNumber(),
        insert_key: new Date(),
        insert_by: req.logedINUser,
        message: message,
      },
      transaction: transaction,
      type: db.QueryTypes.INSERT,
    })
    .then(function (result) {
      if (result.length > 0) {
        return true;
      } else {
        throw "Insertion Of Loggers is failed";
      }
    })
    .catch(function (err) {
      console.log("Error in save log ", err);
      return false;
    });
  return result;
};

exports.checkLeaveBackDays = async function (req) {
  const leaveDay = req.body.day;
  const currentYear = moment().format("YYYY");
  const leaveDayYear = moment(leaveDay, "DD-MM-YYYY").format("YYYY");

  if (parseInt(leaveDayYear) !== parseInt(currentYear)) {
    return { valid: false, message: "leave can't be applied based on the previous year" };
  }

  const settings = await hrmsDB.query("SELECT setting_leave FROM tbl_project_setting WHERE setting_session = :currentYear", {
    replacements: {
      currentYear: currentYear,
    },
    type: hrmsDB.QueryTypes.SELECT,
  });

  if (settings.length === 0) {
    return false;
  }

  try {
    const leaveSettings = JSON.parse(settings[0].setting_leave);
    const leaveType = req.body.type;
    if (leaveSettings[leaveType]) {
      return leaveSettings[leaveType].days;
    } else {
      return false;
    }
  } catch (error) {
    return false;
  }
};

// 18-09-2022
exports.mxValidation = function (email) {
  return new Promise((resolve, reject) => {
    const domain = email.split("@")[1];
    dns.resolveMx(domain, (err, addresses) => {
      if (err) {
        if (err.code === "ENOTFOUND") {
          resolve(false); // Domain not found, return false
        } else {
          reject(err); // Other DNS resolution errors
        }
      } else if (addresses && addresses.length > 0) {
        resolve(true); // MX record found, return true
      } else {
        resolve(false); // No MX record found, return false
      }
    });
  });
};

/*const isValidMX = await exports.mxValidation(email);
if (isValidMX) {
  console.log(`Email ${email} has valid MX records.`);
} else {
  console.log(`Email ${email} does not have valid MX records.`);
}*/
// 20-09-2022

exports.strCharValid = (str) => {
  const arr = ["'", "`", ":"];
  for (let i = 0; i < arr.length; i++) {
    if (str.indexOf(arr[i]) >= 0) {
      return `character that you have mentioned as [ ${arr[i]} ] not accepted`;
    }
  }
  return true;
};

exports.getIcon = (filename) => {
  let icon = "file";
  let ext = filename.split(".").pop();
  if (ext == "pdf") {
    icon = "file-pdf";
  } else if (ext == "jpg" || ext == "jpeg" || ext == "png") {
    icon = "file-image";
  } else if (ext == "csv" || ext == "xlsx") {
    icon = "file-excel";
  } else if (ext == "zip" || ext == "rar") {
    icon = "file-archive";
  }
  return icon;
};

exports.calculateDateOfBirth = (dob) => {
  // Convert the input date to a Moment object in India time zone.
  const dateTime = moment.tz(dob, "DD-MM-YYYY", "Asia/Kolkata");

  // Get the current date in India time zone.
  const currentDate = moment.tz("Asia/Kolkata");

  // Calculate the difference in years between the input date and the current date.
  const yearsDifference = currentDate.diff(dateTime, "years");

  return yearsDifference;
};

exports.number = (number) => {
  if (typeof number === "string") {
    number = Number(number);
  }

  if (number % 1 !== 0) {
    // Convert the decimal value to fixed(2)
    number = Math.round(number * 100) / 100;
  } else {
    // No decimal value, so just return the number
    number = Math.floor(number);
  }

  return number;
};

exports.uniqueID = () => {
  var now = new Date();
  var formattedDate = now.getFullYear().toString().slice(-2) + ("0" + (now.getMonth() + 1)).slice(-2) + ("0" + now.getDate()).slice(-2) + ("0" + now.getHours()).slice(-2) + ("0" + now.getMinutes()).slice(-2);
  var randomDigits = Math.floor(1000000 + Math.random() * 9000000);
  var uniqueID = "SLR" + formattedDate + randomDigits;
  return uniqueID;
};

exports.formatter = (str) => {
  const words = str.toLowerCase().split(" ");
  const convertedWords = words.map((word) => {
    if (word.length <= 2) {
      return word.toUpperCase();
    } else {
      return word.charAt(0).toUpperCase() + word.slice(1);
    }
  });
  return convertedWords.join(" ");
};

exports.calculateDateDifference = (olddate) => {
  const now = moment();
  const oldDateObj = moment(olddate, "DD-MM-YYYY");

  const years = now.diff(oldDateObj, "years");
  oldDateObj.add(years, "years");

  const months = now.diff(oldDateObj, "months");
  oldDateObj.add(months, "months");

  const days = now.diff(oldDateObj, "days");

  return `${years} years, ${months} months & ${days} days`;
};

exports.removeWhitespace = (inputString) => {
  return inputString.trim().replace(/\s+/g, "");
};

exports.validate_date = (dateString) => {
  // Regular expression for DD-MM-YYYY format
  const regex = /^(0[1-9]|[12][0-9]|3[01])-(0[1-9]|1[0-2])-\d{4}$/;
  return regex.test(dateString);
};

exports.calculateExperience = (doj, dol) => {
  const dojDate = moment(doj, "DD-MM-YYYY");
  const dolDate = moment(dol, "DD-MM-YYYY");

  const experience = moment.duration(dolDate.diff(dojDate));

  const years = experience.years();
  const months = experience.months();
  const days = experience.days();

  return `${years}Y, ${months}M & ${days}D`;
};

//GENERATE PASSWORD
exports.generatePassword = (specialCharacters) => {
  const characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789" + (specialCharacters ? "@#$_&" : "");
  let password = "";
  for (let i = 0; i < Math.floor(Math.random() * 20) + 8; i++) {
    password += characters[Math.floor(Math.random() * characters.length)];
  }

  // Make sure the password contains at least one uppercase letter, lowercase letter, and number.
  while (!password.match(/[A-Z]/) || !password.match(/[a-z]/) || !password.match(/[0-9]/)) {
    password = "";
    for (let i = 0; i < Math.floor(Math.random() * 20) + 8; i++) {
      password += characters[Math.floor(Math.random() * characters.length)];
    }
  }

  return password;
};

// TIME AGO
exports.timeAgo = (dateTime) => {
  const now = new Date();
  const timestamp = new Date(dateTime);

  const timeDiff = now - timestamp;
  const seconds = Math.floor(timeDiff / 1000);

  if (seconds < 60) {
    return "just now";
  }

  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) {
    return `${minutes} minute${minutes === 1 ? "" : "s"} ago`;
  }

  const hours = Math.floor(minutes / 60);
  if (hours < 24) {
    return `${hours} hour${hours === 1 ? "" : "s"} ago`;
  }

  const days = Math.floor(hours / 24);
  if (days < 7) {
    return `${days} day${days === 1 ? "" : "s"} ago`;
  }

  const weeks = Math.floor(days / 7);
  if (weeks < 4) {
    return `${weeks} week${weeks === 1 ? "" : "s"} ago`;
  }

  const months = Math.floor(days / 30);
  if (months < 12) {
    return `${months} month${months === 1 ? "" : "s"} ago`;
  }

  const years = Math.floor(days / 365);
  return `${years} year${years === 1 ? "" : "s"} ago`;
};

// Google Recaptcha Verification
exports.verifyRecaptcha = async function (recaptchaResponse) {
  try {
    const { data } = await google.recaptcha("v3").siteVerify({
      secret: process.env.RECAPTCHA_SECRET_KEY,
      response: recaptchaResponse,
    });
    return data.success;
  } catch (error) {
    console.error("Error verifying reCAPTCHA:", error);
    return false;
  }
};

exports.firstErrorValidatorjs = (obj) => {
  return Object.values(obj.errors.all())[0][0];
};

exports.crashRes = (res, err, { routeName }, transaction = null) => {
  if (transaction) {
    transaction.rollback();
  }
  let errorMessage = "We're Sorry<br/>An unexpected error has occured. Our technical staff has been automatically notified and will be looking into this with utmost urgency.";
  if (process.env.NODE_ENV === "DEV") {
    console.log(err);
    errorMessage += ` Details: ${err.stack}`;
  }

  return res.json({ success: false, status: "error", message: errorMessage });
};

exports.formateNumber = (type, number) => {
  // Remove spaces from the number
  const numStr = number.toString().replace(/\s+/g, "");

  // Check the type of number and format accordingly
  if (type === "aadhaar") {
    // Check if the number has 12 digits
    if (numStr.length === 12) {
      // Format the number as XXXX XXXX XXXX
      return `${numStr.slice(0, 4)} ${numStr.slice(4, 8)} ${numStr.slice(8)}`;
    }
  } else if (type === "mobile") {
    // Check if the number has 10 digits
    if (numStr.length === 10) {
      // Format the number as XXX XXX XXXX
      return `${numStr.slice(0, 3)} ${numStr.slice(3, 6)} ${numStr.slice(6)}`;
    }
  }

  // Return '--' for invalid number or type
  return "--";
};

exports.calculateAge = (dateString) => {
  const dateRegex = /^\d{4}-\d{2}-\d{2}$/; // Regular expression for YYYY-MM-DD format

  // Check if the input date matches the required format
  if (!dateRegex.test(dateString)) {
    return "--";
  }

  const today = new Date();
  const birth = new Date(dateString);

  let age = today.getFullYear() - birth.getFullYear();
  const m = today.getMonth() - birth.getMonth();
  const d = today.getDate() - birth.getDate();

  if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) {
    age--;
    const birthMonthAdjusted = today.getMonth() + (12 - birth.getMonth());
    age += birthMonthAdjusted >= 12 ? 1 : 0;
  }

  const years = age;
  const months = (today.getMonth() - birth.getMonth() + 12) % 12;
  const days = (today.getDate() - birth.getDate() + 30) % 30;

  return `${years} yrs and ${months} m and ${days} days`;
};

//Aadhaar Authentication
const d = [
  [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
  [1, 2, 3, 4, 0, 6, 7, 8, 9, 5],
  [2, 3, 4, 0, 1, 7, 8, 9, 5, 6],
  [3, 4, 0, 1, 2, 8, 9, 5, 6, 7],
  [4, 0, 1, 2, 3, 9, 5, 6, 7, 8],
  [5, 9, 8, 7, 6, 0, 4, 3, 2, 1],
  [6, 5, 9, 8, 7, 1, 0, 4, 3, 2],
  [7, 6, 5, 9, 8, 2, 1, 0, 4, 3],
  [8, 7, 6, 5, 9, 3, 2, 1, 0, 4],
  [9, 8, 7, 6, 5, 4, 3, 2, 1, 0],
];

const p = [
  [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
  [1, 5, 7, 6, 2, 8, 3, 0, 9, 4],
  [5, 8, 0, 3, 7, 9, 6, 1, 4, 2],
  [8, 9, 1, 6, 0, 4, 3, 5, 2, 7],
  [9, 4, 5, 3, 1, 2, 6, 8, 7, 0],
  [4, 2, 8, 6, 5, 7, 3, 9, 0, 1],
  [2, 7, 9, 3, 8, 0, 6, 4, 1, 5],
  [7, 0, 4, 6, 9, 1, 3, 2, 5, 8],
];

function AadhaarInvArray(array) {
  if (Object.prototype.toString.call(array) === "[object Number]") {
    array = String(array);
  }
  if (Object.prototype.toString.call(array) === "[object String]") {
    array = array.split("").map(Number);
  }
  return array.reverse();
}

function AadhaarValidate(array) {
  var c = 0;
  var invertedArray = AadhaarInvArray(array);
  for (var i = 0; i < invertedArray.length; i++) {
    c = d[c][p[i % 8][invertedArray[i]]];
  }
  return c === 0;
}

exports.validateAadhaar = function (aadhaarNumber) {
  let reg = /^\d+$/;
  let disallowedAadhaar = "123412341234";
  let uid = aadhaarNumber.trim().replace(/\s+/g, "");

  // Check if Aadhaar number is 12 digits and contains only digits
  if (uid.length === 12 && reg.test(uid)) {
    if (disallowedAadhaar === uid) {
      return false;
    } else {
      return true;
    }
  } else {
    return false;
  }
};

exports.slugify = function (str) {
  str = str.replace(/^\s+|\s+$/g, ""); // trim leading/trailing white space
  str = str.toLowerCase(); // convert string to lowercase
  str = str
    .replace(/[^a-z0-9 -]/g, "") // remove any non-alphanumeric characters
    .replace(/\s+/g, "-") // replace spaces with hyphens
    .replace(/-+/g, "-"); // remove consecutive hyphens
  return str;
};

exports.reversalSlug = function (thisID) {
  return thisID.replace(/-/g, " ").replace(/\b[a-z]/g, function () {
    return arguments[0].toUpperCase();
  });
};

// Insert Activity Logs
exports.updateRecord = async function updateRecord(module, currentTable, rowID, existingVersion, insertBy, insertDate, uniqueKey, title, transaction = null) {
  try {
    const uniqueId = helper.getUniqueNumber();
    await hrmsDB.query(`INSERT INTO update_log (module, table_name, table_row, old_version, insert_date, insert_by, unique_key, update_title) VALUES (:module, :tableName, :rowID, :oldVersion, :insertDate, :insertBy, :uniqueKey, :title)`, {
      replacements: {
        module: module,
        tableName: currentTable,
        rowID: rowID,
        oldVersion: JSON.stringify(existingVersion),
        insertDate: insertDate,
        insertBy: insertBy,
        uniqueKey: uniqueKey,
        title: title,
      },
      type: hrmsDB.QueryTypes.INSERT,
      transaction: transaction ? transaction : null,
    });

    return uniqueId; // will use in future
  } catch (error) {
    console.error("Error while saving activity logs:", error);
  }
};

exports.emailValidation = function (email_address, callback) {
  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  if (!emailPattern.test(email_address)) {
    return callback({
      code: 500,
      status: "error",
      message: { msg: "Invalid email format" },
    });
  }

  const domain = email_address.split("@")[1];

  dns.resolve(domain, "MX", (err, addresses) => {
    if (err || !addresses || addresses.length === 0) {
      return callback({
        code: 500,
        status: "error",
        message: { msg: "Invalid or non-existent DNS/MX records" },
      });
    }
    callback({
      code: 200,
      status: "success",
      message: { msg: "Email validation successful" },
    });
  });
};
