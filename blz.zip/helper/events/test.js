
exports.test = (eventEmitter) => {

    // setInterval(() => {
    //     eventEmitter.emit("attendance", "hello world")
    // },2000)
    
}