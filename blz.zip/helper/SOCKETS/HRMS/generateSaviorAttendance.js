const { hrmsDB, saviorDB } = require("../../../config/database");

const jwt = require("jsonwebtoken");
const moment = require("moment");
const helper = require("../../helper");
const { verifyToken, error_log, emit_error_msg, emit_notifications } = require("../../utils");

exports.generateSaviorAttendance = function (io, socket) {
  socket.on("generate_savior_attendance", async (reqData) => {
    let user_token = await verifyToken(`${socket.handshake.auth.token}`);

    const t = await hrmsDB.transaction();

    const insertTimeDt = moment(new Date()).format("YYYY-MM-DD HH:mm:ss");

    try {
      await hrmsDB.query("TRUNCATE TABLE attendance");

      let stmt0 = await hrmsDB.query(
        "SELECT tbl_emp_basic.*, COALESCE( tbl_emp_family.emp_father_name, 'N/A' ) AS father_name, master_payroll.payroll_full_name, master_payroll.payroll_office_address, master_payroll.payroll_gstin, master_payroll.payroll_pan, master_branch.branch_name FROM `tbl_emp_basic` LEFT JOIN `tbl_emp_family` ON `tbl_emp_family`.`emp_code` = `tbl_emp_basic`.`emp_code` LEFT JOIN master_payroll ON master_payroll.payroll_key = tbl_emp_basic.payroll_id LEFT JOIN master_branch ON master_branch.branch_key = tbl_emp_basic.payroll_branch WHERE tbl_emp_basic.emp_status IN ('A', 'H') AND tbl_emp_basic.payroll_id = :payroll AND tbl_emp_basic.emp_join_status = 'P' ORDER BY tbl_emp_basic.emp_code ASC LIMIT 10",
        {
          replacements: {
            payroll: reqData.payroll
          },
          type: hrmsDB.QueryTypes.SELECT,
        }
      );

      if (stmt0.length == 0) {
        await t.rollback();
        socket.emit("toastr_error", {
          msg: "an internal error occured, try after sometime",
        });
        return;
      }

      let startTime = new Date(); // Record the start time
      for (let i = 0; i < stmt0.length; i++) {
        let stmt1 = await saviorDB.query(
          "SELECT paycode, ISNULL(CONVERT(varchar, dateoffice, 105) + ' ' + CONVERT(varchar, dateoffice, 108), '--') AS date_formatted, shiftstarttime, shiftendtime, ISNULL(CONVERT(varchar, in1, 105) + ' ' + CONVERT(varchar, in1, 108), '--') AS in1_formatted, ISNULL(CONVERT(varchar, out2, 105) + ' ' + CONVERT(varchar, out2, 108), '--') AS out2_formatted, ISNULL(DATENAME(dw, dateoffice), '--') AS day, ISNULL(CASE WHEN in1 IS NOT NULL AND out2 IS NOT NULL THEN CONVERT(varchar, DATEADD(SECOND, DATEDIFF(SECOND, in1, out2), 0), 108) ELSE '' END, '--') AS total_time, otduration,shift, shiftattended, status AS savior_status, CASE WHEN status = 'MIS' THEN 'MIS' WHEN in1 IS NULL AND out1 IS NULL THEN STATUS WHEN CONVERT(VARCHAR(8), DATEADD(SECOND, DATEDIFF(SECOND, in1, out2), 0), 108) BETWEEN '00:00:00' AND '04:29:59' THEN 'A' WHEN CONVERT(VARCHAR(8), DATEADD(SECOND, DATEDIFF(SECOND, in1, out2), 0), 108) BETWEEN '04:30:00' AND '08:44:59' THEN 'HD' WHEN CONVERT(VARCHAR(8), DATEADD(SECOND, DATEDIFF(SECOND, in1, out2), 0), 108) >= '08:45:00' THEN 'P' ELSE 'NA' END AS policy_status FROM tbltimeregister WHERE paycode = :empcode AND CONVERT(VARCHAR(7), dateoffice, 120) = :month ORDER BY dateoffice ASC",
          {
            replacements: {
              empcode: stmt0[i].emp_code,
              month: moment(reqData.period, "YYYY-MM").format("YYYY-MM"),
            },
            type: saviorDB.QueryTypes.SELECT,
          }
        );
        // if (stmt1.length == 0) {
        //   await t.rollback();
        //   socket.emit("toastr_error", {
        //     msg: "no punches found"
        //   });
        //   return;
        // }
        if (stmt1.length > 0) {
          // Sort stmt1 based on the difference between total_time and 8 hours
          stmt1.sort((a, b) => {
            const diffA = Math.abs(moment.duration(a.total_time).asHours() - 8);
            const diffB = Math.abs(moment.duration(b.total_time).asHours() - 8);
            return diffA - diffB;
          });
          for (let j = 0; j < stmt1.length; j++) {
            // GET LEAVE TAKEN
            let leave_taken = 0, leave_type = 'N/A';
            let stmt2 = await hrmsDB.query("SELECT SUM(day) as day, leave_type FROM tbl_leave_breakup WHERE date = :date AND emp_code = :empcode AND leave_status = 'APR' GROUP BY leave_type", {
              replacements: {
                date: moment(stmt1[j].date_formatted, "DD-MM-YYYY HH:mm:ss").format("YYYY-MM-DD"),
                empcode: stmt1[j].paycode.trim(),
              },
              type: hrmsDB.QueryTypes.SELECT,
            });
            if (stmt2.length > 0) {
              leave_taken += stmt2[0].day;
              leave_type = stmt2[0].leave_type;
            }

            // Condition to determine row.status
            if (stmt1[j].in1_formatted === '--' && stmt1[j].out2_formatted === '--' && leave_type !== 'N/A') {
              stmt1[j].status = leave_type;
            } else {
              stmt1[j].status = stmt1[j].status;
            }

            // Determine if SRT or HD based on total_time
            let attendance_status = stmt1[j].policy_status;
            if (stmt1[j].total_time > '08:00:00' && stmt1[j].total_time < '09:00:00' && stmt1[j].policy_status === 'HD') {
              let srtCountQuery = await hrmsDB.query("SELECT COUNT(*) as count FROM attendance WHERE emp_code = :empcode AND attendance_status = 'SRT' AND DATE_FORMAT(attendance_date, '%Y-%m') = :currentMonth", {
                replacements: {
                  empcode: stmt1[j].paycode.trim(),
                  currentMonth: moment(reqData.period, "YYYY-MM").format("YYYY-MM"),
                },
                type: hrmsDB.QueryTypes.SELECT,
              });
              let srtCount = srtCountQuery[0].count;

              if (srtCount < 3) {
                attendance_status = 'SRT';
              } else {
                attendance_status = 'HD';
              }
            }

            // INSERT QUERY HERE
            let stmt3 = await hrmsDB.query("INSERT INTO attendance (emp_code, shiftstarttime, shiftendtime, in1, out2, hoursworked, otworked, shift, shiftattended, attendance_status, attendance_date, attendance_day, row_status, insert_by, insert_dt) VALUES (:empcode, :shiftstarttime, :shiftendtime, :in1, :out2, :hoursworked, :otworked, :shift, :shiftattended, :attendance_status, :attendance_date, :attendance_day, :row_status, :insert_by, :insert_dt)", {
              replacements: {
                empcode: stmt1[j].paycode.trim(),
                shiftstarttime: stmt1[j].shiftstarttime ?? "--",
                shiftendtime: stmt1[j].shiftendtime ?? "--",
                in1: stmt1[j].in1_formatted,
                out2: stmt1[j].out2_formatted,
                hoursworked: stmt1[j].total_time == '' ? "0" : stmt1[j].total_time,
                otworked: stmt1[j].otduration == '' ? "0" : stmt1[j].otduration,
                shift: stmt1[j].shift,
                shiftattended: stmt1[j].shiftattended,
                attendance_status: attendance_status,
                attendance_date: moment(stmt1[j].date_formatted, "DD-MM-YYYY HH:mm:ss").format("YYYY-MM-DD HH:mm:ss"),
                attendance_day: stmt1[j].day,
                row_status: "OK",
                insert_by: user_token.crn_id,
                insert_dt: insertTimeDt,
              },
              type: hrmsDB.QueryTypes.INSERT,
              transaction: t
            });

            console.log("==============");
            const totalRecords = stmt0.length;
            const recordsProcessed = i + 1;
            const recordsLeft = totalRecords - recordsProcessed;
            const percentage = (recordsProcessed / totalRecords) * 100;

            // Calculate the elapsed time
            const currentTime = new Date();
            const elapsedTime = currentTime - startTime;
            const timePerRecord = elapsedTime / recordsProcessed;
            const estimatedTimeLeft = timePerRecord * recordsLeft;
            // Convert estimatedTimeLeft from milliseconds to a more readable format
            const estimatedTimeLeftSeconds = Math.round(estimatedTimeLeft / 1000);
            const estimatedTimeLeftMinutes = Math.floor(estimatedTimeLeftSeconds / 60);
            const estimatedTimeLeftHours = Math.floor(estimatedTimeLeftMinutes / 60);
            // Calculate remaining minutes and seconds
            const remainingMinutes = estimatedTimeLeftMinutes % 60;
            const remainingSeconds = estimatedTimeLeftSeconds % 60;
            // Format the time as "00h:00m:00s"
            const formattedTime = `${estimatedTimeLeftHours.toString().padStart(2, '0')}h:${remainingMinutes.toString().padStart(2, '0')}m:${remainingSeconds.toString().padStart(2, '0')}s`;

            console.log(`Progress: ${percentage.toFixed(2)}% | Remaining time: ${formattedTime} | Total Records: ${totalRecords} | Records Processed: ${recordsProcessed} | Records Left: ${recordsLeft} `,);
            console.log("==============");
            socket.emit("progress_update", {
              progress: percentage.toFixed(2),
              remainingTime: formattedTime,
              totalRecords: totalRecords,
              recordsProcessed: recordsProcessed,
              recordsLeft: recordsLeft,
              recordsRow: `Date of : ${moment(stmt1[j].date_formatted, "DD-MM-YYYY HH:mm:ss").format("DD-MM-YYYY")} | status : Processed | Employee : ${stmt1[j].paycode.trim()} | `
            })
          }
        }
      }
      await t.commit();
      socket.emit("toastr_success", {
        msg: "Attendance generated successfully",
      });
      return;
    } catch (err) {
      await t.rollback();
      socket.emit("toastr_error", {
        msg: "an error occurred while generating attendance draft - " + err.stack,
      });

      error_log({ stack: err.stack });

      return;
    }
  });

};
