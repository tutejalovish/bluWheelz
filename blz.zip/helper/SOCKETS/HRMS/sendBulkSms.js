const jwt = require("jsonwebtoken");
const moment = require("moment");
const helper = require("../../helper");
const { verifyToken, error_log, emit_error_msg, emit_notifications } = require("../../utils");
const { hrmsDB } = require("../../../config/database");
const wpHelper = require('../../../helper/wpHelper');

exports.sendBulkSms = function (io, socket) {
    socket.on("send_bulk_sms", async (reqData) => {

        let user_token = await verifyToken(`${socket.handshake.auth.token}`);
        const userId = user_token.crn_id;

        try {

            let totalTime = 0;

            const stmt = await hrmsDB.query("SELECT * FROM wp_send_msg WHERE campaign = :campaign AND send_status = 'PENDING' ", {
                replacements: {
                    campaign: reqData.campaign
                },
                type: hrmsDB.QueryTypes.SELECT,
            });

            if (stmt.length > 0) {

                for (let i = 0; i < stmt.length; i++) {

                    const timer = Math.random() * (90000 - 30000) + 30000;
                    totalTime += timer;

                    setTimeout(async () => {

                        const response = await wpHelper.send({ message: stmt[i].wp_message, chatId: "91"+stmt[i].wp_number });

                        const stmt2 = await hrmsDB.query("UPDATE wp_send_msg SET send_status = 'SEND' , sent_time = :time WHERE ID = :ID ", {
                            replacements: {
                                ID: stmt[i].ID,
                                time: moment(new Date()).format("YYYY-MM-DD HH:mm:ss")
                            }
                        });

                        // console.log(response)

                        // 
                        const totalRecords = stmt.length;
                        const recordsProcessed = i + 1;
                        const recordsLeft = totalRecords - recordsProcessed;
                        const percentage = (recordsProcessed / totalRecords) * 100;

                        // Calculate the elapsed time
                        const currentTime = new Date();
                        if (i === 0) {
                            startTime = currentTime; // Initialize startTime only at the beginning of the loop
                        }
                        const elapsedTime = currentTime - startTime; // Current time - start time

                        // 

                        io.in(`${userId}`).emit("bulk_sms_status", {
                            percentage: percentage.toFixed(2),
                            remainingTime: moment.utc(elapsedTime).format('HH:mm:ss'),
                            totalRecords: totalRecords,
                            recordsProcessed: recordsProcessed,
                            recordsLeft: recordsLeft,
                            totalTime: moment.utc(totalTime).format('HH:mm:ss')
                        })

                    }, i * timer);

                }

            }

        }
        catch (err) {
            socket.emit("toastr_error", {
                msg: "an error occurred while generating salary draft - " + err.stack,
            });
            error_log({ stack: err.stack });
        }

    });
}