const { hrmsDB } = require("../../../config/database");
const fs = require('fs');
const path = require('path');

const jwt = require("jsonwebtoken");
const moment = require("moment");
const helper = require("../../helper");
const { verifyToken, error_log, emit_error_msg, emit_notifications } = require("../../utils");
const outputFilePath = path.join(__dirname, 'salary_draft.txt'); // Path to the output text file

exports.generateDraft = function (io, socket) {
  socket.on("generate_draft", async (reqData) => {

    try {
      let startTime;
      let user_token = await verifyToken(`${socket.handshake.auth.token}`);
      const userId = user_token.crn_id;


      let stmt0 = await hrmsDB.query(
        "SELECT `paid_emp_payroll`, `paid_salary_period`, `salary_draft_batch` FROM `tbl_draft_salary` WHERE `paid_salary_period` = :period AND `paid_emp_payroll` = :payroll  ORDER BY `ID`  DESC LIMIT 1",
        {
          replacements: {
            payroll: reqData.payroll,
            period: moment(reqData.period, "YYYY-MM").format("YYYY-MM"),
            type: reqData.type,
          },
          type: hrmsDB.QueryTypes.SELECT,
        },
      );

      if (stmt0.length > 0) {
        socket.emit("toastr_error", {
          msg: "payroll preview is already generated, delete all the draft and generate again",
        });
        return;
      }

      let t1 = await hrmsDB.transaction();

      let stmt1 = await hrmsDB.query(
        "SELECT tbl_emp_collar.collar_id, tbl_emp_collar.collar_name, master_branch.branch_key, master_branch.branch_name, master_payroll.payroll_key, master_payroll.payroll_name FROM `tbl_attendance` LEFT JOIN tbl_emp_basic ON tbl_emp_basic.emp_code = tbl_attendance.attend_emp_code LEFT JOIN master_branch ON tbl_emp_basic.payroll_branch = master_branch.branch_key LEFT JOIN tbl_emp_collar ON tbl_emp_basic.emp_type = tbl_emp_collar.collar_id LEFT JOIN master_payroll ON master_payroll.payroll_key = tbl_emp_basic.payroll_id WHERE tbl_attendance.attend_month_for = :period AND tbl_attendance.attend_payroll = :payroll GROUP BY tbl_emp_basic.payroll_branch, tbl_emp_basic.emp_type",
        {
          replacements: {
            payroll: reqData.payroll,
            period: moment(reqData.period, "YYYY-MM").format("YYYY-MM"),
          },
          type: hrmsDB.QueryTypes.SELECT,
        },
      );
      if (stmt1.length > 0) {
        let headerWritten = false;

        for (let i = 0; i < stmt1.length; i++) {
          let checkSalaryCloseStatus = await hrmsDB.query(
            "SELECT `final_emp_payroll`, `final_salary_period` FROM `tbl_final_salary` WHERE `final_salary_period` = :period AND `final_emp_payroll` = :payroll  ORDER BY `ID` DESC LIMIT 1",
            {
              replacements: {
                payroll: reqData.payroll,
                period: moment(reqData.period, "YYYY-MM").format("YYYY-MM"),
                type: reqData.type,
              },
              type: hrmsDB.QueryTypes.SELECT,
            },
          );

          if (checkSalaryCloseStatus.length > 0) {
            socket.emit("toastr_error", {
              msg: "payroll has already finalized the salaries of the period you are trying to manage, to do the operation again, pls delete all the data related to the selected payroll from final logs and generate again..",
            });
            return;
          }

          let stmt2 = await hrmsDB.query(
            "SELECT `salary_draft_batch` FROM `tbl_draft_salary` GROUP BY `salary_draft_batch` ORDER BY `ID` DESC LIMIT 1 FOR UPDATE",
            {
              type: hrmsDB.QueryTypes.SELECT,
              transaction: t1,
            },
          );

          let batchCode;
          if (stmt2.length > 0) {
            batchCode = stmt2[0].salary_draft_batch;

            let strings = batchCode.replace(/[0-9]/g, "");
            let digits = (
              parseInt(batchCode.replace(/[^0-9]/g, "")) + 1
            ).toString();
            if (digits.length < 6) digits = ("0" + digits).substr(-6);
            batchCode = strings + digits;
          } else {
            batchCode = "SLRDFT01";
          }

          let stmt3 = await hrmsDB.query(
            "SELECT t1.*, tbl_emp_basic.emp_type, tbl_emp_basic.payroll_branch AS branch, tbl_emp_basic.emp_join_status, DAY(LAST_DAY(:lastdate)) -( SELECT attend_work_days FROM tbl_attendance WHERE attend_emp_code = t1.attend_emp_code AND attend_month_for = :period ORDER BY ID DESC LIMIT 1 ) AS ncp_day FROM tbl_attendance t1 JOIN( SELECT MAX(ID) AS maxID, attend_month_for FROM tbl_attendance WHERE `attend_payroll` = :payroll AND `attend_month_for` = :period GROUP BY `attend_emp_code` ) t2 ON t1.attend_month_for = t2.attend_month_for AND t1.ID = t2.maxID LEFT JOIN tbl_emp_basic ON tbl_emp_basic.emp_code = t1.attend_emp_code WHERE tbl_emp_basic.payroll_branch = :branch AND tbl_emp_basic.emp_type = :type AND tbl_emp_basic.emp_status IN ('A', 'H') AND DATE_FORMAT(tbl_emp_basic.emp_doj, '%Y-%m') <= :period ORDER BY tbl_emp_basic.ID",
            {
              replacements: {
                payroll: reqData.payroll,
                branch: stmt1[i].branch_key,
                type: stmt1[i].collar_id,
                period: moment(reqData.period, "YYYY-MM").format("YYYY-MM"),
                lastdate: moment(reqData.period, "YYYY-MM")
                  .endOf("month")
                  .format("YYYY-MM-DD"),
              },
              type: hrmsDB.QueryTypes.SELECT,
            },
          );

          if (stmt3.length > 0) {
            let month_data = await hrmsDB.query(
              "SELECT COALESCE( SUM(DATEDIFF( LEAST(LAST_DAY(holiday_date_from), holiday_date_to), GREATEST(DATE(CONCAT(YEAR(holiday_date_from), '-', MONTH(holiday_date_from), '-01')), holiday_date_from) ) + 1), 0) AS total_holiday, COALESCE(master_month.month_weekend, 0) AS total_sunday, DAY(LAST_DAY(CONCAT(input_month.month_to_check, '-01'))) AS total_days_in_month FROM ( SELECT :period AS month_to_check ) AS input_month LEFT JOIN master_holiday ON DATE_FORMAT(holiday_date_from, '%Y-%m') = input_month.month_to_check LEFT JOIN master_month ON master_month.session = input_month.month_to_check GROUP BY input_month.month_to_check",
              {
                replacements: {
                  period: moment(reqData.period, "YYYY-MM").format("YYYY-MM")
                },
                type: hrmsDB.QueryTypes.SELECT,
              },
            );

            if (month_data.length == 0) {
              socket.emit("toastr_error", {
                msg: "an error occurred while fetching the month data from reference resource",
              });
              return;
            }

            for (let item of stmt3) {
              //CHECK SALARY STRUCTURE FOR THAT EMPLOYEE
              let stmt4 = await hrmsDB.query(
                "SELECT * FROM `tbl_emp_salary` WHERE `emp_code` = :emp_code AND `emp_payroll` = :payroll ORDER BY ID DESC LIMIT 1",
                {
                  replacements: {
                    emp_code: item.attend_emp_code,
                    payroll: item.attend_payroll,
                  },
                  type: hrmsDB.QueryTypes.SELECT,
                },
              );
              if (stmt4.length > 0) {
                for (let j = 0; j < stmt4.length; j++) {
                  //ACTUAL BREAKUP
                  let basic = helper.number(stmt4[j].salary_basic),
                    hra = helper.number(stmt4[j].salary_hra),
                    da = helper.number(stmt4[j].salary_da),
                    conv_reimbursement = helper.number(stmt4[j].salary_conv_reimb),
                    actual_edu_allowance = helper.number(stmt4[j].salary_edu_allowance),
                    book_periodicals = helper.number(stmt4[j].salary_books_periodicals),
                    mobile_reimbursement = helper.number(stmt4[j].salary_mobile_reimb),
                    uniform_allowance = helper.number(stmt4[j].salary_uniform_allowance),
                    stipned_amt = helper.number(stmt4[j].salary_stipned_amt),
                    ita_amt = helper.number(stmt4[j].salary_lta),
                    actual_gross =
                      basic +
                      hra +
                      da +
                      conv_reimbursement +
                      actual_edu_allowance +
                      book_periodicals +
                      mobile_reimbursement +
                      uniform_allowance +
                      stipned_amt +
                      ita_amt;

                  //OVER TIME CALCULATION
                  let over_time = item.attend_ot_hrs,
                    incentive = helper.number(item.attend_ot_hrs / 2),
                    incentive_amt = Math.round(
                      (actual_gross / 30 / 8) *
                      helper.number(incentive * 2) *
                      1.25,
                    );

                  //PAID BREAKUP
                  let paid_basic = helper.number(
                    (basic /
                      moment(reqData.period, "YYYY-MM").daysInMonth()) *
                    item.attend_work_days,
                  ),
                    paid_hra = helper.number(
                      (hra / moment(reqData.period, "YYYY-MM").daysInMonth()) *
                      item.attend_work_days,
                    ),
                    paid_da = helper.number(
                      (da / moment(reqData.period, "YYYY-MM").daysInMonth()) *
                      item.attend_work_days,
                    ),
                    paid_conv_reimbursement = helper.number(
                      (conv_reimbursement /
                        moment(reqData.period, "YYYY-MM").daysInMonth()) *
                      item.attend_work_days,
                    ),
                    edu_allowance = helper.number(
                      (helper.number(stmt4[j].salary_edu_allowance) /
                        moment(reqData.period, "YYYY-MM").daysInMonth()) *
                      item.attend_work_days,
                    ),
                    book_periodical = helper.number(
                      (helper.number(stmt4[j].salary_books_periodicals) /
                        moment(reqData.period, "YYYY-MM").daysInMonth()) *
                      item.attend_work_days,
                    ),
                    mobile_reimb = helper.number(
                      (helper.number(stmt4[j].salary_mobile_reimb) /
                        moment(reqData.period, "YYYY-MM").daysInMonth()) *
                      item.attend_work_days,
                    ),
                    salary_uni_allowance = helper.number(
                      (helper.number(stmt4[j].salary_uniform_allowance) /
                        moment(reqData.period, "YYYY-MM").daysInMonth()) *
                      item.attend_work_days,
                    ),
                    salary_stipend = helper.number(
                      (helper.number(stmt4[j].salary_stipned_amt) /
                        moment(reqData.period, "YYYY-MM").daysInMonth()) *
                      item.attend_work_days,
                    ),
                    salary_lta = helper.number(
                      (helper.number(stmt4[j].salary_lta) /
                        moment(reqData.period, "YYYY-MM").daysInMonth()) *
                      item.attend_work_days,
                    ),
                    paid_gross = Math.round(
                      paid_basic +
                      paid_hra +
                      paid_da +
                      paid_conv_reimbursement +
                      edu_allowance +
                      book_periodical +
                      mobile_reimb +
                      salary_uni_allowance +
                      salary_stipend +
                      salary_lta +
                      incentive_amt,
                    ),
                    bonus = helper.number(
                      paid_basic + paid_da > 21000
                        ? 0
                        : Math.round((paid_basic + paid_da) * (8.33 / 100)),
                    ),
                    salary_loan = helper.number(item.attend_loan),
                    salary_other_deduction = helper.number(
                      item.attend_other_deduction,
                    ),
                    salary_income_tax = helper.number(item.attend_incometax),
                    salary_arrear = helper.number(item.attend_arrear),
                    salary_advance = helper.number(item.attend_advance);

                  //EMPLOYER CONTRIBUTION
                  let employer_wages =
                    Math.round(paid_basic + paid_da) <= 15000
                      ? Math.round(paid_basic + paid_da)
                      : 15000,
                    employer_epf_contribution = employer_wages <= 15000
                      ? helper.number(
                        employer_wages *
                        helper.number(
                          stmt4[j].employer_epf_contribution / 100
                        )
                      )
                      : 1800,
                    employer_eps_contribution = Math.round(
                      employer_wages * (stmt4[j].employer_eps / 100),
                    ),
                    employer_epf_eps_diff_remitted = helper.number(
                      employer_epf_contribution - employer_eps_contribution,
                    ),
                    employer_edli = Math.round(
                      employer_wages * (stmt4[j].employer_edli / 100),
                    ),
                    employer_pf_admin = Math.round(
                      employer_wages * (stmt4[j].employer_admin_charg / 100),
                    ),
                    employer_esi =
                      actual_gross >= 21000
                        ? 0
                        : Math.round(
                          (paid_gross * stmt4[j].employer_esi) / 100,
                        ),
                    employer_insurance = stmt4[j].employer_insurance,
                    employer_gross = Math.round(
                      employer_eps_contribution +
                      employer_epf_eps_diff_remitted +
                      employer_edli +
                      employer_pf_admin +
                      employer_insurance +
                      employer_esi,
                    ),
                    employer_ctc = Math.round(paid_gross + employer_gross);

                  //EMPLOYEE CONTRIBUTION
                  let employee_pf = Math.round(
                    employer_wages * (stmt4[j].employee_pf / 100),
                  ),
                    employee_esi =
                      actual_gross > 21000
                        ? 0
                        : Math.ceil(
                          paid_gross * (stmt4[j].employee_esi / 100),
                        ),
                    employee_vpf = helper.number(item.attend_vpf),
                    employee_gross = Math.round(employee_pf + employee_esi);

                  // LEAVE ENCASHMENT
                  let leave_encashment = Math.round(
                    (actual_gross / 26) * item.attend_leave_days,
                  );

                  // NIGHT ALLOWANCE [1000 is Fixed Value]
                  let night_alw = Math.round(
                    (1000 / (month_data[0].total_days_in_month - (helper.number(month_data[0].total_sunday) + helper.number(month_data[0].total_holiday)))) * item.attend_night_days
                  );

                  //TAKE HOME
                  let take_home = Math.round(paid_gross - employee_gross);
                  let line = `${item.attend_emp_code} | basic = ${basic} +
                      hra = ${hra}+
                      da = ${da}+
                      conv_reimbursement = ${conv_reimbursement} +
                      actual_edu_allowance = ${edu_allowance} +
                      book_periodicals  = ${book_periodicals} +
                      mobile_reimbursement = ${mobile_reimbursement} +
                      uniform_allowance   = ${uniform_allowance} +
                      stipned_amt   = ${stipned_amt} +
                      ita_amt = ${ita_amt} = ${actual_gross} | paid_basic = ${paid_basic} +
                      paid_hra  = ${paid_hra} +
                      paid_da   = ${paid_da} +
                      paid_conv_reimbursement = ${paid_conv_reimbursement} +
                      edu_allowance = ${edu_allowance} +
                      book_periodical = ${book_periodical} +
                      mobile_reimb       = ${mobile_reimbursement} +
                      salary_uni_allowance   = ${salary_uni_allowance} +
                      salary_stipend  = ${salary_stipend} +
                      salary_lta  = ${salary_lta} +
                      incentive_amt  = ${incentive_amt} = ${paid_gross} | Incentive = ${helper.number(actual_gross / 30 / 8)} * ${helper.number(incentive * 2)} * 1.25\n\n`;

                  // Write to the file
                  if (!headerWritten) {
                    fs.writeFileSync(outputFilePath, "EMP CODE  |    Actual Gross  | Paid Gross\n", 'utf8');
                    headerWritten = true;
                  }
                  fs.appendFileSync(outputFilePath, line, 'utf8');
                  let insert_stmt = await hrmsDB.query(
                    "INSERT INTO `tbl_draft_salary`(`paid_er_wages`,`paid_ee_vpf`,`paid_emp_ncp_days`,`paid_salary_code`, `paid_emp_attendance`, `paid_income_tax`, `paid_ee_loan`,`paid_ee_other_deduction`,`paid_ee_advance`,`paid_ee_arrear` , `emp_type`, `paid_emp_night_alw`, `paid_emp_leave_encmnt`, `paid_bonus`, `paid_emp_branch`, `paid_take_home`, `paid_incentive`, `salary_draft_batch`, `paid_salary_period`, `paid_emp_payroll`, `paid_emp_code`, `paid_basic`, `paid_da`, `paid_hra`, `paid_edu_allowance`, `paid_books_periodicals`, `paid_mobile_reimb`, `paid_uniform_allowance`, `paid_lta`, `paid_conv_reimb`, `paid_stipned_amt`, `paid_er_epf`, `paid_er_eps`, `paid_er_edli`, `paid_er_admin_amt`, `paid_er_insurance`, `paid_er_esi`, `paid_ee_pf`, `paid_ee_esi`, `paid_salary_insert_dt`, `paid_salary_insert_by`, `paid_payroll_status`, `paid_other_data` ) VALUES(:epf_wages,:vpf,:ncp_day, :salary_code, :attendance_code, :income_tax, :loan, :other_deduction, :advance, :arrear, :type, :night_alw, :leave_encmnt, :bonus, :branch, :takehome, :incentive, :batch, :period, :payroll, :emp_code, :paid_basic, :paid_da, :paid_hra, :edu_allw, :book_perd, :mobile_remb, :uniform_allw, :lta, :paid_conv_reimbursement, :salary_stipend_amt, :employer_epf_contribution, :employer_eps, :employer_edli, :employer_admin_charg, :employer_insurance, :employer_esi, :employee_pf, :employee_esi, :insert_dt, :insert_by, :payroll_status, :other )",
                    {
                      replacements: {
                        epf_wages:
                          stmt4[j].salary_compliance_status == "Y"
                            ? employer_wages
                            : 0,
                        vpf: employee_vpf,
                        ncp_day: item.ncp_day ?? 0,
                        salary_code: stmt4[j].salary_code,
                        attendance_code: item.attend_key,
                        type: item.emp_type,
                        night_alw: night_alw,
                        leave_encmnt: leave_encashment,
                        bonus: bonus,
                        branch: item.branch,
                        takehome: take_home,
                        incentive: incentive_amt,
                        batch: batchCode,
                        period: moment(reqData.period, "YYYY-MM").format(
                          "YYYY-MM",
                        ),
                        payroll: stmt4[j].emp_payroll,
                        emp_code: stmt4[j].emp_code,

                        //PAID BREAKUP
                        paid_basic: paid_basic,
                        paid_hra: paid_hra,
                        paid_da: paid_da,
                        paid_conv_reimbursement: paid_conv_reimbursement,

                        //EMPLOYER CONTRIBUTION
                        employer_epf_contribution:
                          item.emp_join_status == 'T' ? 0 : stmt4[j].salary_compliance_status == "Y"
                            ? employer_epf_contribution
                            : 0,
                        employer_eps:
                          stmt4[j].salary_compliance_status == "Y"
                            ? employer_eps_contribution
                            : 0,
                        employer_edli:
                          stmt4[j].salary_compliance_status == "Y"
                            ? employer_edli
                            : 0,
                        employer_esi:
                          item.emp_join_status == 'T' ? 0 : stmt4[j].salary_compliance_status == "Y"
                            ? employer_esi
                            : 0,
                        employer_insurance: employer_insurance,
                        employer_admin_charg:
                          stmt4[j].salary_compliance_status == "Y"
                            ? employer_pf_admin
                            : 0,

                        //EMPLOYEE CONTRIBUTION
                        employee_pf:
                          item.emp_join_status == 'T' ? 0 : stmt4[j].salary_compliance_status == "Y"
                            ? employee_pf
                            : 0,
                        employee_esi:
                          item.emp_join_status == 'T' ? 0 : stmt4[j].salary_compliance_status == "Y"
                            ? employee_esi
                            : 0,

                        edu_allw: edu_allowance,
                        book_perd: book_periodical,
                        mobile_remb: mobile_reimb,
                        uniform_allw: salary_uni_allowance,
                        lta: salary_lta,
                        salary_stipend_amt: salary_stipend,
                        income_tax: salary_income_tax,
                        loan: salary_loan,
                        other_deduction: salary_other_deduction,
                        advance: salary_advance,
                        arrear: salary_arrear,
                        insert_dt: moment(new Date())
                          .tz("Asia/Kolkata")
                          .format("YYYY-MM-DD HH:mm:ss"),
                        insert_by: userId,
                        payroll_status: "A",
                        other: JSON.stringify({
                          work_day: item.attend_work_days,
                          work_hour: item.attend_ot_hrs,
                          batch: item.batch_key,
                          key: item.attend_key,
                        }),
                      },
                      type: hrmsDB.QueryTypes.INSERT,
                      transaction: t1,
                    },
                  );

                  // check from leave _breakup if above date == leave table breakup date status == APR then show status

                  const totalRecords = stmt1.length;
                  const recordsProcessed = i + 1;
                  const recordsLeft = totalRecords - recordsProcessed;
                  const percentage = (recordsProcessed / totalRecords) * 100;

                  // Calculate the elapsed time
                  const currentTime = new Date();
                  if (i === 0) {
                    startTime = currentTime; // Initialize startTime only at the beginning of the loop
                  }
                  const elapsedTime = currentTime - startTime; // Current time - start time
                  const timePerRecord = elapsedTime / recordsProcessed; // Time per record
                  const estimatedTimeLeft = timePerRecord * recordsLeft;

                  // Convert estimatedTimeLeft from milliseconds to a more readable format
                  const estimatedTimeLeftSeconds = Math.round(estimatedTimeLeft / 1000);
                  const estimatedTimeLeftMinutes = Math.floor(estimatedTimeLeftSeconds / 60);
                  const estimatedTimeLeftHours = Math.floor(estimatedTimeLeftMinutes / 60);

                  // Calculate remaining minutes and seconds
                  const remainingMinutes = estimatedTimeLeftMinutes % 60;
                  const remainingSeconds = estimatedTimeLeftSeconds % 60;

                  // Format the time as "00h:00m:00s"
                  const formattedTime = `${estimatedTimeLeftHours.toString().padStart(2, '0')}h:${remainingMinutes.toString().padStart(2, '0')}m:${remainingSeconds.toString().padStart(2, '0')}s`;

                  console.log(`Progress: ${percentage.toFixed(2)}% | Remaining time: ${formattedTime} | Total Records: ${totalRecords} | Records Processed: ${recordsProcessed} | Records Left: ${recordsLeft} `,);

                  socket.emit("generate_draft_progress", {
                    percentage: percentage.toFixed(2),
                    remainingTime: formattedTime,
                    totalRecords: totalRecords,
                    recordsProcessed: recordsProcessed,
                    recordsLeft: recordsLeft,
                  })


                }
              } else {
                await t1.rollback();
                socket.emit("toastr_error", {
                  msg:
                    "an error occurred while fetching salary structure for employee code (" +
                    item.attend_emp_code +
                    ")",
                });
                return;
              }
            } // Loop 2 ENDS
          } else {
            // nothing found
          }
        } // LOOP 1 ENDS
      } else {
        // nothing found
      }

      await t1.commit();
      socket.emit("toastr_success", {
        msg: "payroll draft generated successfully",
      });
      return;
    } catch (err) {
      socket.emit("toastr_error", {
        msg: "an error occurred while generating salary draft - " + err.stack,
      });
      error_log({ stack: err.stack });
    }
  });

};
