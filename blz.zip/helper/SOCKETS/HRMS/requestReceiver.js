const { EmployeeAttendance, automateAttendance } = require("./../../backendProcess/HRMS/csv_EmployeeAttendance");
const { BankTransfer } = require("./../../backendProcess/HRMS/csv_BankTransafer");
const { EmployeeList } = require("./../../backendProcess/HRMS/csv_EmployeeList");
const { EmployeePayslip } = require("./../../backendProcess/HRMS/generateBulkPayslip");
const { EmployeeAssets } = require("./../../backendProcess/HRMS/csv_EmployeeeAssets");
const { EmployeeSalaryAttendance } = require("./../../backendProcess/HRMS/generate_SaviorImportAttendance");
const {EmployeeBonus}=require("./../../backendProcess/HRMS/csv_EmployeeBonus")
const jwt = require("jsonwebtoken");
const moment = require("moment");
const helper = require("./../../helper");
const { verifyToken, error_log, emit_error_msg, emit_notifications, emit_hrms_notifications } = require("./../../utils");

const { hrmsDB } = require("../../../config/database");

exports.request = function (io, socket) {


  socket.on("generate_report_list", async (data) => {

        console.log("Genaerate data",data)
    try {

      const referenceID = helper.getUniqueNumber();
      const existingData = JSON.parse(data.otherdata);
      const newData = {
        newFolder: helper.getUniqueNumber(),
        transaction: referenceID,
        progress_total: 0,
        progress_done: 0,
        filename: "",
        fileurl: "",
      };

      const updatedData = { ...existingData, ...newData };
      const updatedOtherData = JSON.stringify(updatedData);
      data.otherdata = updatedOtherData;

      let check = await verifyToken(`${socket.handshake.auth.token}`);

      const myexpression = JSON.parse(data.otherdata).type;

      let check_data = await hrmsDB.query("SELECT * FROM `user_files_req` WHERE `user_id`= :uid AND `req_code` = :expression AND req_date = :date AND `status` = 'pending'", {
        replacements: {
          expression: myexpression,
          uid: check.crn_id,
          date: JSON.parse(data.otherdata).period,
        },
        type: hrmsDB.QueryTypes.SELECT,
      });

      if (check_data.length > 0) {
        socket.emit("toastr_error", {
          msg: "your previous request is already in pending, please wait until it is completed...",
        });
        return;
      }

      await hrmsDB.query(
        "INSERT INTO `user_files_req` ( `module_name`, `request_txt_label`,  `req_code`, `user_id` , `req_date`, `msg_type` , `status` , `other_data`, `insert_date` ) VALUES ('HRMS', :label, :expression, :uid, :req_date ,'file','pending', :other, :insert_date) ",
        {
          replacements: {
            label:
              myexpression == "emp_master"
                ? "Employee Master"
                : myexpression == "emp_bonus"
                  ? "Employee Bonus"
                  : myexpression == "bank_trn"
                    ? "Bank Transfer Sheet"
                    : myexpression == "emp_attendance"
                      ? "Employee Attendance"
                      : myexpression == "employee_payslip"
                        ? "Employee Payslip"
                        : myexpression == "emp_assets"
                        ? "Bonus Report"
                        : myexpression=="bonusReport"
                          ? "Employee Assets"
                          : myexpression == "emp_savior"
                            ? "Employee Automate Attendance"
                            : myexpression == "savior_salary_attendance"
                              ? "Salary Attendance" : "--",
            expression: myexpression,
            uid: check.crn_id,
            req_date: JSON.parse(data.otherdata).period,
            other: data.otherdata,
            insert_date: moment().format("YYYY-MM-DD HH:mm:ss"),
          },
          type: hrmsDB.QueryTypes.INSERT,
        }
      );

      switch (myexpression) {
        case "emp_master":
          await EmployeeList(data.otherdata, check.crn_id, emit_hrms_notifications, myexpression, socket, io);
          break;

      

        case "bank_trn":
          await BankTransfer(data.otherdata, check.crn_id, emit_hrms_notifications, myexpression, socket, io);
          break;

        case "emp_attendance":
          await EmployeeAttendance(data.otherdata, check.crn_id, emit_hrms_notifications, myexpression, socket, io);
          break;

        case "employee_payslip":
          await EmployeePayslip(data.otherdata, check.crn_id, emit_hrms_notifications, myexpression, socket, io);
          break;

        case "emp_assets":
          await EmployeeAssets(data.otherdata, check.crn_id, emit_hrms_notifications, myexpression, socket, io);
          break;

        case "emp_savior":
          await automateAttendance(data.otherdata, check.crn_id, emit_hrms_notifications, myexpression, socket, io);
          break;

        case "savior_salary_attendance":
          await EmployeeSalaryAttendance(data.otherdata, check.crn_id, emit_hrms_notifications, myexpression, socket, io);
          break;

        case "bonusReport":
          await EmployeeBonus(data.otherdata, check.crn_id, emit_hrms_notifications, myexpression, socket, io)  
          break;

        default:
          console.log(`sorry, we are out of - ${myexpression}`);
      }
    } catch (err) {
      error_log({ stack: err.stack });
    }
  });

  // START CONNECTION WITH CHAT
  socket.on('joinTrack', async (data) => {
    socket.join(data.trackid);
  });
  //INSERTION OF CHAT IN MESSAGES(DATABASE)

  socket.on("upload", (file, callback) => {
    console.log(file); // <Buffer 25 50 44 ...>

    const { writeFile } = require("fs");

    // save the content to the disk, for example
    writeFile("./", file, (err) => {
      callback({ message: err ? "failure" : "success" });
    });
  });

  socket.on("chat", async (data) => {
    try {

      token_res = await verifyToken(`${socket.handshake.auth.token}`);
      let user_id = token_res.crn_id;


      await hrmsDB.query("INSERT INTO tbl_chat (incoming_msg_id, outgoing_msg_id, msg,insert_dt, trxn_id) values(:from_user, :to_user, :message, :insert_dt, :request)", {
        replacements: {
          request: data.trackid || "--",
          from_user: user_id,
          to_user: data.empcode,
          message: data.msg,
          insert_dt: moment(new Date()).tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss"),
        },
        type: hrmsDB.QueryTypes.INSERT,
      });

      io.to(data.empcode).emit("chat", { msg: data.msg, outgoing: user_id, incoming: data.empcode });
    } catch (error) {

      console.log(error);

      socket.emit({
        status: "error",
        message: { msg: "something happend wrong, please try again later" },
        code: "500",
        debug: error.stack,
      });

      error_log({ stack: error.stack });

    }
  });

};
