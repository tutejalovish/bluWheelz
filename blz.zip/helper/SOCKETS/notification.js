const jwt = require("jsonwebtoken");
const { hrmsDB } = require("./../../config/database");
const moment = require("moment");

const { verifyToken, error_log, emit_error_msg, emit_notifications } = require("../utils");

exports.notification = function (io, socket) {
  if (socket) {
    socket.on("fetch_notifications", async (data) => {
      try {
        token_res = await verifyToken(`${socket.handshake.auth.token}`);
        let user_id = token_res.crn_id;

        let stmt_0 = await hrmsDB.query(
          "SELECT * FROM `user_files_req` WHERE `user_id` = :user_id AND `module_name` = 'HRMS' ORDER BY `ID` DESC",
          {
            replacements: { user_id: user_id },
            type: hrmsDB.QueryTypes.SELECT,
          },
        );
        let final_data = [];
        if (stmt_0.length > 0) {
          let stmt_1 = await hrmsDB.query(
            "SELECT COUNT(CASE WHEN `msg_type` LIKE 'msg' THEN 0 END) AS `push_msg`, COUNT(CASE WHEN `msg_type` LIKE 'file' THEN 0 END) AS `file_msg`, COUNT(CASE WHEN `msg_type` LIKE 'btn' THEN 0 END) AS `btn_msg` FROM `user_files_req` WHERE `user_id` = :user_id ORDER BY `ID` DESC",
            {
              replacements: { user_id: user_id },
              type: hrmsDB.QueryTypes.SELECT,
            },
          );
          for (let i = 0; i < stmt_0.length; i++) {
            final_data.push({
              insert_date: moment(
                stmt_0[i].insert_date,
                "YYYY-MM-DD HH:mm:ss",
              ).fromNow(),
              msg_type: stmt_0[i].msg_type,
              other_data: stmt_0[i].other_data,
              req_code: stmt_0[i].req_code,
              req_date: stmt_0[i].req_date,
              request_txt_label: stmt_0[i].request_txt_label,
              status: stmt_0[i].status,
              user_id: stmt_0[i].user_id,
            });
          }

          socket.emit("notification", {
            data: final_data,
            push_count: Number(stmt_1[0].push_msg + stmt_1[0].btn_msg),
            file_count: stmt_1[0].file_msg,
          });
          if (data) {
            io.to(user_id).emit("all-notifications", {
              data: final_data,
              push_count: Number(stmt_1[0].push_msg + stmt_1[0].btn_msg),
              file_count: stmt_1[0].file_msg,
            });
          }
        } else {
          socket.emit("notification", {
            data: final_data,
            push_count: 0,
            file_count: 0,
          });
          if (data) {
            io.to(user_id).emit("all-notifications", {
              data: final_data,
              push_count: 0,
              file_count: 0,
            });
          }
        }
      } catch (err) {
        error_log({ stack: err.stack });
      }
    });


  }
};
