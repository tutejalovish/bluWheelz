const moment = require("moment");
const helper = require('./helper')
// exports.payslip = (arr) => {
//     return `
//     <!DOCTYPE html>
//     <html lang="en">
//     <head>
//     <meta charset="UTF-8" />
//     <meta http-equiv="X-UA-Compatible" content="IE=edge" />
//     <meta name="viewport" content="width=device-width, initial-scale=1.0" />
//     <style>
//     body {
//     justify-content: center;
//     align-items: center;
//     font-family: sans-serif;
//     }
//     table,
//     tr,
//     td {
//     padding: 10px;
//     font-weight: 550;
//     border: 0.5px solid #848484;
//     border-collapse: collapse;
//     font-size: 0.6rem;
//     text-align: center;
//     padding: 5px;
//     }
//     hr {
//     margin-left: 0px;
//     background-color: white;
//     border: 0px;
//     height: 0px;
//     border-top: 1px dashed gray;
//     }
//     </style>
//     </head>
//     <body>
//     <table style="width: 100%">
//     <tr>
//     <td colspan="6" style="position: relative; font-size:12px">
//     MsCorpres Automation Pvt Ltd<br />
//     Unit No-321 Tower-4. 3rd Floor,<br/>Assotech Business Cresterra, Sector 135, Expressway Noida,<br/> Uttar Pradesh - 201304
//     <br />
//     SALARY SLIP : FORM NO.XIX WAGES SLIP [RULE 78 (1)(B)]
//     </td>
//     </tr>
//     <tr>
//     <td colspan=6" style="background:#cccccc">
//     <bold>Payslip for Jan-2024</bold>
//     </td>
//     </tr>
//     <tr>
//     <td>EMP ID</td>
//     <td>${arr[0].emp_code}</td>
//     <td>Location</td>
//     <td>${arr[0].location_id}</td>
//     <td>UAN No.</td>
//     <td>${arr[0].uan}</td>
//     </tr>
//     <tr>
//     <td>Name</td>
//     <td>${arr[0].name}</td>
//     <td>Contact No.</td>
//     <td>${arr[0].contact_no}</td>
//     <td>Month Days</td>
//     <td>${arr[0].month_days}</td>
//     </tr>
//     <tr>
//     <td>Father's Name</td>
//     <td>${arr[0].father}</td>
//     <td>Bank Name</td>
//     <td>${arr[0].bank_name}</td>
//     <td>Paid Days</td>
//     <td>${arr[0].paid_days}</td>
//     </tr>
//     <tr>
//     <td>Date of Joining</td>
//     <td>${arr[0].doj}</td>
//     <td>Account No.</td>
//     <td>${arr[0].account}</td>
//     <td>EL Balance</td>
//     <td>${arr[0].el_bal}</td>
//     </tr>
//     <tr>
//     <td>Designation</td>
//     <td>${arr[0].designation_id}</td>
//     <td>IFSC</td>
//     <td>${arr[0].ifsc}</td>
//     <td>SL Balance</td>
//     <td>${arr[0].sl_bal}</td>
//     </tr>
//     <tr>
//     <td>Department</td>
//     <td>${arr[0].department_id}</td>
//     <td>ESI Code</td>
//     <td>${arr[0].esi_code}</td>
//     <td colspan="2"></td>
//     </tr>
//     <tr style="background:#cccccc">
//     <td colspan="2">Salary Head</td>
//     <td>Gross Rate</td>
//     <td>Gross Earning</td>
//     <td colspan="2">Deduction</td>
//     </tr>
//     <tr>
//     <td colspan="2">Basic</td>
//     <td>${arr[0].actualBasic}</td>
//     <td>${arr[0].basic}</td>
//     <td>EPF</td>
//     <td>${arr[0].epf}</td>
//     </tr>
//     <tr>
//     <td colspan="2">Dearness Allowance</td>
//     <td>${arr[0].actualDa}</td>
//     <td>${arr[0].da}</td>
//     <td>ESI</td>
//     <td>${arr[0].esi_code}</td>
//     </tr>
//     <tr>
//     <td colspan="2">House Rent Allowance</td>
//     <td>${arr[0].actualHra}</td>
//     <td>${arr[0].hra}</td>
//     <td>Advance</td>
//     <td>${arr[0].advance}</td>
//     </tr>
//     <tr>
//     <td colspan="2">Conveyance Allowance</td>
//     <td>${arr[0].actualCa}</td>
//     <td>${arr[0].conveyance}</td>
//     <td>VPF</td>
//     <td>${arr[0].vpf}</td>
//     </tr>
//     <tr>
//     <td colspan="2">Education Allowance</td>
//     <td>${arr[0].education}</td>
//     <td>${arr[0].education}</td>
//     <td>Income Tax</td>
//     <td>${arr[0].income_tax}</td>
//     </tr>
//     <tr>
//     <td colspan="2">Books & Periodicals</td>
//     <td>${arr[0].books_periodicals}</td>
//     <td>${arr[0].books_periodicals}</td>
//     <td></td>
//     <td></td>
//     </tr>
//     <tr>
//     <td colspan="2">Mobile Reimbursement</td>
//     <td>${arr[0].mobile}</td>
//     <td>${arr[0].mobile}</td>
//     <td></td>
//     <td></td>
//     </tr>
//     <tr>
//     <td colspan="2">Uniform Allowance</td>
//     <td>${arr[0].uniform}</td>
//     <td>${arr[0].uniform}</td>
//     <td></td>
//     <td></td>
//     </tr>
//     <tr>
//     <tr>
//     <td colspan="2">LTA</td>
//     <td>${arr[0].lta}</td>
//     <td>${arr[0].lta}</td>
//     <td></td>
//     <td></td>
//     </tr>
//     <tr>
//     <td colspan="2">REIMBURSEMENT</td>
//     <td>${arr[0].reiumbursement}</td>
//     <td>${arr[0].reiumbursement}</td>
//     <td></td>
//     <td></td>
//     </tr>
//     <tr>
//     <td colspan="2">Arrear</td>
//     <td>${arr[0].arrear}</td>
//     <td>${arr[0].arrear}</td>
//     <td>Other Deductions</td>
//     <td>${arr[0].other_deduction}</td>
//     </tr>
//     <tr>
//     <td colspan="2">OTHER EARNING</td>
//     <td>${arr[0].other}</td>
//     <td>${arr[0].other}</td>
//     <td></td>
//     <td></td>
//     </tr>
//     <tr>
//     <td colspan="2">TOTAL</td>
//     <td>${arr[0].total}</td>
//     <td>${arr[0].total}</td>
//     <td>TOTAL</td>
//     <td>${arr[0].total_deduction}</td>
//     </tr>
//     <tr>
//     <td colspan="6">
//     <div style="display: flex; flex-direction:row; width: 100%">
//     <span style="margin: 0px 5px">Net Salary:</span>
//     <span style="margin: 0px 5px">${arr[0].final_in_hand}</span>
//     <span style="margin: 0px 5px">${helper.amount_to_word(arr[0].final_in_hand)}</span>
//     </div>
//     </td>
//     </tr>
//     </table>
//     <p style="text-align:left; font-size:10px">
//     Remarks : This is a computer generated statement, as such no signature required
//     <span style="float:right;">
//     Generate On: ${moment().format("DD-MM-YYYY")}
//     </span>
//     </p>
//     <hr>
//     </body>
//     </html>
    
//   `;
// };


///////////////////
exports.payslip = (arr) => {
  return `
  <!DOCTYPE html>
  <html lang="en">
    <head>
      <meta charset="UTF-8" />
      <meta http-equiv="X-UA-Compatible" content="IE=edge" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      <style>
            body {
              justify-content: center;
              align-items: center;
              font-family: sans-serif;
            }
            table,
            tr,
            td {
              padding: 10px;
              font-weight: 550;
              border: 0.5px solid #848484;
              border-collapse: collapse;
              font-size: 0.6rem;
              text-align: center;
              padding: 5px;
            }
            hr {
              margin-left: 0px;
              background-color: white;
              border: 0px;
              height: 0px;
              border-top: 1px dashed gray;
          }
      </style>
    </head>
    <body>
      <table style="width: 100%">
        <tr>
          <td colspan="6" style="position: relative; font-size:12px">
          MsCorpres Automation Pvt Ltd<br />
          Unit No-321 Tower-4. 3rd Floor,<br/>Assotech Business Cresterra, Sector 135, Expressway Noida,<br/> Uttar Pradesh - 201304
          <br />
            SALARY SLIP : FORM NO.XIX WAGES SLIP [RULE 78 (1)(B)]
          </td>
        </tr>
        <tr>
          <td colspan=6" style="background:#cccccc">
          <bold>Payslip for the month of ${arr[0].month}</bold>
          </td>
        </tr>
        <tr>
          <td>EMP ID</td>
          <td>${arr[0].emp_code}</td>
          <td>Location</td>
          <td>${arr[0].location_id}</td>
          <td>UAN No.</td>
          <td>${arr[0].uan}</td>
        </tr>
        <tr>
          <td>Name</td>
          <td>${arr[0].name}</td>
          <td>Contact No.</td>
          <td>${arr[0].contact_no}</td>
          <td>Month Days</td>
          <td>${arr[0].month_days}</td>
        </tr>
        <tr>
          <td>Father\'s Name</td>
          <td>${arr[0].father}</td>
          <td>Bank Name</td>
          <td>${arr[0].bank_name}</td>
          <td>Paid Days</td>
          <td>${arr[0].paid_days}</td>
        </tr>
<tr>
          <td>Date of Joining</td>
          <td>${arr[0].doj}</td>
          <td>Account No.</td>
          <td>${arr[0].account}</td>
          <td>EL Balance</td>
          <td>${arr[0].el_closingBal}</td>
        </tr>
        <tr>
          <td>Designation</td>
          <td>${arr[0].designation_id}</td>
          <td>IFSC</td>
          <td>${arr[0].ifsc}</td>
          <td>SL Balance</td>
          <td>${arr[0].sl_closingBal}</td>
        </tr>
        <tr>
          <td>Department</td>
          <td>${arr[0].department_id}</td>
          <td>ESI Code</td>
          <td>${arr[0].esi_code}</td>
          <td colspan="2"></td>
        </tr>
        <tr style="background:#cccccc">
          <td colspan="2">Salary Head</td>
          <td>Gross Rate</td>
          <td>Gross Earning</td>
          <td colspan="2">Deduction</td>
        </tr>
        <tr>
          <td colspan="2">Basic</td>
          <td>${arr[0].actualBasic}</td>
          <td>${arr[0].basic}</td>
          <td>EPF</td>
          <td>${arr[0].epf}</td>
        </tr>
        <tr>
          <td colspan="2">Dearness Allowance</td>
          <td>${arr[0].actualDa}</td>
          <td>${arr[0].final_da}</td>
          <td>ESI</td>
          <td>${arr[0].final_esi}</td>
        </tr>
        <tr>
          <td colspan="2">House Rent Allowance</td>
          <td>${arr[0].actualHra}</td>
          <td>${arr[0].final_hra}</td>
          <td>Advance</td>
          <td>${arr[0].final_ee_advance}</td>
        </tr>
        <tr>
          <td colspan="2">Conveyance Allowance</td>
          <td>${arr[0].actual_conv_reimb}</td>
          <td>${arr[0].final_conv_reimb}</td>
          <td>VPF</td>
          <td>${arr[0].final_vpf}</td>
        </tr>
        <tr>
          <td colspan="2">Education Allowance</td>
          <td>${arr[0].salary_edu_allowance}</td>
          <td>${arr[0].final_edu_allowance}</td>
          <td>Income Tax</td>
          <td>${arr[0].final_income_tax}</td>
        </tr>
        <tr>
          <td colspan="2">Books & Periodicals</td>
          <td>${arr[0].salary_books_periodicals}</td>
          <td>${arr[0].final_books_periodicals}</td>
          <td></td>
          <td></td>
        </tr>
        <tr>
          <td colspan="2">Mobile Reimbursement</td>
          <td>${arr[0].salary_mobile_reimb}</td>
          <td>${arr[0].final_mobile_reimb}</td>
          <td></td>
          <td></td>
        </tr>
    <tr>
          <td colspan="2">Uniform Allowance</td>
          <td>${arr[0].salary_uniform_allowance}</td>
          <td>${arr[0].final_uniform_allowance}</td>
          <td></td>
          <td></td>
        </tr>
        <tr>
    <tr>
          <td colspan="2">LTA</td>
          <td>${arr[0].salary_lta}</td>
          <td>${arr[0].final_lta}</td>
          <td></td>
          <td></td>
        </tr>
    <tr>
          <td colspan="2">REIMBURSEMENT</td>
          <td>0</td>
          <td>0</td>
          <td></td>
          <td></td>
        </tr>
    <tr>
          <td colspan="2">Arrear</td>
          <td>0</td>
          <td>${arr[0].final_arrear}</td>
          <td>Other Deductions</td>
          <td>${arr[0].final_ee_other_deduction}</td>
        </tr>
    <tr>
          <td colspan="2">OTHER EARNING</td>
          <td>0</td>
          <td>0</td>
          <td></td>
          <td></td>
        </tr>
        <tr>
          <td colspan="2">TOTAL</td>
          <td>${arr[0].gross_actual_total}</td>
          <td>${arr[0].gross_final_total}</td>
          <td>TOTAL</td>
          <td>${arr[0].deduction_final_total}</td>
        </tr>
      
        <tr>
          <td  colspan="6">
          <div style="display: flex; flex-direction:row; width: 100%">
            <span style="margin: 0px 5px">Net Salary:</span>
            <span style="margin: 0px 5px">${arr[0].final_inHand_total}</span>
            <span style="margin: 0px 5px">${arr[0].final_inHand_inWords}</span>
          </div>
          </td>
          </tr>
      </table>
      <p style="text-align:left; font-size:10px">
        Remarks : This is a computer generated statement, as such no signature required
        <span style="float:right;">
          Generate On: ${moment().format('DD-MM-YYYY HH:mm:ss')}
        </span>
      </p>
      <hr>
    </body>
  </html>
  
`;
};




////////////////


exports.payslipBC = (arr) => {
  return `
  <!DOCTYPE html>
    <html lang="en">
      <head>
        <meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <style>
              body {
                justify-content: center;
                align-items: center;
                font-family: sans-serif;
              }
              table,
              tr,
              td {
                padding: 10px;
                font-weight: 550;
                border: 0.5px solid #848484;
                border-collapse: collapse;
                font-size: 0.6rem;
                text-align: center;
                padding: 5px;
              }
              hr {
                margin-left: 0px;
                background-color: white;
                border: 0px;
                height: 0px;
                border-top: 1px dashed gray;
            }
        </style>
      </head>
      <body>
        <table style="width: 100%">
          <tr>
            <td colspan="6" style="position: relative; font-size:12px">
            MsCorpres Automation Pvt Ltd<br />
            Unit No-321 Tower-4. 3rd Floor,<br/>Assotech Business Cresterra, Sector 135, Expressway Noida,<br/> Uttar Pradesh - 201304
            <br />
              SALARY SLIP : FORM NO.XIX WAGES SLIP [RULE 78 (1)(B)]
            </td>
          </tr>
          <tr>
            <td colspan=6" style="background:#cccccc">
            <bold>Payslip for the month of ${arr[0].month}</bold>
            </td>
          </tr>
          <tr>
            <td>EMP ID</td>
            <td>${arr[0].emp_code}</td>
            <td>Location</td>
            <td>${arr[0].location_id}</td>
            <td>UAN No.</td>
            <td>${arr[0].uan}</td>
          </tr>
          <tr>
            <td>Name</td>
            <td>${arr[0].name}</td>
            <td>Contact No.</td>
            <td>${arr[0].contact_no}</td>
            <td>ESI Code</td>
            <td>${arr[0].esi_code}</td>
          </tr>
          <tr>
            <td>Father\'s Name</td>
            <td>${arr[0].father}</td>
            <td>Bank Name</td>
            <td>${arr[0].bank_name}</td>
            <td>Month Days</td>
            <td>${arr[0].month_days}</td>
          </tr>
          <tr>
            <td>Department</td>
            <td>${arr[0].department_id}</td>
            <td>Account No.</td>
            <td>${arr[0].account}</td>
            <td>Paid Days</td>
            <td>${arr[0].paid_days}</td>
          </tr>
          <tr>
            <td>Date Of Joining</td>
            <td>${arr[0].doj}</td>
            <td>IFSC</td>
            <td>${arr[0].ifsc}</td>
            
          </tr>
          <tr style="background:#cccccc">
            <td colspan="2">Salary Head</td>
            <td>Gross Rate</td>
            <td>Gross Earning</td>
            <td colspan="2">Deduction</td>
          </tr>
          <tr>
            <td colspan="2">Basic</td>
            <td>${arr[0].actualBasic}</td>
            <td>${arr[0].basic}</td>
            <td>EPF</td>
            <td>${arr[0].epf}</td>
          </tr>
          <tr>
            <td colspan="2">Dearness Allowance</td>
            <td>${arr[0].actualDa}</td>
            <td>${arr[0].da}</td>
            <td>ESI</td>
            <td>${arr[0].esi}</td>
          </tr>
          <tr>
            <td colspan="2">House Rent Allowance</td>
            <td>${arr[0].actualHra}</td>
            <td>${arr[0].hra}</td>
            <td>Advance</td>
            <td>${arr[0].advance}</td>
          </tr>
          <tr>
            <td colspan="2">Conveyance Allowance</td>
            <td>${arr[0].actualCa}</td></td>
            <td>${arr[0].conveyance}</td>
            <td></td>
            <td></td>
          </tr>
          <tr>
            <td colspan="2">Good Work Incentive</td>
            <td>00</td>
            <td>${arr[0].incentive}</td>
            <td></td>
            <td></td>
          </tr>
          <tr>
            <td colspan="2">Night Allowance</td>
            <td>00</td>
            <td>00</td>
            <td></td>
            <td></td>
          </tr>
          <tr>
            <td colspan="2">Leave Encashment</td>
            <td>00</td>
            <td>${arr[0].leave_encashment}</td>
            <td></td>
            <td></td>
          </tr>
		  <tr>
            <td colspan="2">REIMBURSEMENT</td>
            <td>0</td>
            <td>${arr[0].reimbursement}</td>
            <td></td>
            <td></td>
          </tr>
		  <tr>
            <td colspan="2">OTHER EARNING</td>
            <td>0</td>
            <td>${arr[0].attend_other_earning}</td>
            <td></td>
            <td></td>
          </tr>
          <tr>
            <td colspan="2">TOTAL</td>
            <td>${arr[0].actTotal}</td>
            <td>${arr[0].total}</td>
            <td>TOTAL</td>
            <td>${arr[0].totalDeduction}</td>
          </tr>
        
          <tr>
            <td  colspan="6">
            <div style="display: flex; flex-direction:row; width: 100%">
              <span style="margin: 0px 5px">Net Salary:</span>
              <span style="margin: 0px 5px">${arr[0].final_in_hand}</span>
              <span style="margin: 0px 5px">${helper.amount_to_word(arr[0].final_in_hand)}</span>
            </div>
            </td>
            </tr>
        </table>
        <p style="text-align:left; font-size:10px">
          Remarks : This is a computer generated statement, as such no signature required
          <span style="float:right;">
            Generate On: ${moment().format("DD-MM-YYYY")}
          </span>
        </p>
        <hr>
      </body>
    </html>
    `;
}
