const rsa = require('node-rsa');
const fs = require('fs');
require("./events")
const ftp = require('basic-ftp');

global.helper = require('../helper/helper');
global.moment = require('moment');

// -------------------------------------------------------------------------------------
// CREATE KEY FOLDER
const folderPath = "keys";
fs.access(folderPath, fs.constants.R_OK, (err) => {
    if (err) {
        console.error('The folder does not exist.');
        fs.mkdir(folderPath, { recursive: true }, (err) => {
            if (err) {
                console.error('Error creating folder:', err);
            } else {
                console.log('Folder created successfully.');
                GeneratePair();
            }
        });
    } else {
        console.log('The folder exists.');
        GeneratePair();
    }
});

async function GeneratePair() {
    const publicKeyPath = './keys/public.pem';
    const privateKeyPath = './keys/private.pem';

    // Check if both public and private key files exist
    if (!fs.existsSync(publicKeyPath) || !fs.existsSync(privateKeyPath)) {
        const key = new rsa().generateKeyPair();

        const publicKey = key.exportKey('public');
        const privateKey = key.exportKey('private');

        // Write both keys to files
        if (!fs.existsSync(publicKeyPath)) {
            fs.writeFileSync(publicKeyPath, publicKey, { flag: 'wx' });
        } else {
            fs.writeFileSync(publicKeyPath, publicKey, { flag: 'w' });
        }

        if (!fs.existsSync(privateKeyPath)) {
            fs.writeFileSync(privateKeyPath, privateKey, { flag: 'wx' });
        } else {
            fs.writeFileSync(privateKeyPath, privateKey, { flag: 'w' });
        }

        console.log('RSA key pair generated and saved.');

        const client = new ftp.Client();

        try {
            await client.access({
                host: process.env.SOCKET_FTP_HOST,
                user: process.env.SOCKET_FTP_USER,
                port: process.env.SOCKET_FTP_PORT,
                password: process.env.SOCKET_FTP_PASS,
                secure: true
            });

            console.log('Connected to FTP server');
            await client.uploadFrom(publicKeyPath, '/' + 'public.pem');
            console.log('Public Key uploaded successfully');
            await client.uploadFrom(privateKeyPath, '/' + 'private.pem');
            console.log('Private Key uploaded successfully');
        } catch (err) {
            console.error('an error occured while uploading to FTP server : ', err);
        } finally {
            client.close();
        }

    } else {
        console.log('Public and private key files already exist. Skipping generation.');
    }
}
// END CREATE KEY FOLDER
// -----------------------------------------------------------------------------------

app.use('/', (req, res, next) => {
    if (req.path.endsWith(".css") || req.path.endsWith(".js") || req.path.match(/\.(png|jpg|jpeg|gif|svg)$/)) {
        if (req.headers.referer && req.headers.referer.startsWith(process.env.BASE_URL)) {
            next();
        } else {
            res.status(500).send("Internal Server Error");
        }
    } else {
        next();
    }
});
