const Fastify = require("fastify");

const app = Fastify({
    logger: true
});

const mid = async (request, reply) => {
    console.log("mid");
    reply.headers('x-test', 'test')

    request.body = {
        name: 'test',
    }

    // return reply.send({ mid: 'mid' });
    // return "mid return"; //NOT WORKING
}
// app.use(cors({})) //OLD

// app.register(cors({})) //NEW

const mid2 = async (request, reply) => {
    console.log("mid2");
    reply.headers('x-test', 'test')
}

// Declare a route
app.get('/', { preHandler: [mid, mid2] }, async (request, reply) => {
    return reply.status(200).send({ hello: 'world' })
    // return reply.status(200).json({ hello: 'world' }) // NOT WORKING
    // return "hello world";
})


// Run the server!
try {
    app.listen({ port: 3000 })
        .then(() => {
            console.log(`Server listening on ${app.server.address().port}`)
        })



} catch (err) {
    console.log("errrr")
    app.log.error(err)


    process.exit(1)
}