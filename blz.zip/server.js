
var fastify = require("fastify")({ logger: false });

const expressPlugin = require("@fastify/express");

async function start() {
    await fastify.register(expressPlugin);
    require("./app")(fastify);
}

start();