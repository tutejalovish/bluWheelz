const http = require("http");
const path = require("path");
const cookieParser = require("cookie-parser");
const logger = require("morgan");
const { v4: uuidv4 } = require("uuid");
const cors = require("cors");
const compression = require("compression");
const nocache = require("nocache");
const bodyParser = require("body-parser");
const UAParser = require("ua-parser-js");
const session = require('express-session')

const express = require("express");
const app = express();
require("dotenv").config();
const fs = require("fs");

const port = process.env.PORT;
async function start(fastify) {
  global.app = app;
  app.locals.baseUrl = process.env.BASE_URL;
  app.locals.apiUrl = process.env.API_URL;
  app.locals.socketUrl_2 = process.env.SOCKET_SERVER_2;

  app.use(session({
    secret: uuidv4(),
    resave: false,
    saveUninitialized: true,
    cookie: {
      maxAge: null, // 1800000, // 30 minutes
      httpOnly: true,
      secure: false,
    },
  }));

  require("./helper/start");

  // view engine setup
  app.use("/static", express.static(path.join(__dirname, "public")));
  app.set("views", path.join(__dirname, "views"));
  app.set("view engine", "ejs");
  app.use("/assets", express.static(path.join(__dirname, "assets")));

  // Define a custom format for morgan to log the desired information
  logger.token("browser", function (req) {
    return req.headers["user-agent"];
  });

  logger.token("os", function (req) {
    // Parse the user-agent string to extract the operating system information
    const uaParser = new UAParser();
    const ua = req.headers["user-agent"];
    const result = uaParser.setUA(ua).getResult();

    return result.os.name;
  });

  // Define the custom format for morgan to include all desired information
  const customFormat = `Remote Address - :remote-addr | Remote User - :remote-user
Method - :method 
URL - :referrer + :url 
Http Version - HTTP/:http-version
Status - :status | Length - :res[content-length]
Referrer - :referrer 
Browser - :browser 
Operating System - :os | Date & Time of Request - :date[clf]
------------------------------------------------------------------------------------------------`;

  var accessLogStream = fs.createWriteStream(path.join(__dirname, "access.log"), {
    flags: "a",
  });
  app.use(logger(customFormat, { stream: accessLogStream }));

  app.use(express.json());
  app.use(cookieParser());
  // app.use(express.static(path.join(__dirname, "public")));
  app.use(bodyParser.json({ limit: "1mb" }));
  app.use(
    bodyParser.urlencoded({
      limit: "1mb",
      extended: true,
      parameterLimit: 50000,
    }),
  );
  app.use(compression());
  app.use(nocache());

  // Initialize CORS
  corsOptions = {
    origin: "*",
    optionsSuccessStatus: 200, // some legacy browsers (IE11, various SmartTVs) choke on 204
    methods: ["GET,HEAD,PUT,PATCH,POST,DELETE"],
  };
  app.use(cors(corsOptions));

  // IMPORT AND INITIALIZE ROUTES
  require("./routes/router")(app);

  // FINANCE MODULE

  // catch 404 and forward to error handler
  app.use(function (req, res, next) {
    // next(createError(404));
    return res
      .status(404)
      .send(require("./helper/backendProcess/error_404").error_404());
  });

  // error handler
  app.use(function (err, req, res, next) {
    // set locals, only providing error in development
    res.locals.message = err.message;
    res.locals.error = req.app.get("env") === "development" ? err : {};

    // render the error page
    res.status(err.status || 500);
    res.render("error");
  });

  // console.log("---------------------------");
  // console.log(process)
  // Console when new process is created
  // console.log("Process ID: " + process.pid);
  // console.log("uptime : " + process.uptime());
  // console.log("Memory : " + JSON.stringify(process.memoryUsage()));
  // console.log("---------------------------");

  fastify.use(app);

  const node_server = http
    .createServer(app, () => {
      timeout = 60000;
    })
    .listen(port);
  console.log(`server started at port ${port}`);

  var io = require("socket.io")(node_server, {
    pingTimeout: 6000000,
    pingInterval: 6000000,
    transports: ["websocket", "polling"],
    upgrade: false,
    cors: {
      // origin: ["https://hrms.mscorpres.online", "https://login.mscorpres.online", "https://essp.mscorpres.online"],
      origin: "*",
      allowedHeaders: ["token", "Content-Type", "page_id", "type"],
    },
  });

  
  

}



module.exports = start
