require("dotenv").config();

const { Sequelize } = require("sequelize");

let options = {
  multipleStatements: true,
  connectTimeout: 180000,
  connectionLimit: 10,
  waitForConnections: true,
  queueLimit: 0,
  encrypt: false,
  trustServerCertificate: true,
  charset: "utf8mb4",
};

let poolOption = {
  max: 100,
  min: 0,
  idle: 10000,
  acquire: 100 * 1000,
};






//  const sequelize = new Sequelize("test_hrms", "somendra", "@0Xl82l5q", {
//    host:  "207.180.216.86",
//    dialect: "mysql",
//    dialectOptions: options,
//    pool: poolOption,
//  });

const sequelize = new Sequelize("bluWheelz", "avnadmin", "AVNS_AaNwB7kVSyGWt_gLW", {
  host: "mysql-ab600a1-lovishtuteja506-bluewheelz.e.aivencloud.com",
  port: 11706,
  dialect: "mysql",
  dialectOptions: {
    ssl: {
      rejectUnauthorized: false, // Use 'false' only if not verifying SSL certificates
    },
  },
  pool: poolOption,
});










module.exports = { blz: sequelize};