"use strict";
!(function (p, x) {
    (p.Package.name = "DashLite"), (p.Package.version = "3.2");
    var c = x(window),
        a = x("body"),
        l = x(document),
        e = "nk-menu",
        o = "nk-menu-content",
        s = "menu-active",
        r = "nk-header-menu",
        d = "nk-sidebar",
        t = "nk-sidebar-mobile",
        u = p.Break;
    function f(t, n) {
        return (
            Object.keys(n).forEach(function (e) {
                t[e] = n[e];
            }),
            t
        );
    }
    (p.ClassBody = function () {
        p.AddInBody("nk-apps-sidebar"), p.AddInBody(d);
    }),
        (p.ClassNavMenu = function () {
            p.BreakClass("." + r, u.lg, { timeOut: 0 }),
                p.BreakClass("." + d, u.lg, { timeOut: 0, classAdd: t }),
                c.on("resize", function () {
                    p.BreakClass("." + r, u.lg), p.BreakClass("." + d, u.lg, { classAdd: t });
                });
        }),
        (p.Prettify = function () {
            window.prettyPrint && prettyPrint();
        }),
        (p.Copied = function () {
            var e = ".clipboard-init",
                i = ".clipboard-text",
                o = "clipboard-success",
                s = "clipboard-error";
            function t(e, t) {
                var e = x(e),
                    n = e.parent(),
                    a = { text: "Copy", done: "Copied", fail: "Failed" },
                    e = { text: e.data("clip-text"), done: e.data("clip-success"), fail: e.data("clip-error") },
                    e = ((a.text = e.text || a.text), (a.done = e.done || a.done), (a.fail = e.fail || a.fail), "success" === t ? a.done : a.fail);
                n
                    .addClass("success" === t ? o : s)
                    .find(i)
                    .html(e),
                    setTimeout(function () {
                        n
                            .removeClass(o + " " + s)
                            .find(i)
                            .html(a.text)
                            .blur(),
                            n.find("input").blur();
                    }, 2e3);
            }
            ClipboardJS.isSupported()
                ? new ClipboardJS(e)
                    .on("success", function (e) {
                        t(e.trigger, "success"), e.clearSelection();
                    })
                    .on("error", function (e) {
                        t(e.trigger, "error");
                    })
                : x(e).css("display", "none");
        }),
        (p.CurrentLink = function () {
            var e = window.location.href,
                n = (n = e.substring(0, -1 == e.indexOf("#") ? e.length : e.indexOf("#"))).substring(0, -1 == n.indexOf("?") ? n.length : n.indexOf("?"));
            x(".nk-menu-link, .menu-link, .nav-link").each(function () {
                var e = x(this),
                    t = e.attr("href");
                n.match(t)
                    ? (e.closest("li").addClass("active current-page").parents().closest("li").addClass("active current-page"),
                        e.closest("li").children(".nk-menu-sub").css("display", "block"),
                        e.parents().closest("li").children(".nk-menu-sub").css("display", "block"),
                        this.scrollIntoView({ block: "start" }),
                        x(".nk-menu-switch").parent().removeClass("active"),
                        x("." + o).removeClass(s),
                        (t = e.closest("." + o).data("content")),
                        e.closest("." + o).addClass(s),
                        x("[data-target=" + t + "]")
                            .parent()
                            .addClass("active"))
                    : e.closest("li").removeClass("active current-page").parents().closest("li:not(.current-page)").removeClass("active");
            });
        }),
        (p.PassSwitch = function () {
            p.Passcode(".passcode-switch");
        }),
        (p.Toast = function (e, t, n) {
            var a = "info" === (t = t || "info") ? "ni ni-info-fill" : "success" === t ? "ni ni-check-circle-fill" : "error" === t ? "ni ni-cross-circle-fill" : "warning" === t ? "ni ni-alert-fill" : "",
                i = { position: "bottom-right", ui: "", icon: "auto", clear: !1 },
                n = n ? f(i, n) : i;
            (n.position = n.position ? "toast-" + n.position : "toast-bottom-right"),
                (n.icon = "auto" === n.icon ? a : n.icon || ""),
                (n.ui = n.ui ? " " + n.ui : ""),
                (i = "" !== n.icon ? '<span class="toastr-icon"><em class="icon ' + n.icon + '"></em></span>' : ""),
                "" !== (e = "" !== e ? i + '<div class="toastr-text">' + e + "</div>" : "") &&
                (!0 === n.clear && toastr.clear(),
                    (a = {
                        closeButton: !0,
                        debug: !1,
                        newestOnTop: !1,
                        progressBar: !1,
                        positionClass: n.position + n.ui,
                        closeHtml: '<span class="btn-trigger">Close</span>',
                        preventDuplicates: !0,
                        showDuration: "1500",
                        hideDuration: "1500",
                        timeOut: "2000",
                        toastClass: "toastr",
                        extendedTimeOut: "3000",
                    }),
                    (toastr.options = f(a, n)),
                    toastr[t](e));
        }),
        (p.TGL.screen = function (e) {
            x(e).exists() &&
                x(e).each(function () {
                    var e = x(this).data("toggle-screen");
                    e && x(this).addClass("toggle-screen-" + e);
                });
        }),
        (p.TGL.content = function (e, t) {
            var e = x(e || ".toggle"),
                n = x("[data-content]"),
                s = !1,
                a = { active: "msc-active", content: "content-active", break: !0 },
                r = t ? f(a, t) : a;
            p.TGL.screen(n),
                e.on("click", function (e) {
                    (s = this), p.Toggle.trigger(x(this).data("target"), r), e.preventDefault();
                }),
                l.on("mouseup", function (e) {
                    var t, n, a, i, o;
                    s &&
                        ((t = x(s)),
                            (n = x(s).data("target")),
                            (n = x('[data-content="'.concat(n, '"]'))),
                            (a = x(".datepicker-dropdown")),
                            (i = x(".ui-timepicker-container")),
                            (o = x(".modal")),
                            t.is(e.target) ||
                            0 !== t.has(e.target).length ||
                            n.is(e.target) ||
                            0 !== n.has(e.target).length ||
                            0 !== x(e.target).closest(".select2-container").length ||
                            a.is(e.target) ||
                            0 !== a.has(e.target).length ||
                            i.is(e.target) ||
                            0 !== i.has(e.target).length ||
                            o.is(e.target) ||
                            0 !== o.has(e.target).length ||
                            (p.Toggle.removed(t.data("target"), r), (s = !1)));
                }),
                c.on("resize", function () {
                    n.each(function () {
                        var e = x(this).data("content"),
                            t = x(this).data("toggle-screen"),
                            t = u[t];
                        p.Win.width > t && p.Toggle.removed(e, r);
                    });
                });
        }),
        (p.TGL.expand = function (e, t) {
            var e = e || ".expand",
                n = { toggle: !0 },
                a = t ? f(n, t) : n;
            x(e).on("click", function (e) {
                p.Toggle.trigger(x(this).data("target"), a), e.preventDefault();
            });
        }),
        (p.TGL.ddmenu = function (e, t) {
            var e = e || ".nk-menu-toggle",
                n = { active: "active", self: "nk-menu-toggle", child: "nk-menu-sub" },
                a = t ? f(n, t) : n;
            x(e).on("click", function (e) {
                (p.Win.width < u.lg || x(this).parents().hasClass(d)) && p.Toggle.dropMenu(x(this), a), e.preventDefault();
            });
        }),
        (p.TGL.showmenu = function (e, t) {
            var n = x(e || ".nk-nav-toggle"),
                a = x("[data-content]"),
                i = a.hasClass(r) ? u.lg : u.xl,
                e = { active: "toggle-active", content: d + "-active", body: "nav-shown", overlay: "nk-sidebar-overlay", break: i, close: { profile: !0, menu: !1 } },
                o = t ? f(e, t) : e;
            n.on("click", function (e) {
                p.Toggle.trigger(x(this).data("target"), o), e.preventDefault();
            }),
                l.on("mouseup", function (e) {
                    !n.is(e.target) && 0 === n.has(e.target).length && !a.is(e.target) && 0 === a.has(e.target).length && p.Win.width < i && p.Toggle.removed(n.data("target"), o);
                }),
                c.on("resize", function () {
                    (p.Win.width < u.xl || p.Win.width < i) && !p.State.isMobile && p.Toggle.removed(n.data("target"), o);
                });
        }),
        (p.menuSwitch = function () {
            var a = x(".nk-menu-switch"),
                i = x("." + o);
            a.on("click", function (e) {
                var t = x(this),
                    n = t.data("target"),
                    n = x("[data-content=" + n + "]");
                a.parent().removeClass("active"), t.parent().addClass("active"), i.removeClass(s), n.addClass(s), e.preventDefault();
            });
        }),
        (p.Ani.formSearch = function (e, t) {
            var n = { active: "active", timeout: 400, target: "[data-search]" },
                a = t ? f(n, t) : n,
                i = x(e),
                o = x(a.target);
            i.exists() &&
                (i.on("click", function (e) {
                    e.preventDefault();
                    var e = x(this).data("target"),
                        t = x("[data-search=" + e + "]"),
                        e = x("[data-target=" + e + "]");
                    t.hasClass(a.active)
                        ? (e.add(t).removeClass(a.active),
                            setTimeout(function () {
                                t.find("input").val("");
                            }, a.timeout))
                        : (e.add(t).addClass(a.active), t.find("input").focus());
                }),
                    l.on({
                        keyup: function (e) {
                            "Escape" === e.key && i.add(o).removeClass(a.active);
                        },
                        mouseup: function (e) {
                            o.find("input").val() || o.is(e.target) || 0 !== o.has(e.target).length || i.is(e.target) || 0 !== i.has(e.target).length || i.add(o).removeClass(a.active);
                        },
                    }));
        }),
        (p.Ani.formElm = function (e, t) {
            var n = { focus: "focused" },
                a = t ? f(n, t) : n;
            x(e).exists() &&
                x(e).each(function () {
                    var e = x(this);
                    e.val() && e.parent().addClass(a.focus),
                        e.on({
                            focus: function () {
                                e.parent().addClass(a.focus);
                            },
                            blur: function () {
                                e.val() || e.parent().removeClass(a.focus);
                            },
                        });
                });
        }),
        (p.Validate = function (e, t) {
            x(e).exists() &&
                (x(e).each(function () {
                    var e = { errorElement: "span" },
                        e = t ? f(e, t) : e;
                    x(this).validate(e);
                }),
                    p.Validate.OnChange(".js-select2"),
                    p.Validate.OnChange(".date-picker"),
                    p.Validate.OnChange(".js-tagify"));
        }),
        (p.Validate.OnChange = function (e) {
            x(e).on("change", function () {
                x(this).valid();
            });
        }),
        (p.Validate.init = function () {
            p.Validate(".form-validate", {
                errorElement: "span",
                errorClass: "invalid",
                errorPlacement: function (e, t) {
                    t.parents().hasClass("input-group") ? e.appendTo(t.parent().parent()) : e.appendTo(t.parent());
                },
            });
        }),
        (p.Wizard = function () {
            var e = x(".nk-wizard");
            e.exists() &&
                e.each(function () {
                    var e = x(this).attr("id"),
                        a = x("#" + e).show();
                    a.steps({
                        headerTag: ".nk-wizard-head",
                        bodyTag: ".nk-wizard-content",
                        labels: { finish: "Submit", next: "Next", previous: "Prev", loading: "Loading ..." },
                        titleTemplate: '<span class="number">0#index#</span> #title#',
                        onStepChanging: function (e, t, n) {
                            return n < t || (t < n && (a.find(".body:eq(" + n + ") label.error").remove(), a.find(".body:eq(" + n + ") .error").removeClass("error")), (a.validate().settings.ignore = ":disabled,:hidden"), a.valid());
                        },
                        onFinishing: function (e, t) {
                            return (a.validate().settings.ignore = ":disabled"), a.valid();
                        },
                        onFinished: function (e, t) {
                            window.location.href = "#";
                        },
                    }).validate({
                        errorElement: "span",
                        errorClass: "invalid",
                        errorPlacement: function (e, t) {
                            e.appendTo(t.parent());
                        },
                    });
                });
        }),
        (p.DataTable = function (e, o) {
            x(e).exists() &&
                x(e).each(function () {
                    var e = x(this).data("auto-responsive"),
                        t = !(void 0 === o.buttons || !o.buttons),
                        n = x(this).data("export-title") ? x(this).data("export-title") : "Export",
                        a = t ? '<"dt-export-buttons d-flex align-center"<"dt-export-title d-none d-md-inline-block">B>' : "",
                        t = t ? " with-export" : "",
                        i =
                            '<"row justify-between g-2' +
                            t +
                            '"<"col-7 col-sm-4 text-start"f><"col-5 col-sm-8 text-end"<"datatable-filter"<"d-flex justify-content-end g-2"' +
                            a +
                            'l>>>><"datatable-wrap my-3"t><"row align-items-center"<"col-7 col-sm-12 col-md-9"p><"col-5 col-sm-12 col-md-3 text-start text-md-end"i>>',
                        t =
                            '<"row justify-between g-2' +
                            t +
                            '"<"col-7 col-sm-4 text-start"f><"col-5 col-sm-8 text-end"<"datatable-filter"<"d-flex justify-content-end g-2"' +
                            a +
                            'l>>>><"my-3"t><"row align-items-center"<"col-7 col-sm-12 col-md-9"p><"col-5 col-sm-12 col-md-3 text-start text-md-end"i>>',
                        a = {
                            responsive: !0,
                            autoWidth: !1,
                            dom: x(this).hasClass("is-separate") ? t : i,
                            language: {
                                search: "",
                                searchPlaceholder: "Type in to Search",
                                lengthMenu: "<span class='d-none d-sm-inline-block'>Show</span><div class='form-control-select'> _MENU_ </div>",
                                info: "_START_ -_END_ of _TOTAL_",
                                infoEmpty: "0",
                                infoFiltered: "( Total _MAX_  )",
                                paginate: { first: "First", last: "Last", next: "Next", previous: "Prev" },
                            },
                        },
                        t = o ? f(a, o) : a,
                        t = !1 === e ? f(t, { responsive: !1 }) : t;
                    x(this).DataTable(t), x(".dt-export-title").text(n);
                });
        }),
        (p.DataTable.init = function () {
            p.DataTable(".datatable-init", { responsive: { details: !0 } }), p.DataTable(".datatable-init-export", { responsive: { details: !0 }, buttons: ["copy", "excel", "csv", "pdf"] }), (x.fn.DataTable.ext.pager.numbers_length = 7);
        }),
        (p.BS.ddfix = function (e, t) {
            var n = t || "a:not(.clickable), button:not(.clickable), a:not(.clickable) *, button:not(.clickable) *";
            x(e || ".dropdown-menu").on("click", function (e) {
                x(e.target).is(n) || e.stopPropagation();
            }),
                p.State.isRTL &&
                x(".dropdown-menu").each(function () {
                    var e = x(this);
                    e.hasClass("dropdown-menu-end") && !e.hasClass("dropdown-menu-center")
                        ? e.prev('[data-bs-toggle="dropdown"]').dropdown({ popperConfig: { placement: "bottom-start" } })
                        : e.hasClass("dropdown-menu-end") || e.hasClass("dropdown-menu-center") || e.prev('[data-bs-toggle="dropdown"]').dropdown({ popperConfig: { placement: "bottom-end" } });
                });
        }),
        (p.BS.tabfix = function (e) {
            x(e || '[data-bs-toggle="modal"]').on("click", function () {
                var e = x(this),
                    t = e.data("target"),
                    n = e.attr("href"),
                    e = e.data("tab-target"),
                    t = t ? a.find(t) : a.find(n);
                e && "#" !== e && t ? t.find('[href="' + e + '"]').tab("show") : t && ((n = t.find(".nk-nav.nav-tabs")), (e = x(n[0]).find('[data-bs-toggle="tab"]')), x(e[0]).tab("show"));
            });
        }),
        (p.ModeSwitch = function () {
            var e = x(".dark-switch");
            a.hasClass("dark-mode") ? e.addClass("active") : e.removeClass("active"),
                e.on("click", function (e) {
                    e.preventDefault(), x(this).toggleClass("active"), a.toggleClass("dark-mode");
                });
        }),
        (p.Knob = function (e, t) {
            var n, a;
            x(e).exists() &&
                "function" == typeof x.fn.knob &&
                ((n = { min: 0 }),
                    (a = t ? f(n, t) : n),
                    x(e).each(function () {
                        x(this).knob(a);
                    }));
        }),
        (p.Knob.init = function () {
            var e = { readOnly: !0, lineCap: "round" },
                t = { angleOffset: -90, angleArc: 180, readOnly: !0, lineCap: "round" };
            p.Knob(".knob", e), p.Knob(".knob-half", t);
        }),
        (p.Range = function (e, d) {
            x(e).exists() &&
                "undefined" != typeof noUiSlider &&
                x(e).each(function () {
                    var e = x(this),
                        t = e.attr("id"),
                        n = e.data("start"),
                        n = (n = /\s/g.test(n) ? n.split(" ") : n) || 0,
                        a = e.data("connect"),
                        a = void 0 === (a = /\s/g.test(a) ? a.split(" ") : a) ? "lower" : a,
                        i = e.data("min") || 0,
                        o = e.data("max") || 100,
                        s = e.data("min-distance") || null,
                        r = e.data("max-distance") || null,
                        c = e.data("step") || 1,
                        l = e.data("orientation") || "horizontal",
                        e = e.data("tooltip") || !1,
                        t = (console.log(e), document.getElementById(t)),
                        n = { start: n, connect: a, direction: p.State.isRTL ? "rtl" : "ltr", range: { min: i, max: o }, margin: s, limit: r, step: c, orientation: l, tooltips: e },
                        a = d ? f(n, d) : n;
                    noUiSlider.create(t, a);
                });
        }),
        (p.Range.init = function () {
            p.Range(".form-control-slider"), p.Range(".form-range-slider");
        }),
        (p.Select2.init = function () {
            p.Select2(".js-select2");
        }),
        (p.Slick = function (e, t) {
            x(e).exists() &&
                "function" == typeof x.fn.slick &&
                x(e).each(function () {
                    var e = {
                        prevArrow: '<div class="slick-arrow-prev"><a href="javascript:void(0);" class="slick-prev"><em class="icon ni ni-chevron-left"></em></a></div>',
                        nextArrow: '<div class="slick-arrow-next"><a href="javascript:void(0);" class="slick-next"><em class="icon ni ni-chevron-right"></em></a></div>',
                        rtl: p.State.isRTL,
                    },
                        e = t ? f(e, t) : e;
                    x(this).slick(e);
                });
        }),
        (p.Slider.init = function () {
            p.Slick(".slider-init");
        }),
        (p.Lightbox = function (e, t, n) {
            x(e).exists() &&
                x(e).each(function () {
                    var e = {},
                        e =
                            "video" == t || "iframe" == t
                                ? {
                                    type: "iframe",
                                    removalDelay: 160,
                                    preloader: !0,
                                    fixedContentPos: !1,
                                    callbacks: {
                                        beforeOpen: function () {
                                            (this.st.image.markup = this.st.image.markup.replace("mfp-figure", "mfp-figure mfp-with-anim")), (this.st.mainClass = this.st.el.attr("data-effect"));
                                        },
                                    },
                                }
                                : "content" == t
                                    ? { type: "inline", preloader: !0, removalDelay: 400, mainClass: "mfp-fade content-popup" }
                                    : { type: "image", mainClass: "mfp-fade image-popup" },
                        e = n ? f(e, n) : e;
                    x(this).magnificPopup(e);
                });
        }),
        (p.Control = function (e) {
            document.querySelectorAll(e).forEach(function (e, t, n) {
                e.checked && e.parentNode.classList.add("checked"),
                    e.addEventListener("change", function () {
                        "checkbox" == e.type && (e.checked ? e.parentNode.classList.add("checked") : e.parentNode.classList.remove("checked")),
                            "radio" == e.type &&
                            (document.querySelectorAll('input[name="' + e.name + '"]').forEach(function (e, t, n) {
                                e.parentNode.classList.remove("checked");
                            }),
                                e.checked) &&
                            e.parentNode.classList.add("checked");
                    });
            });
        }),
        (p.NumberSpinner = function (e, t) {
            var a = document.querySelectorAll("[data-number='plus']"),
                i = document.querySelectorAll("[data-number='minus']");
            a.forEach(function (e, t, n) {
                a[t].parentNode;
                a[t].addEventListener("click", function () {
                    var s = a[t].parentNode.children;
                    s.forEach(function (e, t, n) {
                        var a, i, o;
                        s[t].classList.contains("number-spinner") &&
                            ((a = "" == !s[t].value ? parseInt(s[t].value) : 0), (i = "" == !s[t].step ? parseInt(s[t].step) : 1), (o = "" == !s[t].max ? parseInt(s[t].max) : 1 / 0), (s[t].value = a + i < o + 1 ? a + i : a));
                    });
                });
            }),
                i.forEach(function (e, t, n) {
                    i[t].parentNode;
                    i[t].addEventListener("click", function () {
                        var s = i[t].parentNode.children;
                        s.forEach(function (e, t, n) {
                            var a, i, o;
                            s[t].classList.contains("number-spinner") &&
                                ((a = "" == !s[t].value ? parseInt(s[t].value) : 0), (i = "" == !s[t].step ? parseInt(s[t].step) : 1), (o = "" == !s[t].min ? parseInt(s[t].min) : 0), (s[t].value = o - 1 < a - i ? a - i : a));
                        });
                    });
                });
        }),
        (p.Custom.Stepper = function (n, e) {
            var t = !(!n.dataset.stepInit || isNaN(n.dataset.stepInit)) && parseInt(n.dataset.stepInit),
                t = {
                    selectors: {
                        nav: e.selectors.nav || "stepper-nav",
                        progress: e.selectors.progress || "stepper-progress",
                        content: e.selectors.content || "stepper-steps",
                        prev: e.selectors.prev || "step-prev",
                        next: e.selectors.next || "step-next",
                        submit: e.selectors.submit || "step-submit",
                    },
                    classes: { nav_current: e.classes.nav_current || "current", nav_done: e.classes.nav_done || "done", step_active: e.classes.step_active || "active", step_done: e.classes.step_done || "done" },
                    current_step: t || parseInt(e.current_step),
                },
                a = n.querySelectorAll(".".concat(t.selectors.nav, " > *")),
                i = n.querySelectorAll(".".concat(t.selectors.content, " > *")),
                o = (n.querySelector(".".concat(t.selectors.progress)), n.querySelector(".".concat(t.selectors.progress, "-count"))),
                s = n.querySelector(".".concat(t.selectors.progress, "-bar")),
                r = n.querySelector(".".concat(t.selectors.prev)),
                c = n.querySelector(".".concat(t.selectors.next)),
                l = n.querySelector(".".concat(t.selectors.submit)),
                d = t.classes.nav_current,
                p = t.classes.nav_done,
                u = t.classes.step_active,
                f = t.classes.step_done,
                e = t.current_step || 1,
                g = e,
                m = a.length,
                h = i.length,
                v = 0 < n.querySelectorAll(".".concat(t.selectors.nav)).length,
                b = 0 < n.querySelectorAll(".".concat(t.selectors.progress)).length;
            function k(e) {
                var t = e - 1,
                    t =
                        ((n.style.display = "block"),
                            v &&
                            (a.forEach(function (e, t) {
                                e.classList.remove(d);
                            }),
                                a[t].classList.add(d)),
                            i.forEach(function (e, t) {
                                e.classList.remove(u);
                            }),
                            i[t].classList.add(u),
                            e);
                1 === t && ((c.style.display = "block"), (r.style.display = "none"), (l.style.display = "none"), n.setAttribute("data-step-current", "first")),
                    (h !== t) & (1 !== t) && ((r.style.display = "block"), (c.style.display = "block"), (l.style.display = "none"), n.setAttribute("data-step-current", t)),
                    h === t && ((r.style.display = "block"), (l.style.display = "block"), (c.style.display = "none"), n.setAttribute("data-step-current", "last")),
                    b && ((o.innerHTML = "".concat(e, " of ").concat(h)), (s.style.width = "".concat((100 / h) * e, "%")));
            }
            m !== h && v ? console.error("Stepper nav should have same amount of child element as Stepper steps") : k(e);
            var y = x("#" + n.id).validate({
                errorElement: "span",
                errorClass: "invalid",
                onfocusout: !1,
                errorPlacement: function (e, t) {
                    t.parents().hasClass("input-group") ? e.appendTo(t.parent().parent()) : e.appendTo(t.parent());
                },
            });
            r.querySelector("button").addEventListener("click", function (e) {
                e.preventDefault();
                var e = y.form(),
                    t = g - 1;
                e ? h !== g && (v && a[t].classList.add(p), i[t].classList.add(f)) : (v && a[t].classList.remove(p), i[t].classList.remove(f)), k(--g);
            }),
                c.querySelector("button").addEventListener("click", function (e) {
                    e.preventDefault(), y.form() && ((e = g - 1), v && a[e].classList.add(p), i[e].classList.add(f), k(++g));
                }),
                l.querySelector("button").addEventListener("click", function (e) {
                    e.preventDefault(), y.form();
                });
        }),
        (p.Stepper = function (e, a) {
            e = document.querySelectorAll(e);
            0 < e.length &&
                e.forEach(function (e, t) {
                    var n = {
                        selectors: { nav: "stepper-nav", progress: "stepper-progress", content: "stepper-steps", prev: "step-prev", next: "step-next", submit: "step-submit" },
                        classes: { nav_current: "current", nav_done: "done", step_active: "active", step_done: "done", active_step: "active" },
                        current_step: 1,
                    },
                        n = a ? f(n, a) : n;
                    p.Custom.Stepper(e, n), p.Validate.OnChange(".js-select2"), p.Validate.OnChange(".date-picker"), p.Validate.OnChange(".js-tagify");
                });
        }),
        (p.Stepper.init = function () {
            p.Stepper(".stepper-init");
        }),
        (p.Tagify = function (e, t) {
            x(e).exists() && "function" == typeof x.fn.tagify && ((t = t ? f(void 0, t) : void 0), x(e).tagify(t));
        }),
        (p.Tagify.init = function () {
            p.Tagify(".js-tagify");
        }),
        (p.Preloader = function () {
            var e = x(".js-preloader");
            e.exists() && (a.addClass("page-loaded"), e.delay(600).fadeOut(300));
        }),
        (p.OtherInit = function () {
            p.ClassBody(),
                p.PassSwitch(),
                p.CurrentLink(),
                p.LinkOff(".is-disable"),
                p.ClassNavMenu(),
                p.menuSwitch(),
                p.SetHW("[data-height]", "height"),
                p.SetHW("[data-width]", "width"),
                p.NumberSpinner(),
                p.Lightbox(".popup-video", "video"),
                p.Lightbox(".popup-iframe", "iframe"),
                p.Lightbox(".popup-image", "image"),
                p.Lightbox(".popup-content", "content"),
                p.Control(".custom-control-input");
        }),
        (p.Ani.init = function () {
            p.Ani.formElm(".form-control-outlined"), p.Ani.formSearch(".toggle-search");
        }),
        (p.BS.init = function () {
            p.BS.menutip("a.nk-menu-link"),
                p.BS.tooltip(".nk-tooltip"),
                p.BS.tooltip(".btn-tooltip", { placement: "top" }),
                p.BS.tooltip('[data-bs-toggle="tooltip"]'),
                p.BS.tooltip(".tipinfo,.nk-menu-tooltip", { placement: "right" }),
                p.BS.popover('[data-bs-toggle="popover"]'),
                p.BS.progress("[data-progress]"),
                p.BS.fileinput(".form-file-input"),
                p.BS.modalfix(),
                p.BS.ddfix(),
                p.BS.tabfix();
        }),
        (p.Picker.init = function () {
            p.Picker.date(".date-picker"),
                p.Picker.dob(".date-picker-alt"),
                p.Picker.time(".time-picker"),
                p.Picker.date(".date-picker-range", { todayHighlight: !1, autoclose: !1 }),
                p.Picker.date(".date-picker-ym", { format: "mm/yy", startView: 2, autoclose: !0, maxViewMode: 2, minViewMode: 1 });
        }),
        (p.Addons.Init = function () {
            p.Knob.init(), p.Range.init(), p.Select2.init(), p.Slider.init(), p.DataTable.init(), p.Tagify.init();
        }),
        (p.TGL.init = function () {
            p.TGL.content(".toggle"), p.TGL.expand(".toggle-expand"), p.TGL.expand(".toggle-opt", { toggle: !1 }), p.TGL.showmenu(".nk-nav-toggle"), p.TGL.ddmenu("." + e + "-toggle", { self: e + "-toggle", child: e + "-sub" });
        }),
        (p.BS.modalOnInit = function () {
            x(".modal").on("shown.bs.modal", function () {
                p.Select2.init(), p.Validate.init();
            });
        }),
        (p.init = function () {
            p.coms.docReady.push(p.OtherInit),
                p.coms.docReady.push(p.Prettify),
                p.coms.docReady.push(p.ColorBG),
                p.coms.docReady.push(p.ColorTXT),
                p.coms.docReady.push(p.Copied),
                p.coms.docReady.push(p.Ani.init),
                p.coms.docReady.push(p.TGL.init),
                p.coms.docReady.push(p.BS.init),
                p.coms.docReady.push(p.Validate.init),
                p.coms.docReady.push(p.Picker.init),
                p.coms.docReady.push(p.Addons.Init),
                // p.coms.docReady.push(p.Wizard),
                p.coms.docReady.push(p.Stepper.init),
                p.coms.winLoad.push(p.ModeSwitch),
                p.coms.winLoad.push(p.Preloader);
        }),
        p.init();
})(NioApp, jQuery);

$.copyToClipboard = function (element) {
    var $temp = $("<input>");
    $("body").append($temp);
    $temp.val($(element).text()).select();
    document.execCommand("copy");
    toastr["success"]("Copied: " + $(element).text());
    $temp.remove();
};


if (window.history.replaceState) {
    window.history.replaceState(null, null, window.location.href);
}

if (window.self !== window.top) {
    window.top.location.href = window.location.href;
}
if (top == self) {
    document.documentElement.style.display = "block";
} else {
    top.location = self.location;
}

function showProgress() {
    $('body').append(`
        <div class="custom-loader-progress-modal-body" id="progressbar">
        <div class="custom-loader-progress-modal" tabindex="-1" style="display: block;">
            <div class="custom-loader-progress-title">
                Processing...
            </div>
            <div class="custom-loader-progress-container">
                <div class="custom-loader-progress-bar-left custom-loader-progress-bar-common"></div>
                <div class="custom-loader-progress-bar-center custom-loader-progress-bar-common"></div>
                <div class="custom-loader-progress-bar-right custom-loader-progress-bar-common"></div>
            </div>
        </div>
        </div>
    `);
}

function hideProgress() {
    setTimeout(function () {
        $('#progressbar').remove();
    }, 500);
}

function containsSpecialChars(str) {
    // Check if str is a string
    if (typeof str !== "string") {
        return false; // If not a string, return false
    }

    var specialChars = "`=[]\\;'~!@$%^&*()+{}|:\"<>?";
    for (var i = 0; i < specialChars.length; i++) {
        if (str.indexOf(specialChars.charAt(i)) >= 0) {
            return true;
        }
    }
    return false;
}


$(document).ready(function () {
    $("body").removeClass("getting-loader");
    $('body').on('input', 'input[type="tel"]', function () {
        if (isNaN($(this).val())) {
            toastr["error"]("enter only numbers");
            $(this).val('');
            return;
        }
    });
    $('body').on('blur', 'input[type="email"]', function () {
        const email = $(this).val();
        const emailRegex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

        if (!emailRegex.test(email)) {
            toastr["error"]("enter a valid email address");
            $(this).val('');
            return;
        }
    });

    $('body').on('blur', 'input[type="password"]', function () {
        if (password.length < 8 || password.length > 18) {
            toastr["error"]("password must be between 8 and 18 characters"); $(this).val('');
        } 
        // else if (!containsSpecialChars(password)) {
        //     toastr["error"]("password must contain at least one special character"); $(this).val('');
        // }
    }).on('copy paste cut drag drop', 'input[type="password"]', function (e) {
        e.preventDefault();
        toastr["error"]("policy not allowed to perform this action"); $(this).val('');
        return false;
    });
})