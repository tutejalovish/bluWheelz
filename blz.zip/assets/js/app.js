import { toast } from "./libs/wc-toast/index.js"

myToast = toast;