const { hrmsDB } = require("../../config/database");


exports.empApplyStatge1 = async (req, res) => {
    try {

        const stmt = await hrmsDB.query("SELECT aadhaar FROM tbl_hiring WHERE aadhaar = :uid", {
            replacements: {
                uid: req.body.aadhaar,
            },
            type: hrmsDB.QueryTypes.SELECT,
        });
        if (stmt.length > 0) {
            return res.status(500).json({ code: 500, status: "error", message: "Aadhaar already exists" });
        }
        const stmt2 = await hrmsDB.query("SELECT vacancy_name FROM vacancy WHERE vacancy_id = :post", {
            replacements: {
                post: req.body.post,
            },
            type: hrmsDB.QueryTypes.SELECT,
        });
        if (stmt2.length == 0) {
            return res.status(500).json({ code: 500, status: "error", message: "Invalid post" });
        }
        const stmt0 = await hrmsDB.query("INSERT INTO tbl_hiring(f_name,l_name,dob,mobile,email,aadhaar,vaccancy_name,interview_dt,insert_dt,unique_no) VALUES(:fname,:lname,:dob,:mobile,:email,:aadhaar,:post_name,:interview_dt,:insert_dt,:unique)", {
            replacements: {
                fname: req.body.f_name,
                lname: req.body.l_name,
                dob: moment(req.body.dob).format("YYYY-MM-DD"),
                mobile: req.body.mobile,
                email: req.body.email ?? "--",
                aadhaar: req.body.aadhaar,
                post_name: req.body.post,
                interview_dt: moment(req.body.interview_date, "DD-MM-YYYY").format("YYYY-MM-DD"),
                insert_dt: moment(new Date()).format("YYYY-MM-DD HH:mm:ss"),
                unique: helper.getUniqueNumber(),
            },
            type: hrmsDB.QueryTypes.INSERT,
        });
        if (stmt0.length == 0) {
            return res.status(500).json({ code: 500, status: "error", message: "Something went wrong" });
        }

        return res.status(200).json({ code: 200, status: "success", message: "Recruitment submitted successfully" });

    }
    catch (err) {
        return helper.crashRes(res, err);
    }
}

exports.confirmForm = async (req, res) => {
    const t = await hrmsDB.transaction();
    try {

        const stmt0 = await hrmsDB.query("SELECT * FROM tbl_hiring WHERE unique_no = :uid ", {
            replacements: {
                uid: req.logedINUser,
            },
            type: hrmsDB.QueryTypes.SELECT,
        });

        if (stmt0.length == 0) {
            t.rollback();
            return res.status(500).json({ code: 500, status: "error", message: { msg: "Unique id not found" } });
        }

        if (stmt0[0].status !== "A") {
            t.rollback();
            return res.status(500).json({ code: 500, status: "error", message: { msg: "You are not eligible for submit further details" } });
        }

        // 
        const stmt1 = await hrmsDB.query("INSERT INTO tbl_emp_basic(emp_code,emp_f_name,emp_l_name,emp_dob,emp_gender,emp_doj,emp_mobile,emp_email) VALUES (:emp_code,:emp_f_name,:emp_l_name,:emp_dob,:emp_gender,:emp_doj,:emp_mobile,:emp_email) ", {
            replacements: {
                emp_code: req.logedINUser,
                emp_f_name: stmt0[0].f_name ?? "",
                emp_l_name: stmt0[0].l_name ?? "",
                emp_dob: stmt0[0].dob ?? "",
                emp_gender: req.body.gender,
                emp_doj: req.body.doj,
                emp_mobile: stmt0[0].mobile ?? "",
                emp_email: stmt0[0].email ?? "",
            },
            transaction: t,
            type: hrmsDB.QueryTypes.INSERT,
        });

        const stmt2 = await hrmsDB.query("INSERT INTO tbl_emp_family(emp_code,emp_father_name,emp_mother_name,emp_married) VALUES (:emp_code,:father,:mother,:married) ", {
            replacements: {
                emp_code: req.logedINUser,
                father: req.body.father_name,
                mother: req.body.mother_name,
                married: req.body.married_status,
            },
            transaction: t,
            type: hrmsDB.QueryTypes.INSERT,
        });
        const stmt4 = await hrmsDB.query("INSERT INTO tbl_emp_benifits(emp_code,emp_uan,emp_esi) VALUES (:emp_code,:emp_uan,:emp_esi) ", {
            replacements: {
                emp_code: req.logedINUser,
                emp_uan: req.body.uan,
                emp_esi: req.body.esi,
            },
            transaction: t,
            type: hrmsDB.QueryTypes.INSERT,
        });

        let stmt5 = await hrmsDB.query("SELECT * FROM `tbl_emp_education` WHERE `emp_code` = :employee_code AND `emp_passed_exam` = :exam", {
            replacements: {
                employee_code: req.logedINUser,
                exam: req.body.exam,
            },
            type: hrmsDB.QueryTypes.SELECT,
        });

        if (stmt5.length > 0) {
            t.rollback();
            return res.status(500).json({ code: 500, message: { msg: "education already mapped" }, status: "error", });
        } else {
            let stmt6 = await hrmsDB.query(
                "INSERT INTO `tbl_emp_education` ( `emp_code`, `emp_passed_exam`, `emp_passed_subject`,`emp_passed_score`, `emp_passed_board`, `emp_passed_year`, `education_code`, `insert_dt`) VALUES ( :emp_code, :emp_passed_exam, :emp_passed_subject, :emp_passed_score, :emp_passed_board, :emp_passed_year, :education_code, :insert_dt)",
                {
                    replacements: {
                        emp_code: req.logedINUser,
                        emp_passed_exam: req.body.exam,
                        emp_passed_subject: req.body.subject,
                        emp_passed_score: req.body.score,
                        emp_passed_board: req.body.board,
                        emp_passed_year: req.body.year,
                        education_code: helper.getUniqueNumber(),
                        insert_dt: moment(new Date()).tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss"),
                    },
                }
            );
        }
        if (stmt1.length == 0 || stmt2.length == 0 || stmt4.length == 0) {
            t.rollback();
            return res.status(500).json({ code: 500, status: "error", message: { msg: "Something went wrong" } });
        }
        // 

        t.commit();

        return res.json({ code: 200, status: "success", message: { msg: "Thank you for your registration" } });




    } catch (err) {
        t.rollback();
        return helper.crashRes(res, err);
    }
}