const { hrmsDB } = require("../../config/database")

const wpHelper = require('../../helper/wpHelper');
const helper = require("../../helper/helper");


const XLSX = require('xlsx');
const moment = require("moment");

// SEND BULK SMS FROM EXCEL CONSTROLLER
const send = async (req, res) => {
    try {



        const file = req.file;
        const fileUrl = file.path;

        // READ AND GET DATA FROM EXCEL
        const workbook = XLSX.readFile(fileUrl);
        const sheet_name_list = workbook.SheetNames;
        const xlData = XLSX.utils.sheet_to_json(workbook.Sheets[sheet_name_list[0]]);
        // GET MESSAGE FROM REQUEST BODY
        const { message } = req.body;

        let totalTime = 0;

        const insert_date = moment().format("YYYY-MM-DD HH:mm:ss");

        for (let i = 0; i < xlData.length; i++) {

            // SET RANDOM MINUTE TIMER
            // const timer = Math.random() * (90000 - 30000) + 30000;
            // totalTime += timer;

            // setTimeout(async () => {

            let msgBody = message.replace(/{fname}/g, xlData[i].First_name).replace(/{lname}/g, xlData[i].Last_name);

            // const response = await wpHelper.send({ message: msgBody, chatId: xlData[i].Mobile_no });

            // console.log(response?.response);

            const result = await hrmsDB.query("INSERT INTO wp_send_msg( campaign , wp_number, wp_message, insert_by, insert_dt) VALUES ( :campaign , :wp_number, :wp_message, :insert_by, :insert_dt)", {
                replacements: {
                    campaign: req.body.campaign,
                    wp_number: xlData[i].Mobile_no,
                    wp_message: msgBody,
                    insert_by: req.logedINUser,
                    insert_dt: insert_date
                },
                type: hrmsDB.QueryTypes.INSERT
            });

            //     }, i * timer);
        }

        return res.json({ success: true, message: "Bulk SMS sent successfully", code: 200 });
    }
    catch (err) {
        return helper.crashRes(res, err);
    }
}

const getCampaign = async (req, res, search) => {
    try {

        let stmt;

        if (search == null) {
            stmt = await hrmsDB.query("SELECT campaign FROM wp_send_msg GROUP BY campaign LIMIT 100", {
                type: hrmsDB.QueryTypes.SELECT
            });
        } else {
            stmt = await hrmsDB.query("SELECT campaign FROM wp_send_msg WHERE campaign LIKE :search GROUP BY campaign LIMIT 100", {
                replacements: {
                    search: `%${search}%`
                }
            })
        }



        if (stmt.length <= 0) {
            return res.status(500).json({ success: false, message: "No campaign found", code: 500 });
        }


        const data = [];

        for (let i = 0; i < stmt.length; i++) {
            data.push({ id: stmt[i].campaign, text: stmt[i].campaign });
        }

        return res.status(200).json({ success: true, data: data, code: 200 });

    } catch (err) {
        return helper.crashRes(res, err);
    }
}

const fetchList = async (req, res) => {
    try {

        const stmt = await hrmsDB.query("SELECT * FROM wp_send_msg WHERE campaign = :campaign", {
            replacements: {
                campaign: req.body.campaign
            },
            type: hrmsDB.QueryTypes.SELECT
        });

        if (stmt.length <= 0) {
            return res.status(500).json({ success: false, message: "No campaign found", code: 500 });
        }

        const data = [];


        for (let i = 0; i < stmt.length; i++) {
            data.push({
                status : stmt[i].send_status,
                number : stmt[i].wp_number,
                message : stmt[i].wp_message,
                campaign : stmt[i].campaign,
            })
        }

        return res.status(200).json({ success: true, data: data, code: 200 });

    }
    catch (err) {
        return helper.crashRes(res, err);
    }

}

module.exports = {
    send,
    getCampaign,
    fetchList
}