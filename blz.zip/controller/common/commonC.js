const { hrmsDB } = require("../../config/database")
exports.fetchContractor = async function (req, res) {
    const limit = 10;
    let stmt;
    if (req.body.searchTerm) {
        stmt = await hrmsDB.query("SELECT `payroll_key`,`payroll_name` FROM `master_payroll` WHERE `contractor_status` = 'A' AND (`payroll_name` like :name) ORDER BY `payroll_name` LIMIT :limit", {
            replacements: {
                name: `%${req.body.searchTerm}%`,
                limit: limit,
            },
            type: hrmsDB.QueryTypes.SELECT,
        });
    } else {
        stmt = await hrmsDB.query("SELECT `payroll_key`,`payroll_name` FROM `master_payroll` WHERE `contractor_status` = 'A' ORDER BY `payroll_name` ASC LIMIT :limit", {
            replacements: {
                limit: limit,
            },
            type: hrmsDB.QueryTypes.SELECT,
        });
    }

    let final = [];

    stmt.map((item) => {
        final.push({
            id: item.payroll_key,
            text: item.payroll_name,
        });

        if (stmt.length == final.length) {
            res.json(final);
            return;
        }
    });
}

exports.fetchBranch = async function (req, res) {
    let stmt0 = await hrmsDB.query("SELECT `payroll_key` FROM `master_payroll` WHERE payroll_key  = :contractor ORDER BY ID LIMIT 1", {
        replacements: { contractor: req.body.contractor },
        type: hrmsDB.QueryTypes.SELECT,
    },
    );

    let final = [];
    if (stmt0.length > 0) {
        let stmt1 = await hrmsDB.query(
            "SELECT * FROM `master_branch` WHERE company_key  = :contractor ORDER BY ID DESC",
            {
                replacements: { contractor: req.body.contractor },
                type: hrmsDB.QueryTypes.SELECT,
            },
        );
        const length = stmt1.length;
        for (let i = 0; i < length; i++) {
            final.push({
                id: stmt1[i].branch_key,
                text: stmt1[i].branch_name,
            });
        }

        return res.json({ code: 200, status: "success", data: final });
    } else {
        return res.json([{ id: "0", text: "Payroll not found" }]);
    }
}

exports.fetchVacancy = async (req, res) => {
    const stmt = await hrmsDB.query("SELECT vacancy_key as code , vacancy_name as name FROM vacancy_master", {
        type: hrmsDB.QueryTypes.SELECT,
    });

    if(stmt.length > 0){
        const data = [];
        for (let i = 0; i < stmt.length; i++) {
            data.push({
                id: stmt[i].code,
                text: stmt[i].name
            })
        }
        return res.json({ code: 200, status: "success", data: data });
    }

}

exports.fetchActiveVacancyRole = async(req,res) => {
    const stmt = await hrmsDB.query("SELECT aadhaar FROM vacancy WHERE aadhaar = :uid", {
        
    })
}