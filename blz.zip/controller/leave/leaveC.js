const { hrmsDB } = require("../../config/database");
const helper = require("../../helper/helper");
const Validator = require("validatorjs");
const moment = require("moment");
const { v4: uuidv4, v4 } = require("uuid");
// const sendInternalMail = require("./leaveHelper");
const { createLeaveStageprocess, sendExtApproveMail, sendExtFarwardMail, mailTemplate, leave, sendInternalMail } = require("./leaveHelper");
const { name } = require("../../model/JobsM");

const today = moment().startOf("day"); // Get the start of today
const minAllowedDate = moment(today).subtract(7, "days");
const maxAllowedDate = moment(today).add(15, "days");

exports.getBalance = async (req, res) => {
  try {
    let leaveBalanceData = 0,
      sessionOptionsData = null;

    if (req.body.type == "CL") {
      const compBalance = await hrmsDB.query(`SELECT COALESCE(SUM(leave_balance), 0) as balance FROM compensatory_leave_balance WHERE empcode = :empcode  AND STR_TO_DATE(leave_validity, '%Y-%m-%d') > '${moment().format("YYYY-MM-DD")}' `, {
        replacements: {
          empcode: req.body.empCode,
        },
        type: hrmsDB.QueryTypes.SELECT,
      });

      leaveBalanceData = { balance: parseFloat(compBalance[0].balance) };
    }

    // Query for leave balance
    const leaveBalanceStmt = await hrmsDB.query(
      "SELECT (SELECT COALESCE(SUM(total_days), 0) FROM tbl_leave_request WHERE leave_status = 'PEN' AND empcode = :empcode AND leave_type = :type AND DATE_FORMAT(date_from,'%Y-%m') = :currentMonth) AS shadow_balance, COALESCE(tbl_leave_log.month_leave_bal, 0) AS available_balance FROM tbl_leave_log WHERE month_leave_type = :type AND leave_empcode = :empcode AND leave_month = :currentMonth ORDER BY ID DESC LIMIT 1",
      {
        replacements: {
          type: req.body.type,
          empcode: req.body.empCode,
          currentMonth: moment(req.body.startDate, "DD-MM-YYYY").format("YYYY-MM"),
        },
        type: hrmsDB.QueryTypes.SELECT,
      }
    );

    if (leaveBalanceStmt.length > 0) {
      leaveBalanceData = { balance: helper.number(leaveBalanceStmt[0].available_balance - leaveBalanceStmt[0].shadow_balance) };
    }

    // Query for session options
    const sessionOptionsStmt = await hrmsDB.query("SELECT * FROM master_session WHERE leave_type = :type ORDER BY ID DESC LIMIT 1", {
      replacements: {
        type: req.body.type,
      },
      type: hrmsDB.QueryTypes.SELECT,
    });

    if (sessionOptionsStmt.length == 0) {
      return res.status(400).json({ message: "No session found" });
    }

    if (sessionOptionsStmt.length > 0) {
      sessionOptionsData = {
        options: sessionOptionsStmt[0].leave_session_tm.split(",").map((range, index) => ({
          value: helper.number(index + 1),
          label: range.trim(),
        })),
      };
    }

    return res.json({
      code: 200,
      status: "success",
      data: {
        leaveBalance: leaveBalanceData,
        leaveOptions: sessionOptionsData,
        sessionValue: sessionOptionsStmt[0].leave_session_count ?? 0,
        approval_level: "", // hierarchyLevels,
        total_level: "", // totalLevels,
      },
    });
  } catch (err) {
    return helper.crashRes(res, err);
  }
};

exports.calculate = async (req, res) => {
  try {
    const fromDt = req.body.startDate;
    const fromSession = req.body.startSession;
    const toDt = req.body.endDate;
    const toSession = req.body.endSession;

    const fromDate = moment(fromDt, "DD-MM-YYYY");
    const toDate = moment(toDt, "DD-MM-YYYY");

    // Query to Get Session Information
    const sessionStmt = await hrmsDB.query("SELECT * FROM master_session WHERE leave_type = :type ORDER BY ID DESC LIMIT 1", {
      replacements: {
        type: req.body.leaveType,
      },
      type: hrmsDB.QueryTypes.SELECT,
    });
    if (sessionStmt.length == 0) {
      return res.json({
        code: 500,
        status: "error",
        message: { msg: "session not configured in system" },
      });
    }

    const totalSessions = sessionStmt[0].leave_session_count;
    const sessionDurations = sessionStmt[0].leave_session_value
      .split(",")
      .map((pair) => pair.split(":").map((value) => value.trim()))
      .reduce((acc, [key, value]) => {
        acc[key] = parseFloat(value);
        return acc;
      }, {});
    let calculation = 0;

    if (req.body.leaveType == "OD") {
      const timezone = "Asia/Kolkata"; // India IST timezone
      // if (!moment(fromDt, "DD-MM-YYYY").tz(timezone).isSame(moment(toDt, "DD-MM-YYYY").tz(timezone), "day")) {
      //   return res.status(400).json({ message: "for OD leave, start and end dates must be the same" });
      // }
      let totalHours = 0;
      let totalMinutes = 0;

      const startSessionTime = sessionStmt[0].leave_session_tm.split(",")[fromSession - 1].split("-")[0].trim();
      const endSessionTime = sessionStmt[0].leave_session_tm.split(",")[toSession - 1].split("-")[1].trim();

      const startMoment = moment(startSessionTime, "hh:mm A").tz(timezone);
      const endMoment = moment(endSessionTime, "hh:mm A").tz(timezone);

      totalHours = endMoment.diff(startMoment, "hours");
      totalMinutes = endMoment.diff(startMoment, "minutes") % 60;

      calculation = totalHours + " h & " + totalMinutes + " m";
    } else if (req.body.leaveType == "WFH" || req.body.leaveType == "EL" || req.body.leaveType == "SL" || req.body.leaveType == "CL" || req.body.leaveType == "ACL" || req.body.leaveType == "LWP") {
      let currentDate = fromDate.clone();

      while (currentDate.isSameOrBefore(toDate)) {
        const currentDaySessionStart = currentDate.isSame(fromDate) ? fromSession : 1;
        const currentDaySessionEnd = currentDate.isSame(toDate) ? toSession : totalSessions;

        for (let i = currentDaySessionStart; i <= currentDaySessionEnd; i++) {
          calculation += sessionDurations[i] || 0; // Use 0 if session number not found in sessionDurations
        }

        currentDate.add(1, "day");
      }
    } else {
      return res.status(400).json({ message: "leave type not configured in system" });
    }

    return res.json({
      code: 200,
      data: {
        currentBooking: calculation,
      },
    });
  } catch (err) {
    return helper.crashRes(res, err);
  }
};

exports.sendLWPRequest = async (req, res) => {
  const t = await hrmsDB.transaction();
  try {
    const format = "DD-MM-YYYY";
    var fromDt = req.body.startDate;
    var fromSession = req.body.startSession;
    var toDt = req.body.endDate;
    var toSession = req.body.endSession;
    var applicationID = helper.uniqueID("REQ");
    const fromDate = moment(fromDt, format);
    const toDate = moment(toDt, format);

    var leaveReason = req.body.reason.replace(/\n/g, "<br>");
    var leaveType = req.body.type;
    //////////////////////////////////////////////////////////////////
    let calls = await leave(fromDt, toDt, fromSession, toSession, req, leaveType, req.body.empCode);
    /////////////////////////////////////////////////////////////////
         
    let diffDays = moment(moment()).diff(moment(fromDate, format), "days") + 1;

    let backDays = await helper.checkLeaveBackDays(req);
    if (backDays < diffDays) {
      t.rollback();
      return res.json({
        code: 500,
        status: "error",
        message: { msg: "Back Date not allowed" },
      });
    }

    if (calls && calls.code && calls.status === "error" && calls.message && calls.message.msg) {
      t.rollback();
      return res.json({
        code: calls.code,
        status: calls.status,
        message: calls.message,
      });
    }

    var mail_calculation, mail_report_officer, mail_application, mail_leave_balance;
    const totalSessions = calls[0].leave_session_count;
    const sessionDurations = calls[0].leave_session_value
      .split(",")
      .map((pair) => pair.split(":").map((value) => value.trim()))
      .reduce((acc, [key, value]) => {
        acc[key] = parseFloat(value);
        return acc;
      }, {});

    let calculation = 0;
    let currentDate = fromDate.clone();

    while (currentDate.isSameOrBefore(toDate)) {
      const currentDaySessionStart = currentDate.isSame(fromDate) ? fromSession : 1;
      const currentDaySessionEnd = currentDate.isSame(toDate) ? toSession : totalSessions;

      for (let i = currentDaySessionStart; i <= currentDaySessionEnd; i++) {
        calculation += sessionDurations[i] || 0; // Use 0 if session number not found in sessionDurations

        await hrmsDB.query("INSERT INTO tbl_leave_breakup (date, session, day, start_time, end_time, leave_transaction, emp_code, leave_type, leave_status) VALUES (:date, :session, :day, :start_time, :end_time, :leave_transaction, :emp_code, :leave_type, :leave_status)", {
          replacements: {
            date: currentDate.format("YYYY-MM-DD"),
            session: i,
            day: sessionDurations[i] || 0, // Use 0 if session number not found in sessionDurations
            start_time: calls[0].leave_session_tm.split(",")[i - 1].split("-")[0].trim(),
            end_time: calls[0].leave_session_tm.split(",")[i - 1].split("-")[1].trim(),
            leave_transaction: applicationID,
            emp_code: req.body.empCode,
            leave_type: req.body.type,
            leave_status: "PEN",
          },
          type: hrmsDB.QueryTypes.INSERT,
          transaction: t,
        });
      }

      currentDate.add(1, "day");
    }

    let reportofficer = await hrmsDB.query("SELECT tbl_emp_basic.emp_code, tbl_emp_basic.emp_email, emp_report_manager.reporting_manager FROM emp_report_manager LEFT JOIN tbl_emp_basic ON tbl_emp_basic.emp_code = emp_report_manager.reporting_manager WHERE emp_report_manager.emp_code = :empcode ORDER BY emp_report_manager.ID DESC LIMIT 1", {
      replacements: {
        empcode: req.body.empCode,
      },
      type: hrmsDB.QueryTypes.SELECT,
    });
    if (reportofficer.length == 0) {
      t.rollback();
      return res.json({
        code: 500,
        status: "error",
        message: { msg: "reporting officer not assigned, pls contact to your HR" },
      });
    }

    let stmt = await hrmsDB.query(
      "INSERT INTO tbl_leave_request (empcode , leave_status , leave_type , date_from , date_to , total_days, leave_remark, leave_cc, leave_indt, leave_by, leave_transaction, request_to, leave_attachment) VALUES (:empcode , :leave_status , :leave_type , :date_from , :date_to , :total_days, :leave_remark, :leave_cc, :leave_indt, :leave_by, :leave_transaction, :request_to,:file)",
      {
        replacements: {
          empcode: req.body.empCode,
          leave_status: "PEN",
          leave_type: leaveType,
          date_from: moment(fromDt, "DD-MM-YYYY").format("YYYY-MM-DD"),
          date_to: moment(toDt, "DD-MM-YYYY").format("YYYY-MM-DD"),
          total_days: calculation,
          leave_remark: leaveReason + "<br/><br/>=========<br/>Note: This request is generated by Human Resource Management. <br/>=========",
          leave_cc: "--",
          leave_indt: moment(new Date()).tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss"),
          leave_by: req.logedINUser,
          leave_transaction: applicationID,
          request_to: reportofficer[0].emp_code,
          file: req.file ? req.file.filename : "--"
        },
        type: hrmsDB.QueryTypes.INSERT,
        transaction: t,
      }
    );

    if (stmt.length > 0) {
      (mail_calculation = calculation), (mail_report_officer = reportofficer[0].emp_email), (mail_application = applicationID);
      var mail_name = await hrmsDB.query("SELECT CONCAT(emp_f_name,' ', emp_l_name) as name FROM tbl_emp_basic WHERE emp_code = :empcode", {
        replacements: {
          empcode: req.body.empCode,
        },
        type: hrmsDB.QueryTypes.SELECT,
      });
     
      let checkLeavePolicy = await hrmsDB.query("SELECT leave_policy FROM tbl_emp_basic WHERE emp_code = :empcode", {
        replacements: {
          empcode: req.body.empCode,
        },
        type: hrmsDB.QueryTypes.SELECT,
      });
      let nameLogedInUser = await hrmsDB.query("SELECT log_full_name FROM hrms_login WHERE log_user_id= :empcode", {
        replacements: {
          empcode: req.logedINUser,
        },
        type: hrmsDB.QueryTypes.SELECT,
      });
      let cc_email = [];
      for (let f = 0; f < req.body.email_cc.split(",").length; f++) {
        const cc = await hrmsDB.query("SELECT emp_email FROM tbl_emp_basic WHERE emp_code = :empcode", {
          replacements: {
            empcode: req.body.email_cc.split(",")[f],
          },
          type: hrmsDB.QueryTypes.SELECT,
        });
        cc_email.push(cc[0]?.emp_email);
      }
      if (checkLeavePolicy[0].leave_policy == "conditional") {
        await createLeaveStageprocess(req, res, t, req.body.empCode, applicationID, mail_calculation, mail_report_officer, mail_application, mail_name[0].name, cc_email, leaveType, leaveReason, fromDt, toDt, fromSession, toSession, mail_leave_balance);
      } else {
        await sendInternalMail(req, mail_calculation, mail_report_officer, mail_application, mail_name[0].name, cc_email, leaveType, leaveReason, fromDt, toDt, fromSession, toSession, mail_leave_balance, nameLogedInUser[0]?.log_full_name);
      }
      await t.commit();

      return res.json({
        code: 200,
        status: "success",
        message: "leave request sent to your approver for approval",
      });
    } else {
      t.rollback();
      return res.json({
        code: 500,
        status: "error",
        message: { msg: "an error while sending leave request to the server" },
      });
    }
  } catch (error) {
    console.log(error);
    t.rollback();
    return res.json({
      code: 500,
      status: "error",
      debug: error.stack,
      message: { msg: error.message },
    });
  }
};

exports.sendELLeaveRequest = async (req, res) => {
  const t = await hrmsDB.transaction();
  try {
   
    const format = "DD-MM-YYYY";
    var fromDt = req.body.startDate;
    var fromSession = req.body.startSession;
    var toDt = req.body.endDate;
    var toSession = req.body.endSession;
    var applicationID = helper.uniqueID("REQ");
    const fromDate = moment(fromDt, format);
    const toDate = moment(toDt, format);

    var leaveReason = req.body.reason.replace(/\n/g, "<br>");
    var leaveType = req.body.type;
    var mail_calculation, mail_report_officer, mail_application, mail_leave_balance;
    //////////////////////////////////////////////////////////////////
    let calls = await leave(fromDt, toDt, fromSession, toSession, req, leaveType, req.body.empCode, req.body.startDate);
    let diffDays = moment(moment()).diff(moment(fromDate, format), "days") + 1;

    let backDays = await helper.checkLeaveBackDays(req);
    if (backDays < diffDays) {
      t.rollback();
      return res.json({
        code: 500,
        status: "error",
        message: { msg: "Back Date not allowed" },
      });
    }

    /////////////////////////////////////////////////////////////////
    if (calls && calls.code && calls.status === "error" && calls.message && calls.message.msg) {
      t.rollback();
      return res.json({
        code: calls.code,
        status: calls.status,
        message: calls.message,
      });
    }

    const totalSessions = calls[0].leave_session_count;
    const sessionDurations = calls[0].leave_session_value
      .split(",")
      .map((pair) => pair.split(":").map((value) => value.trim()))
      .reduce((acc, [key, value]) => {
        acc[key] = parseFloat(value);
        return acc;
      }, {});

    let calculation = 0;
    let currentDate = fromDate.clone();

    while (currentDate.isSameOrBefore(toDate)) {
      const currentDaySessionStart = currentDate.isSame(fromDate) ? fromSession : 1;
      const currentDaySessionEnd = currentDate.isSame(toDate) ? toSession : totalSessions;

      for (let i = currentDaySessionStart; i <= currentDaySessionEnd; i++) {
        calculation += sessionDurations[i] || 0; // Use 0 if session number not found in sessionDurations

        await hrmsDB.query("INSERT INTO tbl_leave_breakup (date, session, day, start_time, end_time, leave_transaction, emp_code, leave_type, leave_status) VALUES (:date, :session, :day, :start_time, :end_time, :leave_transaction, :emp_code, :leave_type, :leave_status)", {
          replacements: {
            date: currentDate.format("YYYY-MM-DD"),
            session: i,
            day: sessionDurations[i] || 0, // Use 0 if session number not found in sessionDurations
            start_time: calls[0].leave_session_tm.split(",")[i - 1].split("-")[0].trim(),
            end_time: calls[0].leave_session_tm.split(",")[i - 1].split("-")[1].trim(),
            leave_transaction: applicationID,
            emp_code: req.body.empCode,
            leave_type: req.body.type,
            leave_status: "PEN",
          },
          type: hrmsDB.QueryTypes.INSERT,
          transaction: t,
        });
      }

      currentDate.add(1, "day");
    }

    // CHECK USER BALANCE FOR LEAVE APPLY
    const checkBalance = await hrmsDB.query(
      "SELECT (SELECT COALESCE(SUM(total_days), 0) FROM tbl_leave_request WHERE leave_status = 'PEN' AND empcode = :empcode AND leave_type = :type AND DATE_FORMAT(date_from,'%Y-%m') = :currentMonth) AS shadow_balance, COALESCE(tbl_leave_log.month_leave_bal, 0) AS available_balance FROM tbl_leave_log WHERE month_leave_type = :type AND leave_empcode = :empcode AND leave_month = :currentMonth ORDER BY ID DESC LIMIT 1",
      {
        replacements: {
          type: req.body.type,
          empcode: req.body.empCode,
          currentMonth: moment(new Date()).format("YYYY-MM"),
        },
        type: hrmsDB.QueryTypes.SELECT,
      }
    );
    if (checkBalance.length == 0) {
      t.rollback();
      return res.json({
        code: 500,
        status: "error",
        message: { msg: "you don't have any configuration for the leave that you are applying for" },
      });
    }
    if (helper.number(checkBalance[0].available_balance - checkBalance[0].shadow_balance) < calculation) {
      t.rollback();
      return res.json({
        code: 500,
        status: "error",
        message: { msg: "You don't have enough leave balance to apply" },
      });
    }

    mail_leave_balance = checkBalance[0].available_balance;
    let reportofficer = await hrmsDB.query("SELECT tbl_emp_basic.emp_code, tbl_emp_basic.emp_email, emp_report_manager.reporting_manager FROM emp_report_manager LEFT JOIN tbl_emp_basic ON tbl_emp_basic.emp_code = emp_report_manager.reporting_manager WHERE emp_report_manager.emp_code = :empcode ORDER BY emp_report_manager.ID DESC LIMIT 1", {
      replacements: {
        empcode: req.body.empCode,
      },
      type: hrmsDB.QueryTypes.SELECT,
    });
    if (reportofficer.length == 0) {
      t.rollback();
      return res.json({
        code: 500,
        status: "error",
        message: { msg: "reporting officer not assigned, pls contact to your HR" },
      });
    }

    let stmt = await hrmsDB.query(
      "INSERT INTO tbl_leave_request (empcode , leave_status , leave_type , date_from , date_to , total_days, leave_remark, leave_cc, leave_indt, leave_by, leave_transaction, request_to, leave_attachment ) VALUES (:empcode , :leave_status , :leave_type , :date_from , :date_to , :total_days, :leave_remark, :leave_cc, :leave_indt, :leave_by, :leave_transaction, :request_to, :file )",
      {
        replacements: {
          empcode: req.body.empCode,
          leave_status: "PEN",
          leave_type: leaveType,
          date_from: moment(fromDt, "DD-MM-YYYY").format("YYYY-MM-DD"),
          date_to: moment(toDt, "DD-MM-YYYY").format("YYYY-MM-DD"),
          total_days: calculation,
          leave_remark: leaveReason + "<br/><br/>=========<br/>Note: This request is generated by Human Resource Management. <br/>=========",
          leave_cc: "--",
          leave_indt: moment(new Date()).tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss"),
          leave_by: req.logedINUser,
          leave_transaction: applicationID,
          request_to: reportofficer[0].emp_code,
          file: req.file ? req.file.filename : "--"
          
        },
        type: hrmsDB.QueryTypes.INSERT,
        transaction: t,
      }
    );

    if (stmt.length > 0) {
      (mail_calculation = calculation), (mail_report_officer = reportofficer[0].emp_email), (mail_application = applicationID);
      var mail_name = await hrmsDB.query("SELECT CONCAT(emp_f_name,' ', emp_l_name) as name FROM tbl_emp_basic WHERE emp_code = :empcode", {
        replacements: {
          empcode: req.body.empCode,
        },
        type: hrmsDB.QueryTypes.SELECT,
      });
      var mailName = mail_name[0]?.name || "";

      let cc_email = [];
      for (let f = 0; f < req.body.email_cc.split(",").length; f++) {
        const cc = await hrmsDB.query("SELECT emp_email FROM tbl_emp_basic WHERE emp_code = :empcode", {
          replacements: {
            empcode: req.body.email_cc.split(",")[f],
          },
          type: hrmsDB.QueryTypes.SELECT,
        });
        cc_email.push(cc[0]?.emp_email);
      }
      let checkLeavePolicy = await hrmsDB.query("SELECT leave_policy FROM tbl_emp_basic WHERE emp_code = :empcode", {
        replacements: {
          empcode: req.body.empCode,
        },
        type: hrmsDB.QueryTypes.SELECT,
      });
      let nameLogedInUser = await hrmsDB.query("SELECT log_full_name FROM hrms_login WHERE log_user_id= :empcode", {
        replacements: {
          empcode: req.logedINUser,
        },
        type: hrmsDB.QueryTypes.SELECT,
      });
      if (checkLeavePolicy[0].leave_policy == "conditional") {
        await createLeaveStageprocess(req, res, t, req.body.empCode, applicationID, mail_calculation, mail_report_officer, mail_application, mail_name, cc_email, leaveType, leaveReason, fromDt, toDt, fromSession, toSession, mail_leave_balance);
      } else {
        await sendInternalMail(req, mail_calculation, mail_report_officer, mail_application, mailName, cc_email, leaveType, leaveReason, fromDt, toDt, fromSession, toSession, mail_leave_balance,nameLogedInUser[0]?.log_full_name);
      }
      await t.commit();

      return res.json({
        code: 200,
        status: "success",
        message: "leave request sent to your approver for approval",
      });
    } else {
      t.rollback();
      return res.json({
        code: 500,
        status: "error",
        message: { msg: "an error while sending leave request to the server" },
      });
    }
  } catch (error) {
    
    t.rollback();
    return helper.crashRes(res, error, { routeName: req.originalUrl }, 500);
  }
};

exports.sendSLLeaveRequest = async (req, res) => {
  const t = await hrmsDB.transaction();
  try {
    const format = "DD-MM-YYYY";
    var fromDt = req.body.startDate;
    var fromSession = req.body.startSession;
    var toDt = req.body.endDate;
    var toSession = req.body.endSession;
    var applicationID = helper.uniqueID("REQ");
    const fromDate = moment(fromDt, format);
    const toDate = moment(toDt, format);

    var leaveReason = req.body.reason.replace(/\n/g, "<br>");
    var leaveType = req.body.type;
    var mail_calculation, mail_report_officer, mail_application, mail_leave_balance;
    //////////////////////////////////////////////////////////////////
    let calls = await leave(fromDt, toDt, fromSession, toSession, req, leaveType, req.body.empCode, req.body.startDate);
    if (calls && calls.code && calls.status === "error" && calls.message && calls.message.msg) {
      t.rollback();
      return res.json({
        code: calls.code,
        status: calls.status,
        message: calls.message,
      });
    }
    let diffDays = moment(moment()).diff(moment(fromDate, format), "days") + 1;

    let backDays = await helper.checkLeaveBackDays(req);
    if (backDays < diffDays) {
      t.rollback();
      return res.json({
        code: 500,
        status: "error",
        message: { msg: "Back Date not allowed" },
      });
    }

    /////////////////////////////////////////////////////////////////

    const totalSessions = calls[0].leave_session_count;
    const sessionDurations = calls[0].leave_session_value
      .split(",")
      .map((pair) => pair.split(":").map((value) => value.trim()))
      .reduce((acc, [key, value]) => {
        acc[key] = parseFloat(value);
        return acc;
      }, {});

    let calculation = 0;
    let currentDate = fromDate.clone();

    while (currentDate.isSameOrBefore(toDate)) {
      const currentDaySessionStart = currentDate.isSame(fromDate) ? fromSession : 1;
      const currentDaySessionEnd = currentDate.isSame(toDate) ? toSession : totalSessions;

      for (let i = currentDaySessionStart; i <= currentDaySessionEnd; i++) {
        calculation += sessionDurations[i] || 0; // Use 0 if session number not found in sessionDurations

        await hrmsDB.query("INSERT INTO tbl_leave_breakup (date, session, day, start_time, end_time, leave_transaction, emp_code, leave_type, leave_status) VALUES (:date, :session, :day, :start_time, :end_time, :leave_transaction, :emp_code, :leave_type, :leave_status)", {
          replacements: {
            date: currentDate.format("YYYY-MM-DD"),
            session: i,
            day: sessionDurations[i] || 0, // Use 0 if session number not found in sessionDurations
            start_time: calls[0].leave_session_tm.split(",")[i - 1].split("-")[0].trim(),
            end_time: calls[0].leave_session_tm.split(",")[i - 1].split("-")[1].trim(),
            leave_transaction: applicationID,
            emp_code: req.body.empCode,
            leave_type: req.body.type,
            leave_status: "PEN",
          },
          type: hrmsDB.QueryTypes.INSERT,
          transaction: t,
        });
      }

      currentDate.add(1, "day");
    }

    // CHECK USER BALANCE FOR LEAVE APPLY
    const checkBalance = await hrmsDB.query(
      "SELECT (SELECT COALESCE(SUM(total_days), 0) FROM tbl_leave_request WHERE leave_status = 'PEN' AND empcode = :empcode AND leave_type = :type AND DATE_FORMAT(date_from,'%Y-%m') = :currentMonth) AS shadow_balance, COALESCE(tbl_leave_log.month_leave_bal, 0) AS available_balance FROM tbl_leave_log WHERE month_leave_type = :type AND leave_empcode = :empcode AND leave_month = :currentMonth ORDER BY ID DESC LIMIT 1",
      {
        replacements: {
          type: req.body.type,
          empcode: req.body.empCode,
          currentMonth: moment(new Date()).format("YYYY-MM"),
        },
        type: hrmsDB.QueryTypes.SELECT,
      }
    );
    if (checkBalance.length == 0) {
      t.rollback();
      return res.json({
        code: 500,
        status: "error",
        message: { msg: "you don't have any configuration for the leave that you are applying for" },
      });
    }
    if (helper.number(checkBalance[0].available_balance - checkBalance[0].shadow_balance) < calculation) {
      t.rollback();
      return res.json({
        code: 500,
        status: "error",
        message: { msg: "You don't have enough leave balance to apply" },
      });
    }

    mail_leave_balance = checkBalance[0].available_balance;

    let reportofficer = await hrmsDB.query("SELECT tbl_emp_basic.emp_code, tbl_emp_basic.emp_email, emp_report_manager.reporting_manager FROM emp_report_manager LEFT JOIN tbl_emp_basic ON tbl_emp_basic.emp_code = emp_report_manager.reporting_manager WHERE emp_report_manager.emp_code = :empcode ORDER BY emp_report_manager.ID DESC LIMIT 1", {
      replacements: {
        empcode: req.body.empCode,
      },
      type: hrmsDB.QueryTypes.SELECT,
    });
    if (reportofficer.length == 0) {
      t.rollback();
      return res.json({
        code: 500,
        status: "error",
        message: { msg: "reporting officer not assigned, pls contact to your HR" },
      });
    }

    let stmt = await hrmsDB.query(
      "INSERT INTO tbl_leave_request (empcode , leave_status , leave_type , date_from , date_to , total_days, leave_remark, leave_cc, leave_indt, leave_by, leave_transaction, request_to, leave_attachment) VALUES (:empcode , :leave_status , :leave_type , :date_from , :date_to , :total_days, :leave_remark, :leave_cc, :leave_indt, :leave_by, :leave_transaction, :request_to,:file)",
      {
        replacements: {
          empcode: req.body.empCode,
          leave_status: "PEN",
          leave_type: leaveType,
          date_from: moment(fromDt, "DD-MM-YYYY").format("YYYY-MM-DD"),
          date_to: moment(toDt, "DD-MM-YYYY").format("YYYY-MM-DD"),
          total_days: calculation,
          leave_remark: leaveReason + "<br/><br/>=========<br/>Note: This request is generated by Human Resource Management. <br/>=========",
          leave_cc: "--",
          leave_indt: moment(new Date()).tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss"),
          leave_by: req.logedINUser,
          leave_transaction: applicationID,
          request_to: reportofficer[0].emp_code,
          file: req.file ? req.file.filename : "--"
        },
        type: hrmsDB.QueryTypes.INSERT,
        transaction: t,
      }
    );

    if (stmt.length > 0) {
      (mail_calculation = calculation), (mail_report_officer = reportofficer[0].emp_email), (mail_application = applicationID);
      var mail_name = await hrmsDB.query("SELECT CONCAT(emp_f_name, emp_l_name) as name FROM tbl_emp_basic WHERE emp_code = :empcode", {
        replacements: {
          empcode: req.body.empCode,
        },
        type: hrmsDB.QueryTypes.SELECT,
      });

      var mailName = mail_name[0]?.name || "";

      let cc_email = [];
      for (let f = 0; f < req.body.email_cc.split(",").length; f++) {
        const cc = await hrmsDB.query("SELECT emp_email FROM tbl_emp_basic WHERE emp_code = :empcode", {
          replacements: {
            empcode: req.body.email_cc.split(",")[f],
          },
          type: hrmsDB.QueryTypes.SELECT,
        });
        cc_email.push(cc[0]?.emp_email);
      }
      let checkLeavePolicy = await hrmsDB.query("SELECT leave_policy FROM tbl_emp_basic WHERE emp_code = :empcode", {
        replacements: {
          empcode: req.body.empCode,
        },
        type: hrmsDB.QueryTypes.SELECT,
      });
      let nameLogedInUser = await hrmsDB.query("SELECT log_full_name FROM hrms_login WHERE log_user_id= :empcode", {
        replacements: {
          empcode: req.logedINUser,
        },
        type: hrmsDB.QueryTypes.SELECT,
      });
      if (checkLeavePolicy[0].leave_policy == "conditional") {
        await createLeaveStageprocess(req, res, t, req.body.empCode, applicationID, mail_calculation, mail_report_officer, mail_application, mail_name, cc_email, leaveType, leaveReason, fromDt, toDt, fromSession, toSession);
      } else {
        await sendInternalMail(req, mail_calculation, mail_report_officer, mail_application, mailName, cc_email, leaveType, leaveReason, fromDt, toDt, fromSession, toSession, mail_leave_balance, nameLogedInUser[0]?.log_full_name);
      }
      await t.commit();

      return res.json({
        code: 200,
        status: "success",
        message: "leave request sent to your approver for approval",
      });
    } else {
      t.rollback();
      return res.json({
        code: 500,
        status: "error",
        message: { msg: "an error while sending leave request to the server" },
      });
    }
  } catch (error) {
    t.rollback();
    return res.json({
      code: 500,
      status: "error",
      debug: error.stack,
      message: { msg: error.message },
    });
  }
};

exports.sendWFHRequest = async (req, res) => {
  const t = await hrmsDB.transaction();
  try {
    const format = "DD-MM-YYYY";
    var fromDt = req.body.startDate;
    var fromSession = req.body.startSession;
    var toDt = req.body.endDate;
    const fromDate = moment(fromDt, format);
    const toDate = moment(toDt, format);
    var toSession = req.body.endSession;
    const applicationID = helper.uniqueID("REQ");

    var leaveReason = req.body.reason.replace(/\n/g, "<br>");
    var leaveType = req.body.type;

    var mail_calculation, mail_report_officer, mail_application, mail_leave_balance;

    //////////////////////////////////////////////////////////////////
    let calls = await leave(fromDt, toDt, fromSession, toSession, req, leaveType, req.body.empCode, req.body.startDate);
    if (calls && calls.code && calls.status === "error" && calls.message && calls.message.msg) {
      t.rollback();
      return res.json({
        code: calls.code,
        status: calls.status,
        message: calls.message,
      });
    }
    let diffDays = moment(moment()).diff(moment(fromDate, format), "days") + 1;

    let backDays = await helper.checkLeaveBackDays(req);
    if (backDays < diffDays) {
      t.rollback();
      return res.json({
        code: 500,
        status: "error",
        message: { msg: "Back Date not allowed" },
      });
    }

    /////////////////////////////////////////////////////////////////

    const totalSessions = calls[0].leave_session_count;
    const sessionDurations = calls[0].leave_session_value
      .split(",")
      .map((pair) => pair.split(":").map((value) => value.trim()))
      .reduce((acc, [key, value]) => {
        acc[key] = parseFloat(value);
        return acc;
      }, {});

    let calculation = 0;
    if (!moment(fromDate).isSame(toDate, "day")) {
      t.rollback();
      return res.json({
        code: 500,
        status: "error",
        message: { msg: "for WFH leave, you can take leave for only one day" },
      });
    }
    let currentDate = fromDate.clone();

    while (currentDate.isSameOrBefore(toDate)) {
      const currentDaySessionStart = currentDate.isSame(fromDate) ? fromSession : 1;
      const currentDaySessionEnd = currentDate.isSame(toDate) ? toSession : totalSessions;

      for (let i = currentDaySessionStart; i <= currentDaySessionEnd; i++) {
        calculation += sessionDurations[i] || 0; // Use 0 if session number not found in sessionDurations

        await hrmsDB.query("INSERT INTO tbl_leave_breakup (date, session, day, start_time, end_time, leave_transaction, emp_code, leave_type, leave_status) VALUES (:date, :session, :day, :start_time, :end_time, :leave_transaction, :emp_code, :leave_type, :leave_status)", {
          replacements: {
            date: currentDate.format("YYYY-MM-DD"),
            session: i,
            day: sessionDurations[i] || 0, // Use 0 if session number not found in sessionDurations
            start_time: calls[0].leave_session_tm.split(",")[i - 1].split("-")[0].trim(),
            end_time: calls[0].leave_session_tm.split(",")[i - 1].split("-")[1].trim(),
            leave_transaction: applicationID,
            emp_code: req.body.empCode,
            leave_type: req.body.type,
            leave_status: "PEN",
          },
          type: hrmsDB.QueryTypes.INSERT,
          transaction: t,
        });
      }

      currentDate.add(1, "day");
    }

    // CHECK USER BALANCE FOR LEAVE APPLY
    const checkBalance = await hrmsDB.query(
      "SELECT (SELECT COALESCE(SUM(total_days), 0) FROM tbl_leave_request WHERE leave_status = 'PEN' AND empcode = :empcode AND leave_type = :type AND DATE_FORMAT(date_from,'%Y-%m') = :currentMonth) AS shadow_balance, COALESCE(tbl_leave_log.month_leave_bal, 0) AS available_balance FROM tbl_leave_log WHERE month_leave_type = :type AND leave_empcode = :empcode AND leave_month = :currentMonth ORDER BY ID DESC LIMIT 1",
      {
        replacements: {
          type: req.body.type,
          empcode: req.body.empCode,
          currentMonth: moment(new Date()).format("YYYY-MM"),
        },
        type: hrmsDB.QueryTypes.SELECT,
      }
    );
    if (checkBalance.length == 0) {
      t.rollback();
      return res.json({
        code: 500,
        status: "error",
        message: { msg: "you don't have any configuration for the leave that you are applying for" },
      });
    }
    if (helper.number(checkBalance[0].available_balance - checkBalance[0].shadow_balance) < calculation) {
      t.rollback();
      return res.json({
        code: 500,
        status: "error",
        message: { msg: "You don't have enough leave balance to apply" },
      });
    }

    mail_leave_balance = checkBalance[0].available_balance;
    let reportofficer = await hrmsDB.query("SELECT tbl_emp_basic.emp_code, tbl_emp_basic.emp_email, emp_report_manager.reporting_manager FROM emp_report_manager LEFT JOIN tbl_emp_basic ON tbl_emp_basic.emp_code = emp_report_manager.reporting_manager WHERE emp_report_manager.emp_code = :empcode ORDER BY emp_report_manager.ID DESC LIMIT 1", {
      replacements: {
        empcode: req.body.empCode,
      },
      type: hrmsDB.QueryTypes.SELECT,
    });
    if (reportofficer.length == 0) {
      t.rollback();
      return res.json({
        code: 500,
        status: "error",
        message: { msg: "reporting officer not assigned, pls contact to your HR" },
      });
    }

    let stmt = await hrmsDB.query(
      "INSERT INTO tbl_leave_request (empcode , leave_status , leave_type , date_from , date_to , total_days, leave_remark, leave_cc, leave_indt, leave_by, leave_transaction, request_to, leave_attachment) VALUES (:empcode , :leave_status , :leave_type , :date_from , :date_to , :total_days, :leave_remark, :leave_cc, :leave_indt, :leave_by, :leave_transaction, :request_to, :file)",
      {
        replacements: {
          empcode: req.body.empCode,
          leave_status: "PEN",
          leave_type: leaveType,
          date_from: moment(fromDt, "DD-MM-YYYY").format("YYYY-MM-DD"),
          date_to: moment(toDt, "DD-MM-YYYY").format("YYYY-MM-DD"),
          total_days: calculation,
          leave_remark: leaveReason + "<br/><br/>=========<br/>Note: This request is generated by Human Resource Management. <br/>=========",
          leave_cc: "--",
          leave_indt: moment(new Date()).tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss"),
          leave_by: req.logedINUser,
          leave_transaction: applicationID,
          request_to: reportofficer[0].emp_code,
          file: req.file ? req.file.filename : "--"
        },
        type: hrmsDB.QueryTypes.INSERT,
        transaction: t,
      }
    );

    if (stmt.length > 0) {
      (mail_calculation = calculation), (mail_report_officer = reportofficer[0].emp_email), (mail_application = applicationID);
      var mail_name = await hrmsDB.query("SELECT CONCAT(emp_f_name,' ', emp_l_name) as name FROM tbl_emp_basic WHERE emp_code = :empcode", {
        replacements: {
          empcode: req.body.empCode,
        },
        type: hrmsDB.QueryTypes.SELECT,
      });
      var mailName = mail_name[0]?.name || "";

      let cc_email = [];
      for (let f = 0; f < req.body.email_cc.split(",").length; f++) {
        const cc = await hrmsDB.query("SELECT emp_email FROM tbl_emp_basic WHERE emp_code = :empcode", {
          replacements: {
            empcode: req.body.email_cc.split(",")[f],
          },
          type: hrmsDB.QueryTypes.SELECT,
        });
        cc_email.push(cc[0]?.emp_email);
      }
      let checkLeavePolicy = await hrmsDB.query("SELECT leave_policy FROM tbl_emp_basic WHERE emp_code = :empcode", {
        replacements: {
          empcode: req.body.empCode,
        },
        type: hrmsDB.QueryTypes.SELECT,
      });
      let nameLogedInUser = await hrmsDB.query("SELECT log_full_name FROM hrms_login WHERE log_user_id= :empcode", {
        replacements: {
          empcode: req.logedINUser,
        },
        type: hrmsDB.QueryTypes.SELECT,
      });
      if (checkLeavePolicy[0].leave_policy == "conditional") {
        await createLeaveStageprocess(req, res, t, req.body.empCode, applicationID, mail_calculation, mail_report_officer, mail_application, mail_name, cc_email, leaveType, leaveReason, fromDt, toDt, fromSession, toSession);
      } else {
        await sendInternalMail(req, mail_calculation, mail_report_officer, mail_application, mailName, cc_email, leaveType, leaveReason, fromDt, toDt, fromSession, toSession, mail_leave_balance, nameLogedInUser[0]?.log_full_name);
      }
      await t.commit();

      return res.json({
        code: 200,
        status: "success",
        message: "leave request sent to your approver for approval",
      });
    } else {
      t.rollback();
      return res.json({
        code: 500,
        status: "error",
        message: { msg: "an error while sending leave request to the server" },
      });
    }
  } catch (error) {
    return helper.crashRes(res, error, { routeName: req.originalUrl });
  }
};

exports.sendODRequest = async (req, res) => {
  const t = await hrmsDB.transaction();
  try {
    var fromDt = req.body.startDate;
    const format = "DD-MM-YYYY";
    var fromSession = req.body.startSession;
    var toDt = req.body.endDate;
    const fromDate = moment(fromDt, format);
    const toDate = moment(toDt, format);
    var toSession = req.body.endSession;
    if (req.body.startSession != 1) {
      return res.json({
        code: 500,
        status: "error",
        message: { msg: "Start Session should be first session" },
      });
    }
    if (req.body.endSession != 4) {
      return res.json({
        code: 500,
        status: "error",
        message: { msg: "End Session should be last session" },
      });
    }
    const applicationID = helper.uniqueID("REQ");

    var leaveReason = req.body.reason.replace(/\n/g, "<br>");
    var leaveType = req.body.type;

    var mail_calculation, mail_report_officer, mail_application, mail_leave_balance;
    //////////////////////////////////////////////////////////////////
    let calls = await leave(fromDt, toDt, fromSession, toSession, req, leaveType, req.body.empCode, req.body.startDate);
    if (calls && calls.code && calls.status === "error" && calls.message && calls.message.msg) {
      t.rollback();
      return res.json({
        code: calls.code,
        status: calls.status,
        message: calls.message,
      });
    }
    let diffDays = moment(moment()).diff(moment(fromDate, format), "days") + 1;

    let backDays = await helper.checkLeaveBackDays(req);
    if (backDays < diffDays) {
      t.rollback();
      return res.json({
        code: 500,
        status: "error",
        message: { msg: "Back Date not allowed" },
      });
    }

    /////////////////////////////////////////////////////////////////

    const totalSessions = calls[0].leave_session_count;
    const sessionDurations = calls[0].leave_session_value
      .split(",")
      .map((pair) => pair.split(":").map((value) => value.trim()))
      .reduce((acc, [key, value]) => {
        acc[key] = parseFloat(value);
        return acc;
      }, {});

    let calculation = 0;

    // ON DUTY
    const timezone = "Asia/Kolkata"; // India IST timezone
    let totalHours = 0;
    let totalMinutes = 0;

    const startSessionTime = calls[0].leave_session_tm.split(",")[fromSession - 1].split("-")[0].trim();
    const endSessionTime = calls[0].leave_session_tm.split(",")[toSession - 1].split("-")[1].trim();

    const startMoment = moment(startSessionTime, "hh:mm A").tz(timezone);
    const endMoment = moment(endSessionTime, "hh:mm A").tz(timezone);

    totalHours = endMoment.diff(startMoment, "hours");
    totalMinutes = endMoment.diff(startMoment, "minutes") % 60;

    calculation = totalHours + " h & " + totalMinutes + " m";
    //
    while (fromDate.isSameOrBefore(toDate)) {
      for (let i = fromSession; i <= toSession; i++) {
        const sessionTimeRange = calls[0].leave_session_tm.split(",")[i - 1];
        const [startSessionTime, endSessionTime] = sessionTimeRange.split("-").map((time) => time.trim());

        await hrmsDB.query("INSERT INTO tbl_leave_breakup (date, session, start_time, end_time, leave_transaction, day, emp_code, leave_type, leave_status) VALUES (:date, :session, :start_time, :end_time, :leave_transaction, :day, :emp_code, :leave_type, :leave_status)", {
          replacements: {
            date: fromDate.format("YYYY-MM-DD"),
            session: i,
            start_time: startSessionTime,
            end_time: endSessionTime,
            leave_transaction: applicationID,
            day: sessionDurations[i],
            emp_code: req.body.empCode,
            leave_type: req.body.type,
            leave_status: "PEN",
          },
          type: hrmsDB.QueryTypes.INSERT,
          transaction: t,
        });
      }

      fromDate.add(1, "day");
    }
    let reportofficer = await hrmsDB.query("SELECT tbl_emp_basic.emp_code, tbl_emp_basic.emp_email, emp_report_manager.reporting_manager FROM emp_report_manager LEFT JOIN tbl_emp_basic ON tbl_emp_basic.emp_code = emp_report_manager.reporting_manager WHERE emp_report_manager.emp_code = :empcode ORDER BY emp_report_manager.ID DESC LIMIT 1", {
      replacements: {
        empcode: req.body.empCode,
      },
      type: hrmsDB.QueryTypes.SELECT,
    });
    if (reportofficer.length == 0) {
      t.rollback();
      return res.json({
        code: 500,
        status: "error",
        message: { msg: "reporting officer not assigned, pls contact to your HR" },
      });
    }

    let stmt = await hrmsDB.query(
      "INSERT INTO tbl_leave_request (empcode , leave_status , leave_type , date_from , date_to , total_days, leave_remark, leave_cc, leave_indt, leave_by, leave_transaction, request_to, leave_attachment) VALUES (:empcode , :leave_status , :leave_type , :date_from , :date_to , :total_days, :leave_remark, :leave_cc, :leave_indt, :leave_by, :leave_transaction, :request_to, :file)",
      {
        replacements: {
          empcode: req.body.empCode,
          leave_status: "PEN",
          leave_type: leaveType,
          date_from: moment(fromDt, "DD-MM-YYYY").format("YYYY-MM-DD"),
          date_to: moment(toDt, "DD-MM-YYYY").format("YYYY-MM-DD"),
          total_days: calculation + " " + (moment(moment()).diff(moment(fromDate, format), "days") + 1) + " Days",
          leave_remark: leaveReason + "<br/><br/>=========<br/>Note: This request is generated by Human Resource Management. <br/>=========",
          leave_cc: "--",
          leave_indt: moment(new Date()).tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss"),
          leave_by: req.logedINUser,
          leave_transaction: applicationID,
          request_to: reportofficer[0].emp_code,
          file: req.file ? req.file ? req.file.filename : "--" : "--"
        },
        type: hrmsDB.QueryTypes.INSERT,
        transaction: t,
      }
    );

    if (stmt.length > 0) {
      (mail_calculation = calculation), (mail_report_officer = reportofficer[0].emp_email), (mail_application = applicationID);
      var mail_name = await hrmsDB.query("SELECT CONCAT(emp_f_name,' ', emp_l_name) as name FROM tbl_emp_basic WHERE emp_code = :empcode", {
        replacements: {
          empcode: req.body.empCode,
        },
        type: hrmsDB.QueryTypes.SELECT,
      });
      var mailName = mail_name[0]?.name || "";

      let cc_email = [];
      for (let f = 0; f < req.body.email_cc.split(",").length; f++) {
        const cc = await hrmsDB.query("SELECT emp_email FROM tbl_emp_basic WHERE emp_code = :empcode", {
          replacements: {
            empcode: req.body.email_cc.split(",")[f],
          },
          type: hrmsDB.QueryTypes.SELECT,
        });
        cc_email.push(cc[0]?.emp_email);
      }
      let checkLeavePolicy = await hrmsDB.query("SELECT leave_policy FROM tbl_emp_basic WHERE emp_code = :empcode", {
        replacements: {
          empcode: req.body.empCode,
        },
        type: hrmsDB.QueryTypes.SELECT,
      });
      let nameLogedInUser = await hrmsDB.query("SELECT log_full_name FROM hrms_login WHERE log_user_id= :empcode", {
        replacements: {
          empcode: req.logedINUser,
        },
        type: hrmsDB.QueryTypes.SELECT,
      });
      if (checkLeavePolicy[0].leave_policy == "conditional") {
        await createLeaveStageprocess(req, res, t, req.body.empCode, applicationID, mail_calculation, mail_report_officer, mail_application, mail_name, cc_email, leaveType, leaveReason, fromDt, toDt, fromSession, toSession, "N/A");
      } else {
        await sendInternalMail(req, mail_calculation, mail_report_officer, mail_application, mailName, cc_email, leaveType, leaveReason, fromDt, toDt, fromSession, toSession, "N/A", nameLogedInUser[0]?.log_full_name);
      }
      await t.commit();
      return res.json({
        code: 200,
        status: "success",
        message: "leave request sent to your approver for approval",
      });
    } else {
      t.rollback();
      return res.json({
        code: 500,
        status: "error",
        message: { msg: "an error while sending leave request to the server" },
      });
    }
  } catch (error) {
    return res.json({
      code: 500,
      status: "error",
      debug: error.stack,
      message: { msg: error.message },
    });
  }
};
//ROUTE FOR SEND ACL LEAVE REQUEST(Apply Compensatory Leave Request) not Availing the request
exports.sendACLLeaveRequest = async (req, res) => {
  const t = await hrmsDB.transaction();

  try {
    const format = "DD-MM-YYYY";
    var fromDt = req.body.startDate;
    var fromSession = req.body.startSession;
    var toDt = req.body.endDate;
    const fromDate = moment(fromDt, format);
    const toDate = moment(toDt, format);
    var toSession = req.body.endSession;
    const applicationID = helper.uniqueID("REQ");

    var leaveReason = req.body.reason.replace(/\n/g, "<br>");
    var leaveType = req.body.type;
    console.log("leaveType", req.body);
    //////////////////////////////////////////////////////////////////
    let calls = await leave(fromDt, toDt, fromSession, toSession, req, leaveType, req.body.empCode);
    /////////////////////////////////////////////////////////////////

    if (calls && calls.code && calls.status === "error" && calls.message && calls.message.msg) {
      t.rollback();
      return res.json({
        code: calls.code,
        status: calls.status,
        message: calls.message,
      });
    }
    let diffDays = moment(moment()).diff(moment(fromDate, format), "days") + 1;

    let backDays = await helper.checkLeaveBackDays(req);
    if (backDays < diffDays) {
      t.rollback();
      return res.json({
        code: 500,
        status: "error",
        message: { msg: "Back Date not allowed" },
      });
    }

    var mail_calculation, mail_report_officer, mail_application, mail_leave_balance;
    const totalSessions = calls[0].leave_session_count;
    const sessionDurations = calls[0].leave_session_value
      .split(",")
      .map((pair) => pair.split(":").map((value) => value.trim()))
      .reduce((acc, [key, value]) => {
        acc[key] = parseFloat(value);
        return acc;
      }, {});

    let calculation = 0;
    let currentDate = fromDate.clone();
    while (currentDate.isSameOrBefore(toDate)) {
      const currentDaySessionStart = currentDate.isSame(fromDate) ? fromSession : 1;
      const currentDaySessionEnd = currentDate.isSame(toDate) ? toSession : totalSessions;

      for (let i = currentDaySessionStart; i <= currentDaySessionEnd; i++) {
        calculation += sessionDurations[i] || 0; // Use 0 if session number not found in sessionDurations

        await hrmsDB.query("INSERT INTO tbl_leave_breakup (date, session, day, start_time, end_time, leave_transaction, emp_code, leave_type, leave_status) VALUES (:date, :session, :day, :start_time, :end_time, :leave_transaction, :emp_code, :leave_type, :leave_status)", {
          replacements: {
            date: currentDate.format("YYYY-MM-DD"),
            session: i,
            day: sessionDurations[i] || 0, // Use 0 if session number not found in sessionDurations
            start_time: calls[0].leave_session_tm.split(",")[i - 1].split("-")[0].trim(),
            end_time: calls[0].leave_session_tm.split(",")[i - 1].split("-")[1].trim(),
            leave_transaction: applicationID,
            emp_code: req.body.empCode,
            leave_type: req.body.type,
            leave_status: "PEN",
          },
          type: hrmsDB.QueryTypes.INSERT,
          transaction: t,
        });
      }

      currentDate.add(1, "day");
    }

    let reportofficer = await hrmsDB.query("SELECT tbl_emp_basic.emp_code, tbl_emp_basic.emp_email, emp_report_manager.reporting_manager FROM emp_report_manager LEFT JOIN tbl_emp_basic ON tbl_emp_basic.emp_code = emp_report_manager.reporting_manager WHERE emp_report_manager.emp_code = :empcode ORDER BY emp_report_manager.ID DESC LIMIT 1", {
      replacements: {
        empcode: req.body.empCode,
      },
      type: hrmsDB.QueryTypes.SELECT,
    });
    if (reportofficer.length == 0) {
      t.rollback();
      return res.json({
        code: 500,
        status: "error",
        message: { msg: "reporting officer not assigned, pls contact to your HR" },
      });
    }

    let stmt = await hrmsDB.query(
      "INSERT INTO tbl_leave_request (empcode , leave_status , leave_type , date_from , date_to , total_days, leave_remark, leave_cc, leave_indt, leave_by, leave_transaction, request_to, leave_attachment) VALUES (:empcode , :leave_status , :leave_type , :date_from , :date_to , :total_days, :leave_remark, :leave_cc, :leave_indt, :leave_by, :leave_transaction, :request_to, :file)",
      {
        replacements: {
          empcode: req.body.empCode,
          leave_status: "PEN",
          leave_type: leaveType,
          date_from: moment(fromDt, "DD-MM-YYYY").format("YYYY-MM-DD"),
          date_to: moment(toDt, "DD-MM-YYYY").format("YYYY-MM-DD"),
          total_days: calculation,
          leave_remark: leaveReason + "<br/><br/>=========<br/>Note: This request is generated by Human Resource Management. <br/>=========",
          leave_cc: "--",
          leave_indt: moment(new Date()).tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss"),
          leave_by: req.logedINUser,
          leave_transaction: applicationID,
          request_to: reportofficer[0].emp_code,
          file: req.file ? req.file ? req.file.filename : "--" : "--"
        },
        type: hrmsDB.QueryTypes.INSERT,
        transaction: t,
      }
    );

    if (stmt.length > 0) {
      (mail_calculation = calculation), (mail_report_officer = reportofficer[0].emp_email), (mail_application = applicationID);
      var mail_name = await hrmsDB.query("SELECT CONCAT(emp_f_name,' ', emp_l_name) as name FROM tbl_emp_basic WHERE emp_code = :empcode", {
        replacements: {
          empcode: req.logedINUser,
        },
        type: hrmsDB.QueryTypes.SELECT,
      });
      var mailName = mail_name[0]?.name || "";

      let cc_email = [];
      for (let f = 0; f < req.body.email_cc.split(",").length; f++) {
        const cc = await hrmsDB.query("SELECT emp_email FROM tbl_emp_basic WHERE emp_code = :empcode", {
          replacements: {
            empcode: req.body.email_cc.split(",")[f],
          },
          type: hrmsDB.QueryTypes.SELECT,
        });
        cc_email.push(cc[0]?.emp_email);
      }
      let checkLeavePolicy = await hrmsDB.query("SELECT leave_policy FROM tbl_emp_basic WHERE emp_code = :empcode", {
        replacements: {
          empcode: req.body.empCode,
        },
        type: hrmsDB.QueryTypes.SELECT,
      });
      let nameLogedInUser = await hrmsDB.query("SELECT log_full_name FROM hrms_login WHERE log_user_id= :empcode", {
        replacements: {
          empcode: req.logedINUser,
        },
        type: hrmsDB.QueryTypes.SELECT,
      });

      if (checkLeavePolicy[0].leave_policy == "conditional") {
        await createLeaveStageprocess(req, res, t, req.body.empCode, applicationID, mail_calculation, mail_report_officer, mail_application, mail_name, cc_email, leaveType, leaveReason, fromDt, toDt, fromSession, toSession, mail_leave_balance);
      } else {
        await sendInternalMail(req, mail_calculation, mail_report_officer, mail_application, mailName, cc_email, leaveType, leaveReason, fromDt, toDt, fromSession, toSession, mail_leave_balance, nameLogedInUser[0]?.log_full_name);
      }
      await t.commit();

      return res.json({
        code: 200,
        status: "success",
        message: "leave request sent to your approver for approval",
      });
    } else {
      t.rollback();
      return res.json({
        code: 500,
        status: "error",
        message: { msg: "an error while sending leave request to the server" },
      });
    }
  } catch (err) {
    console.log(err);
    return res.json({ code: 500, status: "error", message: { msg: err } });
  }
};

// exports.sendCLRequest = async (req, res) => {
//   const t = await hrmsDB.transaction();

//   try {
//     const format = "DD-MM-YYYY";
//     var fromDt = req.body.startDate;
//     var fromSession = req.body.startSession;
//     var toDt = req.body.endDate;
//     var toSession = req.body.endSession;
//     const fromDate = moment(fromDt, format);
//     const toDate = moment(toDt, format);
//     const applicationID = helper.uniqueID("REQ");

//     var leaveReason = req.body.reason.replace(/\n/g, "<br>");
//     var leaveType = req.body.type;
//     //////////////////////////////////////////////////////////////////
//     let calls = await leave(fromDt, toDt, fromSession, toSession, req, leaveType, req.body.empCode, req.body.startMonth);
    
//     /////////////////////////////////////////////////////////////////
//     if (calls && calls.code && calls.status === "error" && calls.message && calls.message.msg) {
//       t.rollback();
//       return res.json({
//         code: calls.code,
//         status: calls.status,
//         message: calls.message,
//       });
//     }
    
//     let diffDays = moment(moment()).diff(moment(fromDate, format), "days") + 1;
    
//     let backDays = await helper.checkLeaveBackDays(req);
//     if (backDays < diffDays) {
//       t.rollback();
//       return res.json({
//         code: 500,
//         status: "error",
//         message: { msg: "Back Date not allowed" },
//       });
//     }

//     var mail_calculation, mail_report_officer, mail_application, mail_leave_balance;
//     const totalSessions = calls[0].leave_session_count;
//     const sessionDurations = calls[0].leave_session_value
//       .split(",")
//       .map((pair) => pair.split(":").map((value) => value.trim()))
//       .reduce((acc, [key, value]) => {
//         acc[key] = parseFloat(value);
//         return acc;
//       }, {});

//     let calculation = 0;

//     let currentDate = fromDate.clone();
//     while (currentDate.isSameOrBefore(toDate)) {
//       const currentDaySessionStart = currentDate.isSame(fromDate) ? fromSession : 1;
//       const currentDaySessionEnd = currentDate.isSame(toDate) ? toSession : totalSessions;

//       for (let i = currentDaySessionStart; i <= currentDaySessionEnd; i++) {
//         calculation += sessionDurations[i] || 0; // Use 0 if session number not found in sessionDurations

//         await hrmsDB.query("INSERT INTO tbl_leave_breakup (date, session, day, start_time, end_time, leave_transaction, emp_code, leave_type, leave_status) VALUES (:date, :session, :day, :start_time, :end_time, :leave_transaction, :emp_code, :leave_type, :leave_status)", {
//           replacements: {
//             date: currentDate.format("YYYY-MM-DD"),
//             session: i,
//             day: sessionDurations[i] || 0, // Use 0 if session number not found in sessionDurations
//             start_time: calls[0].leave_session_tm.split(",")[i - 1].split("-")[0].trim(),
//             end_time: calls[0].leave_session_tm.split(",")[i - 1].split("-")[1].trim(),
//             leave_transaction: applicationID,
//             emp_code: req.logedINUser,
//             leave_type: req.body.type,
//             leave_status: "PEN",
//           },
//           type: hrmsDB.QueryTypes.INSERT,
//           transaction: t,
//         });
//       }

//       currentDate.add(1, "day");
//     }

//     var total_balance = 0;

//     const compBalance = await hrmsDB.query(`SELECT SUM(leave_balance) as balance FROM compensatory_leave_balance WHERE empcode = :empcode  AND STR_TO_DATE(leave_validity, '%Y-%m-%d') > '${moment().format("YYYY-MM-DD")}' `, {
//       replacements: {
//         empcode: req.logedINUser,
//       },
//       type: hrmsDB.QueryTypes.SELECT,
//     });

//     total_balance += parseFloat(compBalance[0].balance);

//     if (total_balance < calculation) {
//       return res.json({
//         code: 500,
//         status: "error",
//         message: { msg: "You don't have enough leave balance to apply compensatory leave" },
//       });
//     }

//     let reportofficer = await hrmsDB.query("SELECT tbl_emp_basic.emp_code, tbl_emp_basic.emp_email, emp_report_manager.reporting_manager FROM emp_report_manager LEFT JOIN tbl_emp_basic ON tbl_emp_basic.emp_code = emp_report_manager.reporting_manager WHERE emp_report_manager.emp_code = :empcode ORDER BY emp_report_manager.ID DESC LIMIT 1", {
//       replacements: {
//         empcode: req.body.empCode,
//       },
//       type: hrmsDB.QueryTypes.SELECT,
//     });
//     if (reportofficer.length == 0) {
//       t.rollback();
//       return res.json({
//         code: 500,
//         status: "error",
//         message: { msg: "reporting officer not assigned, pls contact to your HR" },
//       });
//     }

//     let stmt = await hrmsDB.query(
//       "INSERT INTO tbl_leave_request (empcode , leave_status , leave_type , date_from , date_to , total_days, leave_remark, leave_cc, leave_indt, leave_by, leave_transaction, request_to ) VALUES (:empcode , :leave_status , :leave_type , :date_from , :date_to , :total_days, :leave_remark, :leave_cc, :leave_indt, :leave_by, :leave_transaction, :request_to )",
//       {
//         replacements: {
//           empcode: req.body.empCode,
//           leave_status: "PEN",
//           leave_type: leaveType,
//           date_from: moment(fromDt, "DD-MM-YYYY").format("YYYY-MM-DD"),
//           date_to: moment(toDt, "DD-MM-YYYY").format("YYYY-MM-DD"),
//           total_days: calculation,
//           leave_remark: leaveReason + "<br/><br/>=========<br/>Note: This request is generated by Human Resource Management. <br/>=========",
//           leave_cc: "--",
//           leave_indt: moment(new Date()).tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss"),
//           leave_by: req.logedINUser,
//           leave_transaction: applicationID,
//           request_to: reportofficer[0].emp_code,
//         },
//         type: hrmsDB.QueryTypes.INSERT,
//         transaction: t,
//       }
//     );

//     if (stmt.length > 0) {
//       (mail_calculation = calculation), (mail_report_officer = reportofficer[0].emp_email), (mail_application = applicationID);
//       var mail_name = await hrmsDB.query("SELECT CONCAT(emp_f_name, emp_l_name) as name FROM tbl_emp_basic WHERE emp_code = :empcode", {
//         replacements: {
//           empcode: req.logedINUser,
//         },
//         type: hrmsDB.QueryTypes.SELECT,
//       });
//       var mailName = mail_name[0]?.name || "";

//       let cc_email = [];
//       for (let f = 0; f < req.body.email_cc.length; f++) {
//         const cc = await hrmsDB.query("SELECT emp_email FROM tbl_emp_basic WHERE emp_code = :empcode", {
//           replacements: {
//             empcode: req.body.email_cc[f],
//           },
//           type: hrmsDB.QueryTypes.SELECT,
//         });
//         cc_email.push(cc[0]?.emp_email);
//       }
//       let checkLeavePolicy = await hrmsDB.query("SELECT leave_policy FROM tbl_emp_basic WHERE emp_code = :empcode", {
//         replacements: {
//           empcode: req.body.empCode,
//         },
//         type: hrmsDB.QueryTypes.SELECT,
//       });
//       if (checkLeavePolicy[0].leave_policy == "conditional") {
//         await createLeaveStageprocess(req, res, t, req.body.empCode, applicationID, mail_calculation, mail_report_officer, mail_application, mail_name, cc_email, leaveType, leaveReason, fromDt, toDt, fromSession, toSession, mail_leave_balance);
//       } else {
//         await sendInternalMail(req, mail_calculation, mail_report_officer, mail_application, mailName, cc_email, leaveType, leaveReason, fromDt, toDt, fromSession, toSession, mail_leave_balance);
//       }
//       await t.commit();

//       return res.json({
//         code: 200,
//         status: "success",
//         message: "leave request sent to your approver for approval",
//       });
//     } else {
//       t.rollback();
//       return res.json({
//         code: 500,
//         status: "error",
//         message: { msg: "an error while sending leave request to the server" },
//       });
//     }
//   } catch (err) {
//     t.rollback();
//     return res.json({ code: 500, status: "error", message: { msg: err } });
//   }
// };

exports.sendCLRequest = async (req, res) => {
  const t = await hrmsDB.transaction();

  try {
    const format = "DD-MM-YYYY";
    var fromDt = req.body.startDate;
    var fromSession = req.body.startSession;
    var toDt = req.body.endDate;
    var toSession = req.body.endSession;
    const fromDate = moment(fromDt, format);
    const toDate = moment(toDt, format);
    const applicationID = helper.uniqueID("REQ");

    var leaveReason = req.body.reason.replace(/\n/g, "<br>");
    var leaveType = req.body.type;
    //////////////////////////////////////////////////////////////////
    let calls = await leave(fromDt, toDt, fromSession, toSession, req, leaveType, req.body.empCode, req.body.startDate);
    
    /////////////////////////////////////////////////////////////////
    if (calls && calls.code && calls.status === "error" && calls.message && calls.message.msg) {
      t.rollback();
      return res.json({
        code: calls.code,
        status: calls.status,
        message: calls.message,
      });
    }
    
    let diffDays = moment(moment()).diff(moment(fromDate, format), "days") + 1;
    
    let backDays = await helper.checkLeaveBackDays(req);
    if (backDays < diffDays) {
      t.rollback();
      return res.json({
        code: 500,
        status: "error",
        message: { msg: "Back Date not allowed" },
      });
    }

    var mail_calculation, mail_report_officer, mail_application, mail_leave_balance;
    const totalSessions = calls[0].leave_session_count;
    const sessionDurations = calls[0].leave_session_value
      .split(",")
      .map((pair) => pair.split(":").map((value) => value.trim()))
      .reduce((acc, [key, value]) => {
        acc[key] = parseFloat(value);
        return acc;
      }, {});

    let calculation = 0;

    let currentDate = fromDate.clone();
    while (currentDate.isSameOrBefore(toDate)) {
      const currentDaySessionStart = currentDate.isSame(fromDate) ? fromSession : 1;
      const currentDaySessionEnd = currentDate.isSame(toDate) ? toSession : totalSessions;

      for (let i = currentDaySessionStart; i <= currentDaySessionEnd; i++) {
        calculation += sessionDurations[i] || 0; // Use 0 if session number not found in sessionDurations

        await hrmsDB.query("INSERT INTO tbl_leave_breakup (date, session, day, start_time, end_time, leave_transaction, emp_code, leave_type, leave_status) VALUES (:date, :session, :day, :start_time, :end_time, :leave_transaction, :emp_code, :leave_type, :leave_status)", {
          replacements: {
            date: currentDate.format("YYYY-MM-DD"),
            session: i,
            day: sessionDurations[i] || 0, // Use 0 if session number not found in sessionDurations
            start_time: calls[0].leave_session_tm.split(",")[i - 1].split("-")[0].trim(),
            end_time: calls[0].leave_session_tm.split(",")[i - 1].split("-")[1].trim(),
            leave_transaction: applicationID,
            emp_code: req.body.empCode,
            leave_type: req.body.type,
            leave_status: "PEN",
            
          },
          type: hrmsDB.QueryTypes.INSERT,
          transaction: t,
        });
      }

      currentDate.add(1, "day");
    }

    var total_balance = 0;

    const compBalance = await hrmsDB.query(`SELECT SUM(leave_balance) as balance FROM compensatory_leave_balance WHERE empcode = :empcode  AND STR_TO_DATE(leave_validity, '%Y-%m-%d') > '${moment().format("YYYY-MM-DD")}' `, {
      replacements: {
        empcode: req.logedINUser,
      },
      type: hrmsDB.QueryTypes.SELECT,
    });

    total_balance += parseFloat(compBalance[0].balance);

    if (total_balance < calculation) {
      return res.json({
        code: 500,
        status: "error",
        message: { msg: "You don't have enough leave balance to apply compensatory leave" },
      });
    }

    let reportofficer = await hrmsDB.query("SELECT tbl_emp_basic.emp_code, tbl_emp_basic.emp_email, emp_report_manager.reporting_manager FROM emp_report_manager LEFT JOIN tbl_emp_basic ON tbl_emp_basic.emp_code = emp_report_manager.reporting_manager WHERE emp_report_manager.emp_code = :empcode ORDER BY emp_report_manager.ID DESC LIMIT 1", {
      replacements: {
        empcode: req.body.empCode,
      },
      type: hrmsDB.QueryTypes.SELECT,
    });
    if (reportofficer.length == 0) {
      t.rollback();
      return res.json({
        code: 500,
        status: "error",
        message: { msg: "reporting officer not assigned, pls contact to your HR" },
      });
    }

    let stmt = await hrmsDB.query(
      "INSERT INTO tbl_leave_request (empcode , leave_status , leave_type , date_from , date_to , total_days, leave_remark, leave_cc, leave_indt, leave_by, leave_transaction, request_to, leave_attachment) VALUES (:empcode , :leave_status , :leave_type , :date_from , :date_to , :total_days, :leave_remark, :leave_cc, :leave_indt, :leave_by, :leave_transaction, :request_to, :file)",
      {
        replacements: {
          empcode: req.body.empCode,
          leave_status: "PEN",
          leave_type: leaveType,
          date_from: moment(fromDt, "DD-MM-YYYY").format("YYYY-MM-DD"),
          date_to: moment(toDt, "DD-MM-YYYY").format("YYYY-MM-DD"),
          total_days: calculation,
          leave_remark: leaveReason + "<br/><br/>=========<br/>Note: This request is generated by Human Resource Management. <br/>=========",
          leave_cc: "--",
          leave_indt: moment(new Date()).tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss"),
          leave_by: req.logedINUser,
          leave_transaction: applicationID,
          request_to: reportofficer[0].emp_code,
          file: req.file ? req.file ? req.file.filename : "--" : "--"
        },
        type: hrmsDB.QueryTypes.INSERT,
        transaction: t,
      }
    );

    if (stmt.length > 0) {
      (mail_calculation = calculation), (mail_report_officer = reportofficer[0].emp_email), (mail_application = applicationID);
      var mail_name = await hrmsDB.query("SELECT CONCAT(emp_f_name,' ', emp_l_name) as name FROM tbl_emp_basic WHERE emp_code = :empcode", {
        replacements: {
          empcode: req.logedINUser,
        },
        type: hrmsDB.QueryTypes.SELECT,
      });
      var mailName = mail_name[0]?.name || "";

      let cc_email = [];
      for (let f = 0; f < req.body.email_cc.split(",").length; f++) {
        const cc = await hrmsDB.query("SELECT emp_email FROM tbl_emp_basic WHERE emp_code = :empcode", {
          replacements: {
            empcode: req.body.email_cc.split(",")[f],
          },
          type: hrmsDB.QueryTypes.SELECT,
        });
        cc_email.push(cc[0]?.emp_email);
      }
      let checkLeavePolicy = await hrmsDB.query("SELECT leave_policy FROM tbl_emp_basic WHERE emp_code = :empcode", {
        replacements: {
          empcode: req.body.empCode,
        },
        type: hrmsDB.QueryTypes.SELECT,
      });
      let nameLogedInUser = await hrmsDB.query("SELECT log_full_name FROM hrms_login WHERE log_user_id= :empcode", {
        replacements: {
          empcode: req.logedINUser,
        },
        type: hrmsDB.QueryTypes.SELECT,
      });
      if (checkLeavePolicy[0].leave_policy == "conditional") {
        await createLeaveStageprocess(req, res, t, req.body.empCode, applicationID, mail_calculation, mail_report_officer, mail_application, mail_name, cc_email, leaveType, leaveReason, fromDt, toDt, fromSession, toSession, mail_leave_balance);
      } else {
        await sendInternalMail(req, mail_calculation, mail_report_officer, mail_application, mailName, cc_email, leaveType, leaveReason, fromDt, toDt, fromSession, toSession, mail_leave_balance, nameLogedInUser[0]?.log_full_name);
      }
      await t.commit();

      return res.json({
        code: 200,
        status: "success",
        message: "leave request sent to your approver for approval",
      });
    } else {
      t.rollback();
      return res.json({
        code: 500,
        status: "error",
        message: { msg: "an error while sending leave request to the server" },
      });
    }
  } catch (err) {
    t.rollback();
    return res.json({ code: 500, status: "error", message: { msg: err } });
  }
};
exports.getLeaveDetails = async (req, res) => {
  try {
    let arr = [];
    const stmt = await hrmsDB.query("SELECT * FROM master_leave2 ", {
      type: hrmsDB.QueryTypes.SELECT,
    });
    for (let i = 0; i < stmt.length; i++) {
      arr.push({
        policy: JSON.parse(stmt[i].leave_policy),
        effectiveDate: moment(stmt[i].leave_effective_from, "YYYY-MM-DD").format("DD-MM-YYYY"),
        calType: stmt[i].leave_calendar_type,
        key: stmt[i].unique_key,
      });
    }
    return res.json({ code: 200, status: "success", data: arr });
  } catch (err) {
    return res.json({ code: 500, status: "error", message: err });
  }
};

//Update leave details
exports.updateLeaveDetails = async (req, res) => {
  try {
    let st = await hrmsDB.query("SELECT * FROM master_leave2 WHERE unique_key = :key", {
      replacements: {
        key: req.body.key,
      },
      type: hrmsDB.QueryTypes.SELECT,
    });
    let type = req.body.type;
    let obj = JSON.parse(st[0].leave_policy);
    obj[type] = {
      monthBalance: req.body.monthBalance,
      yearBalance: req.body.yearBalance,
      canBackDate: req.body.canBackDate,
    };
    let stmt = await hrmsDB.query("UPDATE master_leave2 SET leave_policy = :policy WHERE unique_key = :key", {
      replacements: {
        policy: JSON.stringify(obj),
        key: req.body.key,
      },
      type: hrmsDB.QueryTypes.UPDATE,
    });
    if (stmt.length == 0) {
      return res.json({ code: 500, status: "error", message: "no data found to update" });
    }
    return res.json({ code: 200, status: "success", message: "leave details updated successfully" });
  } catch (err) {
    helper.crashRes(res, err, { routeName: req.originalUrl });
  }
};

//ADD leave details
exports.addLeaveDetails = async (req, res) => {
  try {
    const st = await hrmsDB.query("INSERT INTO master_leave2 (leave_policy,leave_effective_from,leave_calendar_type,unique_key) VALUES (:policy,:effectiveDate,:calType,:key)", {
      replacements: {
        policy: JSON.stringify(req.body.policy),
        effectiveDate: req.body.effectiveDate,
        calType: req.body.calType,
        key: helper.getUniqueNumber(),
      },
    });
    if (st.length == 0) {
      return res.json({ code: 500, status: "error", message: "no data found to update" });
    }
    return res.json({ code: 200, status: "success", message: "leave details added successfully" });
  } catch (err) {
    helper.crashRes(res, err, { routeName: req.originalUrl });
  }
};

exports.leaveAppveMaster = async (req, res) => {
  try {
    const valid = new Validator(req.body, {
      search: "required",
    });

    if (valid.passes()) {
      const stmt1 = hrmsDB.query("SELECT emp_code AS id, emp_f_name AS text , emp_code as code FROM tbl_emp_basic WHERE emp_code LIKE :key OR emp_f_name LIKE :key OR emp_l_name LIKE :key or emp_email LIKE :key LIMIT 50", {
        replacements: {
          key: `%${req.body.search}%`,
        },
        type: hrmsDB.QueryTypes.SELECT,
      });

      const stmt2 = hrmsDB.query("SELECT approval_code AS id, approval_name AS text , approval_code as code FROM tbl_external_approvers WHERE approval_code LIKE :key OR approval_name LIKE :key OR approval_mobile LIKE :key or approval_email LIKE :key LIMIT 50", {
        replacements: {
          key: `%${req.body.search}%`,
        },
        type: hrmsDB.QueryTypes.SELECT,
      });

      Promise.all([stmt1, stmt2]).then((result) => {
        return res.json([...result[0], ...result[1]]);
      });
    }
  } catch (err) {
    helper.crashRes(res, err, { routeName: req.originalUrl });
  }
};

exports.addLeaveAppveMaster = async (req, res) => {
  try {
    const valid = new Validator(req.body, {
      employee: "required",
      sequence: "required|array",
      approveBy: "required|array",
      isFarward: "required|array",
    });

    if (valid.fails()) {
      return res.status(400).json({ message: helper.firstErrorValidatorjs(valid) });
    }

    let data = [];

    for (let i = 0; i < req.body.sequence.length; i++) {
      const isExtStmt = await hrmsDB.query("SELECT * FROM tbl_external_approvers WHERE approval_code = :key", {
        replacements: {
          key: req.body.approveBy[i],
        },
        type: hrmsDB.QueryTypes.SELECT,
      });

      let isExt = false;
      if (isExtStmt.length > 0) {
        isExt = true;
      }

      data.push({
        sequence: Number(req.body.sequence[i]),
        stage_name: `Stage ${i + 1}`,
        approver: req.body.approveBy[i],
        isFarward: req.body.isFarward[i],
        isExt: isExt,
      });
    }

    jsonData = {
      stages: data,
    };

    const st = await hrmsDB.query("SELECT * FROM tbl_approval_process WHERE flow_for = :for", {
      replacements: {
        for: req.body.employee,
      },
      type: hrmsDB.QueryTypes.SELECT,
    });
    if (st.length > 0) {
      return res.json({ code: 500, status: "error", message: "already exist" });
    }

    const stmt = await hrmsDB.query("INSERT INTO tbl_approval_process (flow_condition,flow_template,flow_for) VALUES (:condition,:template,:for) ", {
      replacements: {
        condition: JSON.stringify(jsonData),
        template: helper.getUniqueNumber(),
        for: req.body.employee,
      },
      type: hrmsDB.QueryTypes.INSERT,
    });

    if (stmt.length == 0) {
      return res.json({ code: 500, status: "error", message: "no data found to update" });
    }
    return res.json({ code: 200, status: "success", message: "leave details added successfully" });
  } catch (err) {
    helper.crashRes(res, err, { routeName: req.originalUrl });
  }
};

exports.viewLeaveAppveMaster = async (req, res) => {
  try {
    const stmt = await hrmsDB.query("SELECT * FROM tbl_approval_process WHERE flow_for = :for", {
      replacements: {
        for: req.body.employee,
      },
      type: hrmsDB.QueryTypes.SELECT,
    });

    if (stmt.length == 0) {
      return res.status(404).json({ code: 500, status: "error", message: "no data found to update" });
    } else {
      const data = {
        stages: JSON.parse(stmt[0].flow_condition).stages,
        template: stmt[0].flow_template,
        user: stmt[0].flow_for,
      };

      return res.json(data);
    }
  } catch (err) {
    helper.crashRes(res, err, { routeName: req.originalUrl });
  }
};

exports.viewUserLeaveAppveMaster = async (req, res) => {
  try {
  } catch (err) {
    helper.crashRes(res, err, { routeName: req.originalUrl });
  }
};

exports.editLeaveAppveMaster = async (req, res) => {
  try {
    const stmt = await hrmsDB.query("SELECT * FROM tbl_approval_process WHERE flow_for = :for", {
      replacements: {
        for: req.body.employee,
      },
      type: hrmsDB.QueryTypes.SELECT,
    });

    if (stmt.length == 0) {
      return res.status(404).json({ code: 500, status: "error", message: "no data found to update" });
    } else {
      let arr = [];
      for (let i = 0; i < req.body.sequence.length; i++) {
        arr.push({ sequence: req.body.sequence[i], stage_name: req.body.stage[i], approver: req.body.approveBy[i] });
      }
      let t = {
        stages: arr,
      };
      let stmt1 = await hrmsDB.query("UPDATE tbl_approval_process SET flow_condition = :condition WHERE flow_for = :for", {
        replacements: {
          condition: JSON.stringify(t),
          for: req.body.employee,
        },
        type: hrmsDB.QueryTypes.UPDATE,
      });
      if (stmt1.length == 0) {
        return res.json({ code: 500, status: "error", message: "no data found to update" });
      }
      return res.json({ code: 200, status: "success", message: "leave stages updated successfully" });
    }
  } catch (err) {
    helper.crashRes(res, err, { routeName: req.originalUrl });
  }
};

exports.applyUserLeave = async (req, res) => {
  try {
    const valid = new Validator(req.body, {
      leavetype: "required",
      empCode: "required",
      fromDate: "required",
      toDate: "required",
      remark: "required",
    });

    if (valid.fails()) {
      return res.status(400).json({ message: helper.firstErrorValidatorjs(valid) });
    }

    // LEAVE TYPE FOR USER

    // IF
    // IF STAGES

    // GET ALL STAGE OF USER
    const stagesStmt = await hrmsDB.query("SELECT * FROM tbl_approval_process WHERE flow_for = :for", {
      replacements: {
        for: req.body.empCode,
      },
      type: hrmsDB.QueryTypes.SELECT,
    });

    console.log(JSON.parse(stagesStmt[0].flow_condition).stages);

    const stages = JSON.parse(stagesStmt[0].flow_condition).stages;
    const stagesLen = stages.length;

    for (let i = 0; i < stagesLen; i++) {
      console.log(stages[i].sequence, stages[i].stage_name, stages[i].approver);
    }

    if (stagesLen == 0) {
      return res.status(404).json({ code: 500, status: "error", message: "no data found to update" });
    }

    if (stagesStmt.length == 0) {
      return res.status(404).json({ code: 500, status: "error", message: "no data found to update" });
    }

    return res.json({ code: 200, status: "success", message: "Leave Applied" });
  } catch (err) {
    helper.crashRes(res, err, { routeName: req.originalUrl });
  }
};

exports.getLeavedaysList = async (req, res) => {
  try {
    const valid = new Validator(req.body, {
      fromdate: "required",
      toDate: "required",
      empCode: "required",
    });

    if (valid.fails()) {
      return res.status(400).json({ message: helper.firstErrorValidatorjs(valid) });
    }

    const empdata = await hrmsDB.query("SELECT payroll_id , payroll_branch  FROM tbl_emp_basic WHERE emp_code = :empCode", {
      replacements: {
        empCode: req.body.empCode,
      },
      type: hrmsDB.QueryTypes.SELECT,
    });

    if (empdata.length == 0) {
      return res.status(404).json({ code: 500, status: "error", message: "User not data found!!!" });
    }

    const startDate = moment(req.body.fromdate, "DD-MM-YYYY");
    const dateList = [];
    let totalleavedays = 0;
    const holyDayStmt = await hrmsDB.query("SELECT * FROM master_holiday WHERE is_restricted = 'N' AND for_payroll = :payroll AND for_branch = :branch AND DATE_FORMAT(holiday_date_from, '%Y-%m') BETWEEN :fromDate AND :toDate", {
      replacements: {
        fromDate: moment(req.body.fromdate, "DD-MM-YYYY").format("YYYY-MM"),
        toDate: moment(req.body.toDate, "DD-MM-YYYY").format("YYYY-MM"),
        payroll: empdata[0].payroll_id,
        branch: empdata[0].payroll_branch,
      },
      type: hrmsDB.QueryTypes.SELECT,
    });
    const holdayDates = [];
    if (holyDayStmt.length > 0) {
      for (let i = 0; i < holyDayStmt.length; i++) {
        const startHoly = moment(holyDayStmt[i].holiday_date_from, "YYYY-MM-DD");
        const endHoly = moment(holyDayStmt[i].holiday_date_to, "YYYY-MM-DD");
        while (startHoly <= endHoly) {
          holdayDates.push(moment(startHoly, "YYYY-MM-DD").format("DD-MM-YYYY"));
          startHoly.add(1, "days");
        }
      }
    }

    while (startDate <= moment(req.body.toDate, "DD-MM-YYYY")) {
      // SET HOLIADAY
      let isHoliday = false;
      isHoliday = startDate.format("dddd") == "Sunday";
      if (holdayDates.includes(startDate.format("DD-MM-YYYY"))) {
        isHoliday = true;
      }

      if (!isHoliday) {
        totalleavedays += 1;
      }
      // END SET HOLIDAY
      dateList.push({
        date: moment(startDate, "YYYY-MM-DD").format("DD-MM-YYYY"),
        dayName: moment(startDate, "YYYY-MM-DD").format("dddd"),
        lable: isHoliday ? "Leave" : "FullDay",
      });
      startDate.add(1, "days");
    }

    return res.json({ code: 200, status: "success", data: { dateList, totalleavedays } });
  } catch (err) {
    return helper.crashRes(res, err, { routeName: req.originalUrl });
  }
};
