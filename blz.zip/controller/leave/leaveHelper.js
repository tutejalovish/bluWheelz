const { hrmsDB } = require("../../config/database");
const helper = require("../../helper/helper");
const moment = require("moment");
const { v4: uuidv4, v4 } = require("uuid");
const fs = require('fs');
const path = require('path');
const emailRequestTemplate = fs.readFileSync(path.join(__dirname, "../../helper/MailTemplate/LeaveRequest.html"));

const mailTemplate = (data, body) => {
    return `
    <!DOCTYPE html>
  <html lang="en">
  <head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Leave Approval</title>
  </head>
  <body style="font-family: Arial, sans-serif;">
  
  <div style="max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #ccc; border-radius: 5px; background-color: #f9f9f9;">
      <h2 style="text-align: center;">Leave Approval Request</h2>
      <p>Hello ${data.name},</p>
      <p>${body.empCode} has requested leave and requires your approval. Please review the details below:</p>
  
      <table style="width: 100%; margin-bottom: 20px;">
          <tr>
              <th style="text-align: left;">Employee Name:</th>
              <td>${body.empCode}</td>
          </tr>
          <tr>
              <th style="text-align: left;">Leave Type:</th>
              <td>${body.type}</td>
          </tr>
          <tr>
              <th style="text-align: left;">Start Date:</th>
              <td>${body.startDate}</td>
          </tr>
          <tr>
              <th style="text-align: left;">End Date:</th>
              <td>${body.endDate}</td>
          </tr>
          <tr>
              <th style="text-align: left;">Reason:</th>
              <td>${body.reason}</td>
          </tr>
      </table>
  
      <p>Please click the button below to approve the leave request:</p>
      <div style="text-align: center;">
          <a href="${app.locals.baseUrl}view/extLeave/${data.type}/${data.approveKey}" style="display: inline-block; padding: 10px 20px; background-color: #007bff; color: #fff; text-decoration: none; border-radius: 5px;">Approve Leave</a>
      </div>
  
      <p>If you have any questions or concerns, feel free to contact [Your Contact Information].</p>
  
      <p>Thank you,</p>
      <p>[Your Name]</p>
  </div>
  
  </body>
  </html>
  
    `;
}
const parseDate = (dateStr) => {
    return moment(dateStr, "DD-MM-YYYY");
};
const createLeaveStageprocess = async function (req, res, transaction, empCode, applicationID, mail_calculation, mail_report_officer, mail_application, mail_name, cc_email, leaveType, leaveReason, fromDt, toDt, fromSession, toSession, mail_leave_balance) {

    const stagesStmt = await hrmsDB.query("SELECT * FROM tbl_approval_process WHERE flow_for = :for", {
        replacements: {
            for: empCode,
        },
        type: hrmsDB.QueryTypes.SELECT,
    });

    const stages = JSON.parse(stagesStmt[0].flow_condition).stages;
    const stagesLen = stages.length;

    const time = moment().format("YYYY-MM-DD HH:mm:ss");
    let keys = [];
    for (let i = 0; i < stagesLen; i++) {

        const key = v4();
        keys.push(key);

        const createStmt = await hrmsDB.query("INSERT INTO tbl_approval_history(approve_status, approve_stage, sent_time, approve_by, approve_key, leave_request , leave_key) VALUES ( :status, :stage, :sendTime, :approve_by , :key, :request , :leave_key)", {
            replacements: {
                status: "P",
                stage: stages[i].sequence,
                sendTime: time,
                approve_by: stages[i].approver,
                remark: req.body.reason,
                key: key,
                request: empCode,
                leave_key: applicationID
            },
            type: hrmsDB.QueryTypes.INSERT,
            transaction: transaction
        });

    }
    if (stages[0].isExt == true) {

        const getDetailExtStmt = await hrmsDB.query("SELECT * FROM tbl_external_approvers WHERE approval_code = :code", {
            replacements: { code: stages[0].approver },
            type: hrmsDB.QueryTypes.SELECT
        });
        const data = {
            email: getDetailExtStmt[0].approval_email,
            name: getDetailExtStmt[0].approval_name,
            approveKey: keys[0],
        }

        if (stages[0].isFarward == false) {
            await sendExtApproveMail(req.body, data)
        } else {
            sendExtFarwardMail(req, mail_calculation, mail_report_officer, mail_application, mail_name, cc_email, leaveType, leaveReason, fromDt, toDt, fromSession, toSession)
        }
    } else {



        // SEND MAIL IF INTERNAL APPROVER
        sendInternalMail(req, mail_calculation, mail_report_officer, mail_application, mail_name, cc_email, leaveType, leaveReason, fromDt, toDt, fromSession, toSession, mail_leave_balance)

    }
}

const sendExtApproveMail = async function (body, data) {
    data.type = "approve"
    helper.sendMail("somendra.yadav@mscorpres.in", null, "Leave Request", mailTemplate(data), null);
}
const sendExtFarwardMail = async function (body, data) {
    data.type = "forward"
    helper.sendMail("somendra.yadav@mscorpres.in", null, "Leave Request", mailTemplate(data, body), null);
}

const sendInternalMail = async function (req, mail_calculation, mail_report_officer, mail_application, mail_name, cc_email, leaveType, leaveReason, fromDt, toDt, fromSession, toSession, leave_balance,generatedByName) {
    const emailRequestTemplateStr = fs.readFileSync(path.join(__dirname, "../../helper/MailTemplate/LeaveRequest.html"), "utf-8");

    const personalizedTemplate = emailRequestTemplateStr.replace('<%= from_date %>', moment(fromDt, "DD-MM-YYYY").format("DD-MM-YYYY") + "(Session " + fromSession + ")").replace('<%= to_date %>', moment(toDt, "DD-MM-YYYY").format("DD-MM-YYYY") + "(Session " + toSession + ")").replace('<%= total_days %>', mail_calculation).replace('<%= reason %>', leaveReason).replace('<%= name %>', mail_name + "(" + req.body.empCode + ")").replace('<%= leave_type %>', leaveType).replace('<%= leave_id %>', mail_application).replace('<%= leave_balance %>', leave_balance).replace('<%= generatedByName %>', generatedByName+"("+req.logedINUser + ")");


    helper.emailValidation(mail_report_officer, (validationResult) => {
        if (validationResult.code === 200) {
            helper.sendMail(mail_report_officer, cc_email, "Leave Requested", personalizedTemplate);
        }
    });

}

const leave = async function (fromDt, toDt, fromSession, toSession, req, leaveType, empCode, startMonth) {
    ///////////////////////////////////////////
    let eligibleForleave = await hrmsDB.query("SELECT emp_leave_status FROM tbl_emp_basic WHERE emp_code = :empcode", {
        replacements: {
            empcode: empCode
        },
        type: hrmsDB.QueryTypes.SELECT,
    })

    let obj = JSON.stringify(eligibleForleave[0].emp_leave_status);

    let finalObj = JSON.parse(obj);


    let str = JSON.parse(finalObj);



    let status = str.emp_status;
    if (status !== "E") {
        return ({ code: 500, status: "error", message: { msg: "You are not eligible for leave" } });
    }
    let leaves = str.emp_leave_status
    let result = leaves.find(element => element == leaveType.toLowerCase());

    if (result == undefined || result == null) {
        return { code: 500, status: "error", message: { msg: `${empCode} are not eligible for ${leaveType} leave` } };
    }









    ///////////////////////////////////////////
    const format = "DD-MM-YYYY";
    if (leaveType != "ACL" && leaveType != "OD" && leaveType != "LWP" && leaveType != "CL") {
        const stmt0 = await hrmsDB.query("SELECT month_leave_bal FROM tbl_leave_log WHERE month_leave_type = :type AND leave_empcode = :empCode AND leave_year = :leaveYear AND leave_month = :leaveMonth", {
            replacements: {
                empCode: empCode,
                type: leaveType,
                leaveYear: moment(startMonth, "DD-MM-YYYY").format("YYYY"),
                leaveMonth: moment(startMonth, "DD-MM-YYYY").format("YYYY-MM"),
            },
            type: hrmsDB.QueryTypes.SELECT,
        });
        if (stmt0.length == 0) {
            console.log("No leave balance");
            return { code: 500, status: "error", message: { msg: "No leave balance" } };
        }
        const leaveBal = Number(stmt0[0].month_leave_bal);

        //Calculate days between fromDt and toDt
        // const diff = moment(toDt, format).diff(moment(fromDt, format), "days") + 1;
        //////////////////////CALCULATE DAYS///////////////////////////////

        const fromDt1 = req.body.startDate;
        const fromSession1 = req.body.startSession;
        const toDt1 = req.body.endDate;
        const toSession1 = req.body.endSession;

        const fromDate1 = moment(fromDt1, "DD-MM-YYYY");
        const toDate1 = moment(toDt1, "DD-MM-YYYY");

        // Query to Get Session Information
        const sessionStmt1 = await hrmsDB.query("SELECT * FROM master_session WHERE leave_type = :type ORDER BY ID DESC LIMIT 1", {
            replacements: {
                type: leaveType,
            },
            type: hrmsDB.QueryTypes.SELECT,
        });
        if (sessionStmt1.length == 0) {
            return res.json({
                code: 500,
                status: "error",
                message: { msg: "session not configured in system" },
            });
        }

        const totalSessions = sessionStmt1[0].leave_session_count;
        const sessionDurations = sessionStmt1[0].leave_session_value
            .split(",")
            .map((pair) => pair.split(":").map((value) => value.trim()))
            .reduce((acc, [key, value]) => {
                acc[key] = parseFloat(value);
                return acc;
            }, {});
        let calculation = 0;
        

        if (leaveType == "OD") {
            const timezone = "Asia/Kolkata"; // India IST timezone
            // if (!moment(fromDt, "DD-MM-YYYY").tz(timezone).isSame(moment(toDt, "DD-MM-YYYY").tz(timezone), "day")) {
            //   return res.status(400).json({ message: "for OD leave, start and end dates must be the same" });
            // }
            let totalHours = 0;
            let totalMinutes = 0;

            const startSessionTime1 = sessionStmt1[0].leave_session_tm.split(",")[fromSession1 - 1].split("-")[0].trim();
            const endSessionTime1 = sessionStmt1[0].leave_session_tm.split(",")[toSession1 - 1].split("-")[1].trim();

            const startMoment1 = moment(startSessionTime1, "hh:mm A").tz(timezone);
            const endMoment1 = moment(endSessionTime1, "hh:mm A").tz(timezone);

            totalHours = endMoment1.diff(startMoment1, "hours");
            totalMinutes = endMoment1.diff(startMoment1, "minutes") % 60;

            calculation = totalHours + " h & " + totalMinutes + " m";
        } else if (leaveType == "WFH" || leaveType == "EL" || leaveType == "SL" || leaveType == "CL" || leaveType == "ACL" || leaveType == "LWP") {
            let currentDate = fromDate1.clone();

            while (currentDate.isSameOrBefore(toDate1)) {
                const currentDaySessionStart = currentDate.isSame(fromDate1) ? fromSession1 : 1;
                const currentDaySessionEnd = currentDate.isSame(toDate1) ? toSession1 : totalSessions;

                for (let i = currentDaySessionStart; i <= currentDaySessionEnd; i++) {
                    calculation += sessionDurations[i] || 0; // Use 0 if session number not found in sessionDurations
                }

                currentDate.add(1, "day");
            }
        } else {
            return res.status(400).json({ message: "leave type not configured in system" });
        }

        ///////////////////////////////////////////////////////////////////
        const diff = Number(calculation)
        if (leaveBal < diff) {
            return { code: 500, status: "error", message: { msg: "Insufficient leave balance" } };
        }
    }
    if (!parseDate(fromDt).isValid() || !parseDate(toDt).isValid() || parseDate(toDt).isBefore(parseDate(fromDt))) {
        return {
            code: 500,
            status: "error",
            message: { msg: "you have selected an invalid date range" },
        };
    }

    const fromDate = moment(fromDt, format);
    const toDate = moment(toDt, format);

    if (fromDate.year() !== toDate.year()) {
        return {
            code: 500,
            status: "error",
            message: { msg: "Leave date must be of the same year" },
        };
    }
    // if (fromDate.isBefore(moment(), 'day')) {
    //     return {
    //         code: 500,
    //         status: "error",
    //         message: { msg: "Leave Start date cannot be a past date" },
    //     };
    // }

    if (leaveType == "WFH") {
        if (fromSession == toSession) {
            return {
                code: 500,
                status: "error",
                message: { msg: "WFH apply for full day only or only for one day" },
            };
        }
    }

    if (fromDate.isSame(toDate, "day") && fromSession > toSession) {
        return {
            code: 500,
            status: "error",
            message: { msg: "Invalid session range 'from session' must be greater than or equal to 'to session' when 'from date' and 'to date' are the same" },
        };
    }

    let checkPoint = await hrmsDB.query("SELECT * FROM tbl_emp_basic WHERE emp_code = :empcode", {
        replacements: {
            empcode: empCode,
        },
        type: hrmsDB.QueryTypes.SELECT,
    });
    if (checkPoint.length === 0) {
        return {
            code: 500,
            status: "error",
            message: { msg: "something happened wrong while processing the request" },
        };
    }

    if (checkPoint[0].emp_status !== "A") {
        return {
            code: 500,
            status: "error",
            message: { msg: "employee profile status is not active" },
        };
    }

    // D = Disabled || E = Enabled
    if (checkPoint[0].emp_leave_status === "D") {
        return {
            code: 500,
            status: "error",
            message: { msg: "employee are not eligible for the leave" },
        };
    }
    // CHECK REASON LENGTH 15 SHOULD NOT BE LESS THAN 15
    if (req.body.reason.length < 15) {
        return {
            code: 500,
            status: "error",
            message: { msg: "reason should not be in less than 15 characters" },
        };
    }

    /*if (helper.validateMessage(req.body.reason) !== 'OK') {
        return {
          code: 500,
          status: "error",
          message: { msg: helper.validateMessage(req.body.reason) },
        };
      }*/

    // CHECK PREVIOUS LEAVE REQUEST
    const checkPreviousRequest = await hrmsDB.query("SELECT * FROM tbl_leave_request WHERE date_from = :fromdate AND date_to = :todate AND empcode = :empcode AND leave_type = :type AND leave_status NOT IN ('REJ', 'RTN') ORDER BY ID DESC LIMIT 1", {
        replacements: {
            fromdate: moment(fromDt, "DD-MM-YYYY").format("YYYY-MM-DD"),
            todate: moment(toDt, "DD-MM-YYYY").format("YYYY-MM-DD"),
            empcode: empCode,
            type: leaveType,
        },
        type: hrmsDB.QueryTypes.SELECT,
    });
    if (checkPreviousRequest[0]?.leave_by == req.logedINUser) {
        return {
            code: 500,
            status: "error",
            message: { msg: "you have already submitted the leave for the selected date" },
        };
    } else if (checkPreviousRequest.length > 0) {
        return {
            code: 500,
            status: "error",
            message: { msg: "employee have already requested for the leave on the selected date" },
        };
    }

    // Query to Get Session Information
    const sessionStmt = await hrmsDB.query("SELECT * FROM master_session WHERE leave_type = :type AND leave_setting = :year ORDER BY ID DESC LIMIT 1", {
        replacements: {
            type: leaveType,
            year: moment().year(),
        },
        type: hrmsDB.QueryTypes.SELECT,
    });

    if (sessionStmt.length == 0) {
        return {
            code: 500,
            status: "error",
            message: { msg: "session not configured for the current year, contact administrator" },
        };
    }

    return sessionStmt;
}

module.exports = { createLeaveStageprocess, sendExtApproveMail, sendExtFarwardMail, mailTemplate, leave, sendInternalMail }
