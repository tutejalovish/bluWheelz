const wpHelper = require('../../helper/wpHelper');

const message = async (req, res) => {

    try {

        const message = req.body.data.message.body;

        if (message.split(" ").includes("hello")) {
            const result = await wpHelper.send({ message: "Hello reply", chatId: req.body.data.message.from });
        }

        return res.json({ success: true });
    }
    catch (err) {
        console.log(err);
    }

}

module.exports = {
    message
}