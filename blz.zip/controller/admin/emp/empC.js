const { hrmsDB } = require("../../../config/database");

var html_to_pdf = require("html-pdf-node");

// ADD EMPLOYEE
exports.addEmp = async function (req, res) {
    if (req.query.type === "check") {
        let checkAadhaar = await hrmsDB.query("SELECT * FROM `tbl_emp_basic` WHERE `emp_aadhaar_no` = :aadhaar", {
            replacements: {
                aadhaar: req.body.aadhaar,
            },
            type: hrmsDB.QueryTypes.SELECT,
        });
        if (checkAadhaar.length > 0) {
            return res.json({
                response: "exist",
                message: "employee Aadhaar number already mapped with employee code [" + checkAadhaar[0].emp_code + "]\nDo you want to register anyway?",
            });
        } else {
            return res.json({
                response: "notexist",
            });
        }
    } else if (req.query.type === "save") {
        const transaction = await hrmsDB.transaction();
        let new_emp_code, generateCode;
        if (req.body.status == "P") {
            generateCode = await hrmsDB.query("SELECT * FROM `tbl_emp_collar` WHERE `collar_id` = :type AND `collar_company` = :payroll FOR UPDATE", {
                replacements: {
                    type: req.body.type,
                    payroll: req.body.payroll,
                },
                type: hrmsDB.QueryTypes.SELECT,

            });
            if (generateCode.length > 0) {
                let last_id = generateCode[0].collar_last_emp;
                last_id = parseInt(last_id) + 1;
                last_id = last_id.toString();
                last_id = last_id.padStart(parseInt(4), "0");
                new_emp_code = generateCode[0].collor_prefix + last_id;
            } else {
                return res.status(500).json({
                    code: 500,
                    message: "employee code is not configured for the appraisal that you have selected, contact to support team",
                    status: "error",
                });
            }

        } else if (req.body.status == "T") {
            generateCode = await hrmsDB.query("SELECT emp_code FROM `tbl_emp_basic` WHERE emp_join_status = 'T' GROUP BY `emp_code` ORDER BY `ID` DESC LIMIT 1", {
                type: hrmsDB.QueryTypes.SELECT,
            });
            if (generateCode.length > 0) {
                let last_id = generateCode[0].emp_code;
                let strings = last_id.replace(/[0-9]/g, "");
                let digits = (parseInt(last_id.replace(/[^0-9]/g, "")) + 1).toString();
                if (digits.length < 4) digits = ("0000" + digits).substr(-4);
                new_emp_code = strings + digits;
            } else {
                new_emp_code = "T0008";
            }
        } else {
            res.status(500).json({
                code: 500,
                message: "employee mapped status is not configured for the payroll you have selected, contact to support team",
                status: "error",
            });
            return;
        }

        await hrmsDB.query("UPDATE `tbl_emp_collar` SET `collar_last_emp` = `collar_last_emp`+1 WHERE `collar_id` = :type AND `collar_company` = :payroll", {
            replacements: {
                type: req.body.type,
                payroll: req.body.payroll,
            },
            type: hrmsDB.QueryTypes.UPDATE,
            transaction: transaction,
        });

        let checkCode = await hrmsDB.query("SELECT `emp_code` FROM `tbl_emp_basic` WHERE `emp_code` = :emp_code GROUP BY `emp_code` LIMIT 1", {
            replacements: {
                emp_code: new_emp_code,
            },
            type: hrmsDB.QueryTypes.SELECT,
        });
        if (checkCode.length > 0) {
            await transaction.rollback();
            res.status(500).json({
                code: 500,
                message: "alloting employee code as [" + new_emp_code + "] is already exist with us, required manual checking or contact to system administrator",
                status: "error",
            });
            return;
        }

        let stmt = await hrmsDB.query(
            "INSERT INTO `tbl_emp_basic` (`emp_join_status`, `emp_type`, `emp_code`, `emp_mobile`, `emp_f_name`, `emp_l_name`, `emp_dob`, `insert_dt`, `insert_by`,`payroll_id`,`emp_aadhaar_no`,`payroll_branch`,`emp_doj`,`temp_password`) VALUES (:status, :type, :emp_code, :emp_mobile, :emp_f_name, :emp_l_name, :emp_dob, :insert_dt, :insert_by, :payroll,:aadhaar,:branch,:doj,:temppassword)",
            {
                replacements: {
                    status: req.body.status,
                    type: req.body.type,
                    emp_code: new_emp_code,
                    emp_mobile: helper.removeWhitespace(req.body.mobile),
                    emp_f_name: helper.formatter(req.body.f_name),
                    emp_l_name: helper.formatter(req.body.l_name),
                    emp_dob: moment(req.body.dob, "DD-MM-YYYY").format("YYYY-MM-DD"),
                    insert_dt: moment(new Date()).tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss"),
                    insert_by: req.logedINUser,
                    payroll: req.body.payroll,
                    aadhaar: helper.removeWhitespace(req.body.aadhaar),
                    branch: req.body.branch,
                    doj: moment(req.body.doj, "DD-MM-YYYY").format("YYYY-MM-DD"),
                    temppassword: helper.generatePassword(true),
                },
                type: hrmsDB.QueryTypes.INSERT,
                transaction: transaction,
            }
        );
        if (stmt.length > 0) {


            await transaction.commit();
            return res.json({
                code: 200,
                message: `Employee ID generated (CODE : ${new_emp_code} ) & the same has been sent via SMS & WhatsApp`,
                status: "success",
            });
        } else {
            await transaction.rollback();
            return res.status(500).json({
                code: 500,
                message: "an error occured while adding employee",
                status: "error",
            });
        }
    } else {
        return res.status(500).json({
            status: "error",
            message: "Invalid form request..",
            code: "500",
        });
    }
}

exports.fetchAllEmployees = async function (req, res) {
    try {

        const date = req.body.date.match(/([0-9]{2})-([0-9]{2})-([0-9]{4})/g);
        const fromdate = moment(date[0], "DD-MM-YYYY").format("YYYY-MM-DD");
        const todate = moment(date[1], "DD-MM-YYYY").format("YYYY-MM-DD");

        if (moment(date[1], "DD-MM-YYYY").diff(moment(date[0], "DD-MM-YYYY"), "days") > "90") {
            return res.status(500).json({ status: "error", message: "on the w.e.f Nov 11, 2021: We can provide you 90 days OR (3 months) data only", code: "500" });
        }

        let stmt;
        if (req.body.type == "J") {
            if (req.body.payroll_code == "all") {
                stmt = await hrmsDB.query(
                    "SELECT `tbl_emp_basic`.*, CASE WHEN tbl_emp_basic.payroll_branch = '--' THEN 'N/A' ELSE master_branch.branch_name END as branch, tbl_emp_salary.ID as salary_status, `tbl_emp_family`.`emp_father_name` FROM `tbl_emp_basic` LEFT JOIN `tbl_emp_family` ON `tbl_emp_family`.`emp_code` = `tbl_emp_basic`.`emp_code` LEFT JOIN master_branch ON master_branch.branch_key = tbl_emp_basic.payroll_branch LEFT JOIN tbl_emp_salary ON tbl_emp_salary.emp_code = tbl_emp_basic.emp_code AND tbl_emp_salary.ID =( SELECT MAX(ID) FROM tbl_emp_salary WHERE tbl_emp_salary.emp_code = tbl_emp_basic.emp_code ) WHERE DATE_FORMAT(`tbl_emp_basic`.`emp_doj`,'%Y-%m-%d') BETWEEN :date1 AND :date2 ORDER BY `tbl_emp_basic`.`ID` ASC",
                    {
                        replacements: {
                            date1: fromdate,
                            date2: todate,
                        },
                        type: hrmsDB.QueryTypes.SELECT,
                    }
                );
            } else {
                stmt = await hrmsDB.query(
                    "SELECT `tbl_emp_basic`.*, CASE WHEN tbl_emp_basic.payroll_branch = '--' THEN 'N/A' ELSE master_branch.branch_name END as branch, tbl_emp_salary.ID as salary_status, `tbl_emp_family`.`emp_father_name` FROM `tbl_emp_basic` LEFT JOIN `tbl_emp_family` ON `tbl_emp_family`.`emp_code` = `tbl_emp_basic`.`emp_code` LEFT JOIN master_branch ON master_branch.branch_key = tbl_emp_basic.payroll_branch LEFT JOIN tbl_emp_salary ON tbl_emp_salary.emp_code = tbl_emp_basic.emp_code AND tbl_emp_salary.ID =( SELECT MAX(ID) FROM tbl_emp_salary WHERE tbl_emp_salary.emp_code = tbl_emp_basic.emp_code ) WHERE `payroll_id` = :payroll AND DATE_FORMAT(`tbl_emp_basic`.`emp_doj`,'%Y-%m-%d') BETWEEN :date1 AND :date2 AND tbl_emp_basic.emp_type = :category ORDER BY `tbl_emp_basic`.`ID` ASC",
                    {
                        replacements: {
                            payroll: req.body.payroll_code,
                            date1: fromdate,
                            date2: todate,
                            category: req.body.category,
                        },
                        type: hrmsDB.QueryTypes.SELECT,
                    }
                );
            }
        } else if (req.body.type == "I") {
            if (req.body.payroll_code == "all") {
                stmt = await hrmsDB.query(
                    "SELECT `tbl_emp_basic`.*, CASE WHEN tbl_emp_basic.payroll_branch = '--' THEN 'N/A' ELSE master_branch.branch_name END as branch, tbl_emp_salary.ID as salary_status,`tbl_emp_family`.`emp_father_name` FROM `tbl_emp_basic` LEFT JOIN `tbl_emp_family` ON `tbl_emp_family`.`emp_code` = `tbl_emp_basic`.`emp_code` LEFT JOIN master_branch ON master_branch.branch_key = tbl_emp_basic.payroll_branch LEFT JOIN tbl_emp_salary ON tbl_emp_salary.emp_code = tbl_emp_basic.emp_code AND tbl_emp_salary.ID =( SELECT MAX(ID) FROM tbl_emp_salary WHERE tbl_emp_salary.emp_code = tbl_emp_basic.emp_code ) WHERE DATE_FORMAT(`tbl_emp_basic`.`emp_doj`,'%Y-%m-%d') BETWEEN :date1 AND :date2 AND tbl_emp_basic.emp_type = :category ORDER BY `tbl_emp_basic`.`ID` ASC",
                    {
                        replacements: {
                            date1: fromdate,
                            date2: todate,
                            category: req.body.category,
                        },
                        type: hrmsDB.QueryTypes.SELECT,
                    }
                );
            } else {
                stmt = await hrmsDB.query(
                    "SELECT `tbl_emp_basic`.*, CASE WHEN tbl_emp_basic.payroll_branch = '--' THEN 'N/A' ELSE master_branch.branch_name END as branch, tbl_emp_salary.ID as salary_status, `tbl_emp_family`.`emp_father_name` FROM `tbl_emp_basic` LEFT JOIN `tbl_emp_family` ON `tbl_emp_family`.`emp_code` = `tbl_emp_basic`.`emp_code` LEFT JOIN master_branch ON master_branch.branch_key = tbl_emp_basic.payroll_branch LEFT JOIN tbl_emp_salary ON tbl_emp_salary.emp_code = tbl_emp_basic.emp_code AND tbl_emp_salary.ID =( SELECT MAX(ID) FROM tbl_emp_salary WHERE tbl_emp_salary.emp_code = tbl_emp_basic.emp_code ) WHERE `payroll_id` = :payroll AND DATE_FORMAT(`tbl_emp_basic`.`insert_dt`,'%Y-%m-%d') BETWEEN :date1 AND :date2 AND tbl_emp_basic.emp_type = :category ORDER BY `tbl_emp_basic`.`ID` ASC",
                    {
                        replacements: {
                            payroll: req.body.payroll_code,
                            date1: fromdate,
                            date2: todate,
                            category: req.body.category,
                        },
                        type: hrmsDB.QueryTypes.SELECT,
                    }
                );
            }
        }

        if (stmt.length > 0) {
            let data = [];
            for (let i = 0; i < stmt.length; i++) {
                data.push({
                    emp_name: stmt[i].emp_f_name + " " + stmt[i].emp_l_name,
                    branch: stmt[i].branch,
                    father_name: stmt[i].emp_father_name == null ? "N/A" : stmt[i].emp_father_name,
                    emp_dob: moment(stmt[i].emp_dob, "YYYY-MM-DD").format("DD-MM-YYYY"),
                    emp_mobile: stmt[i].emp_mobile,
                    emp_status: stmt[i].emp_status,
                    emp_salary: stmt[i].salary_status == null || stmt[i].salary_status == "" ? "notOK" : "OK",
                    emp_reg_dt: moment(stmt[i].insert_dt, "YYYY-MM-DD HH:mm:ss").format("DD-MM-YYYY HH:mm:ss"),
                    emp_code: stmt[i].emp_code,
                    emp_gender: stmt[i].emp_gender,
                    emp_doj: moment(stmt[i].emp_doj, "YYYY-MM-DD").format("DD-MM-YYYY"),
                });
            }

            return res.json({
                code: 200,
                data,
            });
        } else {
            return res.status(500).json({ code: 500, status: "error", message: "no data found", });
        }
    } catch (err) {
        return helper.crashRes(res, err);
    }
}

exports.printCV = async (req, res) => {
    try {

        const emp = req.body.code;

        let stmt = await hrmsDB.query("SELECT * FROM `tbl_emp_basic` WHERE `emp_code` = :empcode", {
            replacements: { empcode: emp },
            type: hrmsDB.QueryTypes.SELECT,
        });
        if (stmt.length > 0) {
            let file = {
                url: `https://hrms.mscorpres.online/app/print/employee_cv.php?code=${emp}`,
            };
            let options = { format: "A4", printBackground: true };
            await html_to_pdf
                .generatePdf(file, options)
                .then((pdfBuffer) => {
                    let filename = "CV_" + req.body.code.replace(/[/]/g, "_") + ".pdf";
                    return res.json({
                        code: 200,
                        status: "success",
                        message: "file generated successfully...",
                        data: { buffer: pdfBuffer, filename: filename },
                    });
                })
                .catch((err) => {
                    return res.status(500).json({ code: 500, status: "error", message: "error while generating file...", error: err.stack, });
                });
        } else {
            return res.status(500).json({ code: 500, status: "error", message: "employee not found", });
        }

    } catch (err) {
        return helper.crashRes(res, err);
    }
}