const { hrmsDB } = require("../../../config/database");

exports.createVacancy = async (req, res) => {

    try {

        const vacancy_id = helper.getUniqueNumber();

        const stmt = await hrmsDB.query("INSERT INTO vacancy( vacancy_id, vacancy_name, start_date, end_date, insert_by, insert_dt, status) VALUES ( :vacancy_id, :vacancy_name, :start_date, :end_date, :insert_by, :insert_dt, :status )", {
            replacements: {
                vacancy_id: vacancy_id,
                vacancy_name: req.body.vacancy,
                start_date: moment(req.body.start_date, "DD-MM-YYYY").format("YYYY-MM-DD"),
                end_date: moment(req.body.end_date, "DD-MM-YYYY").format("YYYY-MM-DD"),
                insert_by: req.logedINUser,
                insert_dt: moment(new Date()).tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss"),
                status: "ACTIVE"
            }
        });

        if (stmt.length > 0) {
            return res.json({ code: 200, status: "success", message: "Vacancy created successfully" });
        } else {
            return res.status(500).json({ code: 500, status: "error", message: "an error occured while adding employee" });
        }

    } catch (err) {
        return helper.crashRes(res, err);
    }

}

exports.fetchVacancyList = async (req, res) => {
    try {
        const stmt = await hrmsDB.query("SELECT vacancy.*, vacancy_master.vacancy_name FROM vacancy LEFT JOIN vacancy_master ON vacancy_master.vacancy_key = vacancy.vacancy_name ", {
            type: hrmsDB.QueryTypes.SELECT
        });

        if (stmt.length > 0) {

            const data = [];

            for (let i = 0; i < stmt.length; i++) {
                data.push({
                    v_id: stmt[i].vacancy_id,
                    v_name: stmt[i].vacancy_name,
                    s_date: moment(stmt[i].start_date, "DD-MM-YYYY").format("DD-MM-YYYY"),
                    e_date: moment(stmt[i].end_date, "DD-MM-YYYY").format("DD-MM-YYYY"),
                    status: stmt[i].status
                })
            }

            return res.json({ code: 200, status: "success", data: data });
        } else {
            return res.status(500).json({ code: 500, status: "error", message: "No data Found!!!" });
        }

    }
    catch (err) {
        return helper.crashRes(res, err);
    }
}

// FETCH VACANCY HIRING OPTION 
exports.fetchVacancyHiringOption = async (req, res) => {
    try {
        const data = [];
        const stmt0 = await hrmsDB.query("SELECT vacancy_id, vacancy_master.vacancy_name FROM vacancy LEFT JOIN vacancy_master ON vacancy_master.vacancy_key = vacancy.vacancy_name WHERE status='ACTIVE' ", {
            type: hrmsDB.QueryTypes.SELECT,
        });

        console.log(stmt0);

        if (stmt0.length == 0) {
            return res.json({ code: 500, status: "error", message: "Something went wrong" });
        }
        for (let i = 0; i < stmt0.length; i++) {
            data.push({ text: stmt0[i].vacancy_name, id: stmt0[i].vacancy_id });
        }

        return res.json({ code: 200, status: "success", data: data });
    } catch (err) {
        return helper.crashRes(res, err);
    }
}

// GET DATE LIST OF SELECTED VACANCY
exports.fetchInterviewDate = async (req, res) => {
    try {

        const stmt = await hrmsDB.query("SELECT start_date, end_date FROM vacancy WHERE status='ACTIVE' AND vacancy_id = :vacancy_id", {
            replacements: { vacancy_id: req.body.v_id },
            type: hrmsDB.QueryTypes.SELECT
        })

        if (stmt.length == 0) {
            return res.status(500).json({ code: 500, status: "error", message: "Something went wrong" });
        }

        function getDates(startDate, stopDate) {
            var dateArray = [];
            var currentDate = moment(startDate);
            var stopDate = moment(stopDate);
            while (currentDate <= stopDate) {
                dateArray.push(moment(currentDate, 'YYYY-MM-DD').format('DD-MM-YYYY'))
                currentDate = moment(currentDate, 'YYYY-MM-DD').add(1, 'days');
            }
            return dateArray;
        }

        const data = getDates(stmt[0].start_date, stmt[0].end_date);

        return res.json({ code: 200, status: "success", data: data });

    } catch (err) {
        return helper.crashRes(res, err);
    }
}

// FETCH PENDING REGISTRATION USER
exports.fetchPendingRegList = async (req, res) => {
    try {
        const data = [];
        const results = await hrmsDB.query(`SELECT tbl_hiring.* , vacancy_master.vacancy_name FROM tbl_hiring LEFT JOIN vacancy ON vacancy.vacancy_id = tbl_hiring.vaccancy_name LEFT JOIN vacancy_master ON vacancy.vacancy_name = vacancy_master.vacancy_key WHERE tbl_hiring.status = 'P'`, {
            type: hrmsDB.QueryTypes.SELECT,
        });

        if (results.length == 0) {
            return res.status(500).json({ code: 500, status: "error", message: "Data not found" });
        }

        for (let i = 0; i < results.length; i++) {
            data.push({
                unique_id: results[i].unique_no,
                first_name: results[i].f_name,
                last_name: results[i].l_name,
                dateOfBirth: moment(results[i].dob, "YYYY-MM-DD").format("DD-MM-YYYY"),
                currentAge: moment().diff(moment(results[i].dob), "years"),
                mobile_no: results[i].mobile,
                email_id: results[i].email ?? "Not Available",
                aadhaar_id: results[i].aadhaar.replace(/(\d{4})/g, "$1-").slice(0, -1),
                vacancy_name: results[i].vacancy_name,
                interview_date: moment(results[i].interview_dt).format("DD-MM-YYYY"),
            });
        }
        return res.json({ code: 200, status: "success", data: data, });
    } catch (error) {
        return helper.crashRes(res, error);
    }
}


// DEACTIVATE VACANCY BY ADMIN
exports.deactivateVacancy = async (req, res) => {
    try {
        const stmt = await hrmsDB.query("UPDATE vacancy SET status = 'CLOSE' WHERE vacancy_id = :uid", {
            replacements: {
                uid: req.body.v_id,
            }
        });

        console.log(stmt);

        if (stmt[0].affectedRows > 0) {
            return res.json({ code: 200, status: "success", message: "Vacancy deactivated successfully" });
        } else {
            return res.status(500).json({ code: 500, status: "error", message: "There is no changes!!!" });
        }

    }
    catch (err) {
        return helper.crashRes(res, err);
    }
}

// REJECT USER VACANCY BY ADMIN
exports.rejectReg = async (req, res) => {
    try {
        const stmt = await hrmsDB.query("UPDATE tbl_hiring SET status = 'R' WHERE unique_no = :uid", {
            replacements: {
                uid: req.body.uid,
            },
        });

        if (stmt[0].affectedRows > 0) {
            return res.json({ code: 200, status: "success", message: "Rejected successfully" });
        } else {
            return res.status(500).json({ code: 500, status: "error", message: "There is no changes!!!" });
        }

    }
    catch (err) {
        return helper.crashRes(res, err);
    }
}

exports.approveReg = async (req, res) => {
    const t = await hrmsDB.transaction();
    try {
        const stmt = await hrmsDB.query("UPDATE tbl_hiring SET status = 'A' WHERE unique_no = :uid", {
            replacements: {
                uid: req.body.uid,
            },
            transaction: t
        });

        if (stmt[0].affectedRows > 0) {

            let new_emp_code

            let generateCode = await hrmsDB.query("SELECT * FROM `tbl_emp_collar` WHERE `collar_id` = :type AND `collar_company` = :payroll FOR UPDATE", {
                replacements: {
                    type: req.body.collar,
                    payroll: req.body.contractor,
                },
                transaction: t,
                type: hrmsDB.QueryTypes.SELECT,

            });
            if (generateCode.length > 0) {
                let last_id = generateCode[0].collar_last_emp;
                last_id = parseInt(last_id) + 1;
                last_id = last_id.toString();
                last_id = last_id.padStart(parseInt(4), "0");
                new_emp_code = generateCode[0].collor_prefix + last_id;
            }

            const stmt = await hrmsDB.query("UPDATE tbl_hiring SET unique_no = :new_emp_code WHERE unique_no = :uid", {
                replacements: {
                    uid: req.body.uid,
                    new_emp_code: new_emp_code,
                },
                transaction: t
            });

            if (stmt[0].affectedRows > 0) {
                await t.commit();
                return res.json({ code: 200, status: "success", message: "Approved successfully" });
            } else {
                await t.rollback();
                return res.status(500).json({ code: 500, status: "error", message: "There is problem in approving" });
            }

        } else {
            await t.rollback();
            return res.status(500).json({ code: 500, status: "error", message: "There is no changes!!!" });
        }

    } catch (err) {
        await t.rollback();
        return helper.crashRes(res, err);
    }

}