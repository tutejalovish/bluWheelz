const express = require("express");
const router = express.Router();
const auth = require("../../middleware/auth");
const helper = require("../../helper/helper");
const {blz} = require("../../config/database");
//Fetch Master Company Data
router.post("/fetchCompany", /*[auth.isAuthorized()],*/ async (req, res) => {
    try {
      const limit = 10;
      let stmt;
      if (req.body.searchTerm) {
        stmt = await blz.query("SELECT `company_name`, `company_id` FROM `master_company` WHERE (`company_name` LIKE :search OR `company_id` LIKE :search) ORDER BY `ID` ASC LIMIT :limit", {
          replacements: { search: `%${req.body.searchTerm}%`, limit: limit },
          type: blz.QueryTypes.SELECT,
        });
      } else {
        stmt = await blz.query("SELECT `company_name`, `company_id` FROM `master_company`  ORDER BY `ID` ASC LIMIT :limit", {
          replacements: { limit: limit },
          type: blz.QueryTypes.SELECT,
        });
      }
  
      let final = [];
  
      stmt.map((item) => {        
        final.push({ id: item.company_id, code: item.company_id, text: item.company_name });
  
        if (stmt.length == final.length) {
          res.json(final);
          return;
        }        
      });
    } catch (err) {
      console.log(err);
      return helper.crashRes(res, err, { routeName: req.originalUrl });
    }
  });
module.exports = router