module.exports = function (app) {
  const auth = require("../middleware/auth");

  app.use("/view", [auth.isAuthorized()], require("./viewAuthR.js"));

  app.use("/dashboard", require("./DASHBOARD/dashboardv2.js"));

  app.use("/master", require("./OTHERS/utils.js"));

  app.use("/company", require("./COMPANY/company.js"));

  // HRMS
};
