const express = require("express");
const router = express.Router();
const auth = require("../../middleware/auth");
const helper = require("../../helper/helper");
const {blz} = require("../../config/database");

//Fetch Client Data
router.get("/fetchClientData", /*[auth.isAuthorized()],*/ async (req, res) => {
    try {

     const stmt=await blz.query("SELECT master_company.company_name, start_date,end_date,client_name,location,vehicle_type,client_poc_name,poc_number,driver_name,mobile_number,ev_name,vehicle_number,no_of_trial_days,working_hours,etr,atr,day_end_atr,start_km,end_km,km_1,start_percentage,end_percentage,percentage_consumed,day_end_km,km_2,start_percentage_2,end_percentage_2,percentage_consumed_2,total_soc_consumed,total_km,expected_range,soc_top_up_on_route,total_order,order_delivered,return_order,pick_up,toll,weight,remark FROM `vehicle_trials` LEFT JOIN `master_company` ON `vehicle_trials`.`company` = `master_company`.`company_id` WHERE `vehicle_trials`.`company` = :company ORDER BY `vehicle_trials`.`ID` ASC", {
        replacements: { company: req.query.company },
        type: blz.QueryTypes.SELECT,
    })
    let arr=[];
    if(stmt.length>0){
        for(let i=0;i<stmt.length;i++){
            arr.push({
                companyName:stmt[i].company_name,
                startDate:stmt[i].start_date,
                endDate:stmt[i].end_date,
                clientName:stmt[i].client_name,
                location:stmt[i].location,
                vehicleType:stmt[i].vehicle_type,
                clientPocName:stmt[i].client_poc_name,
                pocNumber:stmt[i].poc_number,
                driverName:stmt[i].driver_name,
                mobileNumber:stmt[i].mobile_number,
                evName:stmt[i].ev_name,
                vehicleNumber:stmt[i].vehicle_number,
                noOfTrialDays:stmt[i].no_of_trial_days,
                workingHours:stmt[i].working_hours,
                etr:stmt[i].etr,
                atr:stmt[i].atr,
                dayEndAtr:stmt[i].day_end_atr,
                startKm:stmt[i].start_km,
                endKm:stmt[i].end_km,
                km1:stmt[i].km_1,
                startPercentage:stmt[i].start_percentage,
                endPercentage:stmt[i].end_percentage,
                percentageConsumed:stmt[i].percentage_consumed,
                dayEndKm:stmt[i].day_end_km,
                km2:stmt[i].km_2,
                startPercentage2:stmt[i].start_percentage_2,
                endPercentage2:stmt[i].end_percentage_2,
                percentageConsumed2:stmt[i].percentage_consumed_2,
                totalSocConsumed:stmt[i].total_soc_consumed,
                totalKm:stmt[i].total_km,
                expectedRange:stmt[i].expected_range,
                socTopUpOnRoute:stmt[i].soc_top_up_on_route,
                totalOrder:stmt[i].total_order,
                orderDelivered:stmt[i].order_delivered,
                returnOrder:stmt[i].return_order,
                pickUp:stmt[i].pick_up,
                toll:stmt[i].toll,
                weight:stmt[i].weight,
                remark:stmt[i].remark
            })
        }
    }
   return res.json({ code: 200, status: "success", data: arr })

    }
    catch (err) {
        console.log(err);
        return helper.crashRes(res, err, { routeName: req.originalUrl });
    }
})
module.exports = router