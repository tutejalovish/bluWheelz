var express = require("express");
var router = express.Router();

const auth = require("../middleware/auth");




// AUTH URL


router.get("/logout", [auth.isAuthorized()],  (req, res) => {
  req.session.destroy();
  return res.redirect("/");
});
//Profile
router.get("/user/profile", (req, res) => {
  return res.render("app/user/profile", { title: "Login" });
});

router.get("/user/comp/personal",  (req, res) => {
  return res.render("app/user/comp/personal", { title: "Login" });
});

router.get("/user/comp/security",  (req, res) => {
  return res.render("app/user/comp/security", { title: "Login" });
});

router.get("/auth/login-2fa",  (req, res) => {
  return res.render("auth/login-2fa", { title: "Login with 2FA" });
});
router.get("/auth/sensitive-2fa",  (req, res) => {
  return res.render("auth/sensitive-2fa", { title: "Login with 2FA" });
});
router.get("/auth/setup-2fa",  (req, res) => {
  return res.render("./auth/setup-2fa", { title: "2 fa" });
});

router.get("/dashboard", [auth.isAuthorized()],  (req, res) => {
  return res.render("app/dashboard", { title: "Dashboard",pageId:435155 });
});

router.get("/dashboardv2", [auth.isAuthorized()],  (req, res) => {
  return res.render("app/dashboardv2", { title: "Dashboard V2",pageId:435156 });
});
router.get("/event", [auth.isAuthorized()],  (req, res) => {
  return res.render("app/event", { title: "Events" });
});
router.get("/feed", [auth.isAuthorized()],  (req, res) => {
  return res.render("app/feed", { title: "Dashboard V2" });
});

router.get("/overviewAttendance", [auth.isAuthorized()],  (req, res) => {
  return res.render("app/overviewAttendance", { title: "Attendance Overview" });
});

router.get("/overviewEmployee", [auth.isAuthorized()],  (req, res) => {
  return res.render("app/overviewEmployee", { title: "Employee Overview",pageId:435156 });
});

router.get("/overviewPayroll", [auth.isAuthorized()],  (req, res) => {
  return res.render("app/overviewPayroll", { title: "Payroll Overview" });
});
//Employee
router.get("/pages/master/emp/addEmp",  (req, res) => {
  return res.render("app/pages/master/emp/addEmp", { title: "Add Employee",pageId:902131 });
});
router.get("/pages/master/emp/bulkUpload",  (req, res) => {
  return res.render("app/pages/master/emp/bulkUpload", { title: "Bulk Add Employee",pageId:989129 });
});
router.get("/pages/master/emp/employeeSalaryView",  (req, res) => {
  return res.render("app/pages/master/emp/employeeSalaryView", { title: "View Employee Salary" });
})
router.get("/pages/master/emp/editEmp",  (req, res) => {
  return res.render("app/pages/master/emp/editEmp", { title: "Edit Employee" });
});
router.get("/pages/master/emp/salaryDesign",  (req, res) => {
  return res.render("app/pages/master/emp/salaryDesign", { title: "Edit Salary" });
});
router.get("/pages/master/emp/empSalaryView",  (req, res) => {
  return res.render("app/pages/master/emp/empSalaryView", { title: "View Salary" });
});
router.get("/pages/master/emp/viewEmpDetails",  (req, res) => {
  return res.render("app/pages/master/emp/viewEmpDetails", { title: "View Employee Details",pageId:756432 });
});

// EMP ADMIN
router.get("/pages/master/emp/genLetter",  (req, res) => {
  return res.render("app/pages/master/emp/admin/genLetter");
});
router.get("/pages/prepare-letter",  (req, res) => {
  return res.render("app/pages/master/emp/admin/pages/prepare-letter");
});

router.get("/pages/master/sendNotification",  (req, res) => {
  return res.render("app/pages/master/sendNotification", { title: "Add Employee" });
});
//WINDOW
router.get("/window/reference",  (req, res) => {
  return res.render("app/pages/master/emp/pages/window/addRef");
});

//EDIT
router.get("/pages/master/emp/pages/comp/personal",  (req, res) => {
  return res.render("app/pages/master/emp/pages/comp/personal");
});
router.get("/pages/master/emp/pages/comp/bank",  (req, res) => {
  return res.render("app/pages/master/emp/pages/comp/bank");
});
router.get("/pages/master/emp/pages/personal_info",  (req, res) => {
  return res.render("app/pages/master/emp/pages/personal_info",{pageId:719901});
});
router.get("/pages/master/emp/pages/family_info",  (req, res) => {
  return res.render("app/pages/master/emp/pages/family_info",{pageId:719902});
});
router.get("/pages/master/emp/pages/office_action",  (req, res) => {
  return res.render("app/pages/master/emp/pages/office_action",{pageId:719909});
});
router.get("/pages/master/emp/pages/esiptpf",  (req, res) => {
  return res.render("app/pages/master/emp/pages/esiptpf",{pageId:719907});
});
router.get("/pages/master/emp/pages/salary_structure",  (req, res) => {
  return res.render("app/pages/master/emp/pages/salary_structure",{pageId:719908});
});
router.get("/pages/master/emp/pages/employement_info",  (req, res) => {
  return res.render("app/pages/master/emp/pages/employement_info",{pageId:719905});
});
router.get("/pages/master/emp/pages/bank_info",  (req, res) => {
  return res.render("app/pages/master/emp/pages/bank_info",{pageId:719906});
});
router.get("/pages/master/emp/pages/contact_info",  (req, res) => {
  return res.render("app/pages/master/emp/pages/contact_info",{pageId:719904});
});
router.get("/pages/master/emp/pages/education_info",  (req, res) => {
  return res.render("app/pages/master/emp/pages/education_info",{pageId:719903});
});
router.get("/pages/master/emp/pages/attach_document",  (req, res) => {
  return res.render("app/pages/master/emp/pages/attach_document",{pageId:719910});
});
//SATURATORY COMPLIANCE
router.get("/compliance/epf/mReport",  (req, res) => {
  return res.render("app/compliance/epf/mReport",{pageId:627837});
});
router.get("/compliance/epf/yReport",  (req, res) => {
  return res.render("app/compliance/epf/yReport",{pageId:627838});
});

router.get("/compliance/esi/mReport",  (req, res) => {
  return res.render("app/compliance/esi/mReport",{pageId:627814});
});

router.get("/report/monthlySummary",  (req, res) => {
  return res.render("app/report/monthlySummary",{pageId:627123});
});

router.get("/report/yearlySummary",  (req, res) => {
  return res.render("app/report/yearlySummary",{pageId:627177});
});

//REPORT
router.get("/report/getReport",  (req, res) => {
  return res.render("app/report/getReport");
});

//ASSETS
router.get("/assets/allotedAssets",  (req, res) => {
  return res.render("app/assets/allotedAssets",{pageId: 146434});
});
router.get("/assets/allotToAssets",  (req, res) => {
  return res.render("app/assets/allotToAssets",{pageId: 455544});
});
router.get("/assets/imageAsset",  (req, res) => {
  return res.render("app/assets/imageAsset", { title: "Image Asset" ,pageId: 455543});
});
router.get("/assets/newAsset",  (req, res) => {
  return res.render("app/assets/newAsset", { title: "New Asset" ,pageId: 623621});
});
router.get("/assets/updateAssets",  (req, res) => {
  return res.render("app/assets/updateAssets",{pageId: 455747});
});
router.get("/assets/history",  (req, res) => {
  return res.render("app/assets/pages/assetHistory");
});
router.get("/assets/detail",  (req, res) => {
  return res.render("app/assets/pages/assetExplore");
});
router.get("/assets/return",  (req, res) => {
  return res.render("app/assets/pages/assetReturn");
});

// SOP
router.get("/sop",  (req, res) => {
  return res.render("app/sop", { title: "SOP" });
});
//ATTENDANCE
router.get("/pages/attendance/process/draftAttendance",  (req, res) => {
  return res.render("app/pages/attendance/process/draftAttendance", { title: "Attendance", pageId: 970921 });
});

router.get("/pages/attendance/process/getAttendance",  (req, res) => {
  return res.render("app/pages/attendance/process/getAttendance", { title: "Attendance",pageId: 212899 });
});

router.get("/pages/attendance/process/viewAttendance",  (req, res) => {
  return res.render("app/pages/attendance/process/viewAttendance", { title: "Attendance",pageId: 678631 });
});

router.get("/leave/apply",  (req, res) => {
  return res.render("app/leave/apply", { title: "Leave Apply" });
});
router.get("/leave/refreshLeaves",  (req, res) => {
  return res.render("app/leave/refreshLeaves", { title: "Leave Refresh" });
});
router.get("/leave/manage",  (req, res) => {
  return res.render("app/leave/manage", { title: "Leave Manage" });
});
router.get("/leave/leaveApproveMaster",  (req, res) => {
  return res.render("app/leave/leaveApproveMaster");
});
router.get("/leave/leaveApproveMasterView",  (req, res) => {
  return res.render("app/leave/leaveApproveMasterView");
});

// // List of Holidays
// router.get("/leave/setup/holiday",  (req, res) => {
//   return res.render("app/leave/setup/holidayList", { title: "Attendance" });
// })

// Edit List of Holidays
router.get("/leave/setup/model/editLeave",  (req, res) => {
  return res.render("app/leave/setup/model/editLeave");
});

router.get("/leave/setup/holiday",  (req, res) => {
  return res.render("app/leave/setup/holidayList");
});

router.get("/leave/setup/grantLeave",  (req, res) => {
  return res.render("app/leave/setup/grantLeave");
});

router.get("/holiday/add",  (req, res) => {
  return res.render("app/leave/setup/model/addHoliday");
});
router.get("/holiday/edit/:id",  (req, res) => {
  return res.render("app/leave/setup/model/editHoliday");
});

// PAYROLL
router.get("/payroll/empSeperation",  (req, res) => {
  return res.render("app/payroll/empSeperation", { pageId: 437676 });
});
router.get("/payroll/salaryProcess",  (req, res) => {
  return res.render("app/payroll/salaryProcess");
});
//WINDOW
router.get("/window/finalizeSalary",  (req, res) => {
  return res.render("app/payroll/window/finalizeSalary");
});

router.get("/payroll/salaryComponent",  (req, res) => {
  return res.render("app/payroll/salaryComponent");
});



router.get("/payroll/salaryComponent/:type/:slug",  (req, res) => {
  const slug = req.params.slug;
  return res.render("app/payroll/salaryComponentEdit", { title: "Payroll", type: req.params.type, slug: slug });
});
router.get("/payroll/salaryComponentAdd/:type",  (req, res) => {
  const type = req.params.type.toUpperCase();
  return res.render("app/payroll/salaryCompnentAdd", { title: "Payroll", type: type });
});
router.get("/payroll/referenceId",(req,res)=>{
  return res.render("app/payroll/referenceId");
})
router.get("/payroll/addWorkerWages",(req,res)=>{
  return res.render("app/payroll/addWorkerWages",{title:"Worker Wages"});
})
router.get("/payroll/holdSalary",  (req, res) => {
  return res.render("app/payroll/holdSalary",{pageId: 872389});
});

router.get("/payroll/releaseSalary",  (req, res) => {
  return res.render("app/payroll/releaseSalary",{pageId: 823892});
});

router.get("/payroll/model/releaseSalary",  (req, res) => {
  return res.render("app/payroll/model/releaseSalary");
});
router.get("/payroll/salaryCheck",  (req, res) => {
  return res.render("app/payroll/salaryCheck");
});
router.get("/payroll/arrear",  (req, res) => {
  return res.render("app/payroll/arrear",{pageId: 213131});
});
router.get("/payroll/deduction",  (req, res) => {
  return res.render("app/payroll/deduction",{pageId: 213132});
});
router.get("/payroll/empSeperation",  (req, res) => {
  return res.render("app/payroll/empSeperation");
});
router.get("/payroll/salaryStatement",  (req, res) => {
  return res.render("app/payroll/salaryStatement",{pageId: 923972});
});
router.get("/payroll/salaryRevisions",  (req, res) => {
  return res.render("app/payroll/salaryRevisions");
});
router.get("/payroll/payslip",  (req, res) => {
  return res.render("app/payroll/payslip",{pageId: 412414});
});
router.get("/payroll/testPayslip",  (req, res) => {
  return res.render("app/payroll/testPayslip",{pageId: 412414});
});
router.get("/payroll/bulkSalaryUpload",  (req, res) => {
  return res.render("app/payroll/bulkSalaryUpload",{pageId: 541231});
});
router.get("/payroll/model/assetgen",  (req, res) => {
  return res.render("app/payroll/model/assetgen", { title: "Asset Return Full and Final" });
});
router.get("/payroll/model/fullAndFinalLetter",  (req, res) => {
  return res.render("app/payroll/model/fullAndFinalLetter", { title: "Asset Return Full and Final" });
});
router.get("/payroll/fullAndFinal",  (req, res) => {
  return res.render("app/payroll/fullAndFinal",{pageId:783456});
});
router.get("/payroll/fullAndFinalView",  (req, res) => {
  return res.render("app/payroll/fullAndFinalView",{pageId:783456});
});
// router.get("/transfer/initTransfer",  (req, res) => {
//   return res.render("/app/transfer/initTransfer", { title: "Payroll" });
// });

// >> PAYROLL COMP
router.get("/payroll/compEmpSep/resignation",  (req, res) => {
  return res.render("app/payroll/compEmpSep/resignation");
});

// REPORT

router.get("/report/getReport",  (req, res) => {
  return res.render("app/report/getReport");
});

// WINDOW
router.get("/report/R1",  (req, res) => {
  return res.render("app/report/pages/R1");
});

router.get("/report/R2",  (req, res) => {
  return res.render("app/report/pages/R2");
});

router.get("/report/R3",  (req, res) => {
  return res.render("app/report/pages/R3");
});

router.get("/report/R4",  (req, res) => {
  return res.render("app/report/pages/R4");
});

router.get("/report/R5",  (req, res) => {
  return res.render("app/report/pages/R5");
});

router.get("/report/R6",  (req, res) => {
  return res.render("app/report/pages/R6");
});

router.get("/report/R7",  (req, res) => {
  return res.render("app/report/pages/R7");
});

router.get("/report/R8",  (req, res) => {
  return res.render("app/report/pages/R8");
});

// MODEL
// router.get("/report/models/empBenefit",  (req, res) => {
//   return res.render("app/report/models/empBenefit");
// });
// router.get("/report/models/contList",  (req, res) => {
//   return res.render("app/report/models/contList");
// });



// router.get("/report/models/empBon",  (req, res) => {
//   return res.render("app/report/models/empBon");
// });

// router.get("/report/models/banktrnf",  (req, res) => {
//   return res.render("app/report/models/banktrnf");
// });
// router.get("/report/models/gnrtBulkPay",  (req, res) => {
//   return res.render("app/report/models/gnrtBulkPay");
// });
// router.get("/report/models/empSalary",  (req, res) => {
//   return res.render("app/report/models/empSalary");
// });


// END REPORT

router.get("/settings/listOfValues",  (req, res) => {
  return res.render("app/settings/listOfValues", { title: "List Of Values" });
});
router.get("/settings/listOfSubDepartment",  (req, res) => {
  return res.render("app/settings/listOfSubDepartment", { title: "List Of Sub-Values" });
});
router.get("/settings/essPortal",  (req, res) => {
  return res.render("app/settings/essPortal", { title: "ESS Portal Preference" });
});

//Hierarchy
router.get("/settings/orgHierarchy",  (req, res) => {
  return res.render("app/settings/orgHierarchy", { title: "Org. Hierarchy" });
});

// PERMISSION
router.get("/settings/permission",  (req, res) => {
  return res.render("app/settings/permission", { title: "Permission" });
});
router.get("/settings/copyPermission",  (req, res) => {
  return res.render("app/settings/copyPermission", { title: "Permission" });
});

// router.get("/settings/addpage", [auth.isAuthorized()],  (req, res) => {
router.get("/settings/addpage",  (req, res) => {
  return res.render("app/settings/addpage", { title: "Permission" });
});
router.get("/settings/leaveMaster",  (req, res) => {
  return res.render("app/settings/leaveMaster", { title: "Leave Master" });
});

router.get("/settings/leaveType",  (req, res) => {
  try {
  } catch (err) {}
  return res.render("app/settings/leaveType", { title: "Leave Master" });
});

router.get("/settings/listOfCompany",  (req, res) => {
  return res.render("app/settings/listOfCompany", { title: "List Of Company" });
});
router.get("/settings/greadMaster",  (req, res) => {
  return res.render("app/settings/greadMaster", { title: "Grade Master" });
});

router.get("/settings/leaveSetting",  (req, res) => {
  return res.render("app/settings/leaveSetting", { title: "Leave Back Day Master" });
});

//Development And Training
router.get("/developmentAndTraining/trainingDashboard",  (req, res) => {
  return res.render("app/developmentAndTraining/trainingDashboard", { title: "Development And Training",pageId:"813132" });
})

router.get("/developmentAndTraining/events",  (req, res) => {
  return res.render("app/developmentAndTraining/events", { title: "Development And Training",pageId:"813133",pageId2:"813134" });
});

router.get("/developmentAndTraining/editEvents",  (req, res) => {
  return res.render("app/developmentAndTraining/editEvents", { title: "View Development And Training Events",pageId:"813133" });
}); 

router.get("/developmentAndTraining/editModalEvent",  (req, res) => {
  return res.render("app/developmentAndTraining/editModalEvent", { title: "Edit Modal Development And Training",pageId:"813133" });
});

router.get("/developmentAndTraining/viewModalEvent",  (req, res) => {
  return res.render("app/developmentAndTraining/viewModalEvent", { title: "View Modal Development And Training",pageId:"813133" });
});



// RECRUIT
router.get("/recruit/dashboard",  (req, res) => {
  return res.render("app/recruit/dashboard", { title: "Recruit",pageId:"719912" });
});
router.get("/recruit/skills",  (req, res) => {
  return res.render("app/recruit/skills", { title: "Recruit",pageId:"719911" });
});
router.get("/recruit/jobs",  (req, res) => {
  return res.render("app/recruit/jobs", { title: "Job",pageId:"719913" });
});
router.get("/recruit/jobsViews",  (req, res) => {
  return res.render("app/recruit/jobsViews", { title: "Job",pageId:"719913" });
});
router.get("/recruit/jobApplications",  (req, res) => {
  return res.render("app/recruit/jobsApllied", { title: "Job",pageId:"719914" });
});
router.get("/recruit/interview",  (req, res) => {
  return res.render("app/recruit/interviewSchedule", { title: "Job" });
});

router.get("/recruit/model/jobcategory",  (req, res) => {
  return res.render("app/recruit/model/jobcategory", { title: "Job" });
});

router.get("/recruit/model/jobSubCategory",  (req, res) => {
  return res.render("app/recruit/model/jobSubCategory", { title: "Job" });
});

router.get("/recruit/hrLetters",  (req, res) => {
  return res.render("app/recruit/hrLetters", { title: "Letters Generations" });
});

router.get("/chat",  (req, res) => {
  return res.render("app/chat", { title: "Chat" });
});

// HIERARCHY
router.get("/hierarchy",  (req, res) => {
  return res.render("app/hierarchy/hierarchyView", { title: "Chat" });
});

module.exports = router;