const express = require("express");
const router = express.Router();
const auth = require("../../middleware/auth");
const helper = require("../../helper/helper");
const { blz } = require("../../config/database");

//Route To Fetch Data For Dashboard Client Wise
router.get(
  "/fetchClientDashboard",
  /*[auth.isAuthorized()],*/ async (req, res) => {
    try {
      const stmt = await blz.query(
        "SELECT COUNT(ID) AS noOfTrips,AVG(weight) AS averagePayload,SUM(total_km) AS totalDistance,AVG(expected_range) AS averageRange , COUNT(DISTINCT client_name) AS totalClients ,AVG(total_km) AS averageDistance FROM `vehicle_trials` WHERE `company` = :company ",
        {
          replacements: { company: req.query.company },
          type: blz.QueryTypes.SELECT,
        }
      );
      const fetchClientName=await blz.query(
          "SELECT client_name FROM `vehicle_trials` WHERE `company` = :company GROUP BY client_name",
          {
            replacements: { company: req.query.company },
            type: blz.QueryTypes.SELECT,
          }
      )
      let clientName=[];
      for (let i = 0; i < fetchClientName.length; i++) {
        clientName.push(fetchClientName[i].client_name);
      }
      let arr = [];
      arr.push({
        noOfTrips: stmt[0].noOfTrips,
        averagePayload: stmt[0].averagePayload,
        totalDistance: stmt[0].totalDistance,
        averageDistance: stmt[0].averageDistance,
        averageRange: stmt[0].averageRange,
        totalClients: stmt[0].totalClients,
        clientName: clientName,
      });
      return res.json({ code: 200, status: "success", data: arr });
    } catch (err) {
      helper.crashRes(res, err, { routeName: req.originalUrl });
    }
  }
);

//Route to Fetch Graph Data
router.get(
  "/fetchGraphData",
  /*[auth.isAuthorized()],*/ async (req, res) => {
    try {
        const fromDate = moment(req.query.fromDate, "YYYY-MM-DD");
        const toDate = moment(req.query.toDate, "YYYY-MM-DD");
        
        if (fromDate.isAfter(toDate)) {
          return res.json({ code: 400, status: "error", message: "From date cannot be greater than to date" });
        }
        
        if (toDate.diff(fromDate, 'days') > 7) {
          return res.json({ code: 400, status: "error", message: "Date range cannot be greater than 7 days" });
        }                        
        
      const stmt = await blz.query("SELECT start_date,total_km,expected_range,total_soc_consumed FROM `vehicle_trials` WHERE `company` = :company AND STR_TO_DATE(start_date, '%Y-%m-%d') BETWEEN :fromDate AND :toDate", {
        replacements: { company: req.query.company, fromDate: req.query.fromDate, toDate: req.query.toDate },
        type: blz.QueryTypes.SELECT,
      });
      let totalKm = [];
      let startDate = [];
      let expectedRange = [];
      let socConsumed = [];
      for (let i = 0; i < stmt.length; i++) {
        totalKm.push(Math.round(stmt[i].total_km));
        startDate.push(moment(stmt[i].start_date,"YYYY-MM-DD").format("DD-MMM"));
        expectedRange.push(Math.round(stmt[i].expected_range));
        socConsumed.push(Math.round(stmt[i].total_soc_consumed));
      }
      return res.json({ code: 200, status: "success", totalKm, startDate, expectedRange,socConsumed });
    } catch (err) {
        console.log(err);
      helper.crashRes(res, err, { routeName: req.originalUrl });
    }
  }
);

module.exports = router;
